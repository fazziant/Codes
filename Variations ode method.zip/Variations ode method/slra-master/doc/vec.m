function x = vec(X)
    x = X(:);