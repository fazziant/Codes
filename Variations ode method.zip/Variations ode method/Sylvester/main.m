clear all 
close all

tol=1e-6;
N = 2;  %number of polynomials
d = 1;  %degree common factor
deg=d;
sigma=.1;

M = 10;  %number of different perturbations 
len=[30:30:180]; %polynomials degree

for k=1:length(len)
    n = (len(k) - d) * ones(1, N);    %degree cofactors
    rands = @(n) poly(eig(drss(n)));
    c0 = rands(d);
    for i = 1:N
        p0{i} = conv(c0, rands(n(i) - d + 1));
    end
% l0 = sort(roots(c0));
% e   = @(ch) norm(l0 - sort(roots(ch))) / norm(l0);

P=[];  
   for j=1:M
        for i = 1:N
            pt    = randn(size(p0{i}));
            p{i}  = p0{i} + sigma * norm(p0{i}) * pt / norm(pt);
        end
        P=[p{1};p{2}];
       p1r=fliplr(P(1,:))';
       p2r=fliplr(P(2,:))';
                  
  k, j
          tic,  [sva,A,E,Phat,epsval,relerrappsvd] = dist_cd(P,deg,tol,7,2);
       tappsvd(j,k)=toc;
        eappsvd(j,k) = relerrappsvd;  
        format long
        sappsvd(j,k)=sva(end);
        

            k, j
      tic,  [svo,A,E,Phat,epsval,relerrold] = dist_cd(P,deg,tol,4,1);
       told(j,k)=toc;
        eold(j,k) = relerrold;
        format long
       sold(j,k)=svo(end);

k, j
      tic,  [svs,A,E,Phat,epsval,relerrsvd ] = dist_cd(P,deg,tol,4,2 );
         tsvd(j,k)=toc;
          esvd(j,k) = relerrsvd;
          format long
            ssvd(j,k)=svs(end);

         %  l,j
         % [ph, info] = gcd_nls({p1r,p2r}, [], deg, struct('disp', 'iter'));
         % tslra(j,l)=info.time;
         %  eslra(j,l) = sqrt(info.fmin)/norm(P(:));
       

           k, j
      tic,  [ssvs,A,E,Phat,epsval,relerrsvds] = dist_cd(P,deg,tol,1,2);
       tsvds(j,k)=toc;
        esvds(j,k) = relerrsvds;
        format long
       ssvds(j,k)=ssvs(end);
      
       relerrtot=relerrsvds+relerrsvd+relerrappsvd+relerrold;
       while relerrtot<0
             for i = 1:N
            pt    = randn(size(p0{i}));
            p{i}  = p0{i} + sigma * norm(p0{i}) * pt / norm(pt);
        end
        P=[p{1};p{2}];
       p1r=fliplr(P(1,:))';
       p2r=fliplr(P(2,:))';
                  
  k, j
          tic,  [sva,A,E,Phat,epsval,relerrappsvd] = dist_cd(P,deg,tol,7,2);
       tappsvd(j,k)=toc;
        eappsvd(j,k) = relerrappsvd;  
        format long
        sappsvd(j,k)=sva(end);
        

            k, j
      tic,  [svo,A,E,Phat,epsval,relerrold] = dist_cd(P,deg,tol,4,1);
       told(j,k)=toc;
        eold(j,k) = relerrold;
        format long
       sold(j,k)=svo(end);

k, j
      tic,  [svs,A,E,Phat,epsval,relerrsvd ] = dist_cd(P,deg,tol,4,2 );
         tsvd(j,k)=toc;
          esvd(j,k) = relerrsvd;
          format long
            ssvd(j,k)=svs(end);

         %  l,j
         % [ph, info] = gcd_nls({p1r,p2r}, [], deg, struct('disp', 'iter'));
         % tslra(j,l)=info.time;
         %  eslra(j,l) = sqrt(info.fmin)/norm(P(:));
       

           k, j
      tic,  [ssvs,A,E,Phat,epsval,relerrsvds] = dist_cd(P,deg,tol,1,2);
       tsvds(j,k)=toc;
        esvds(j,k) = relerrsvds;
        format long
       ssvds(j,k)=ssvs(end);

       relerrtot=relerrsvds+relerrsvd+relerrappsvd+relerrold;
       end

    end
  end


% disp('svd')
% [ mean(tsvd), mean(esvd)]
%  disp('slra')
%  [ mean(tslra), mean(eslra)]
% disp('old')
% [ mean(told), mean(eold)]
% disp('appsvd')
% [ mean(tappsvd), mean(eappsvd)]