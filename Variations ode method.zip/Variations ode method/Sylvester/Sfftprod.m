function y = Sfftprod(S, m, x)
 %%% Matrix vector product for a Sylvester matrix S*x based on fft
 
 %m= number of polynomials
 
%  [rS,cS]=size(S);
  rS=size(S,1);
 t=rS/m;
 for i=1:m
    y(t*(i-1)+1:t*i)= fftprodt(S(t*(i-1)+1:t*i,:),x);
 end
 y=y';
end