function [u,s,v]=appisvd(A,x,y)
%test alg4 Sylvester matrix
x=x/norm(x);
y=y/norm(y);
[m,n]=size(A);



 for i=1:10%10
    
    B=[A, y; x', 0];
    c =[zeros(m,1); 1];
    
    x1=B\c;
    nv=norm(x1(1:n));
    v=x1(1:n)/nv;
    s0(i)=abs(x1(n+1))/nv;

    B2=[A', x; y', 0];
    c2=[zeros(n,1); 1];
    
    x2=B2\c2;
    nu=norm(x2(1:m));
    u=x2(1:m);
    u=u/nu;
    s1(i)=abs(x2(m+1))/nu;
    
    if abs(s1(end)-s0(end))<1e-6
        break
    end

end
s=s1(end);
 
    
    

