function [u,s,v]=appisvdvec(A,x,y)
%test alg4 Sylvester matrix
x=orth(x);
y=orth(y);
[m,n]=size(A);


%  A=randn(100,100);
% format long
% [ud,sd,vd]=svd(A); 
% disp('exact singular triplet')
% sd(end,end)
% % ud(:,end)
% % vd(:,end)

% [ua,sa,va]=appisvd(A,u(:,end)+.01,v(:,end)+.01); diag(sa)

% y=ud(:,end)+.01;
% x=vd(:,end)+.01;
% [m,n]=size(A);


 for i=1:10
    
    B=[A, y; x', 0];
    c =[zeros(m,1); 1];
    
    x1=B\c;
    v=x1(1:n)/norm(x1(1:n));
    s0(i)=abs(x1(n+1))/norm(x1(1:n));

    B2=[A', x; y', 0];
    c2=[zeros(n,1); 1];
    
    x2=B2\c2;
    u=x2(1:m)/norm(x2(1:m));
    s1(i)=abs(x2(m+1))/norm(x2(1:m));
    
    if abs(s1(end)-s0(end))<1e-4
        break
    end

end
s=s1(end);
 
    
    

