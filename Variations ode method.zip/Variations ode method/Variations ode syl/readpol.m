function A=readpol(P)
[r,c]=size(P);
n=c-1;


A=zeros(r*n,2*n);
% Construction of A



    for i=1:n
    A(i,:)=[zeros(1,i-1),P(1,:),zeros(1,n-i)];
    A(i+n,:)=[zeros(1,i-1),P(2,:),zeros(1,n-i)];
    end
% for k=2:r
%     for j=1:n
%     A((k-1)*n+j,:)=[zeros(1,n-j),P(k,:),zeros(1,j-1)];
%     %A(n+n+j,:)=[zeros(1,n-j),P(3,:),zeros(1,j-1)];
%     end
% end