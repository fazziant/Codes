function M = Sfftproj(u, v, m)
% Projection onto Toeplitz structure based on fft
% u, v are s.t. E = uv^T is the matrix we want to project
% m is the number of polynomials

M=[];
L=length(u);
r=L/m;
for i=1:m
    M=[M;Tfftproj(u((i-1)*r+1:i*r),v)];
end

