function E = Tfftproj(u, v)
% Projection onto Toeplitz structure based on fft
% u, v are s.t. E = uv^T is the matrix we want to project
% m is the number of polynomials

L=length(u);
K=length(v);
N=L+K-1;
uf=flip(u);
u2=[uf; zeros(N-L,1)];
v2=[v; zeros(N-K,1)];
uh=fft(u2);
vh=fft(v2);

gp=ifft(uh.*vh);


g=gp./L;
 gh=g;
 gh(K+1:end)=0;
 gh(1:L-1)=0;


E=toeplitz(flip(gh(1:L)),gh(L:end));
