clear all
close all

tol=1e-6;
N = 2;  %number of polynomials
d = 1;  %degree common factor
deg=d;
sigma=.1;

M = 10;  %number of different perturbations 
len=[25:25:200]; %polynomials degree

for l=1:length(len)
n = (len(l) - d) * ones(1, N);    %degree cofactors
rands = @(n) poly(eig(drss(n)));
c0 = rands(d);
for i = 1:N
    p0{i} = conv(c0, rands(n(i) - d + 1));
end
% l0 = sort(roots(c0));
% e   = @(ch) norm(l0 - sort(roots(ch))) / norm(l0);

P=[];

    for j = 1:M
        for i = 1:N
            pt    = randn(size(p0{i}));
            p{i}  = p0{i} + sigma * norm(p0{i}) * pt / norm(pt);
            
        end
        P=[p{1};p{2}];
       p1r=fliplr(P(1,:))';
       p2r=fliplr(P(2,:))';
                  

      tic,  [sv,A,E,Phat,epsval,relerrsvd ] = dist_cd(P,deg,tol,4,2 );
         tsvd(j,l)=toc;
          esvd(j,l) = relerrsvd;

          
         [ph, info] = gcd_nls({p1r,p2r}, [], 1, struct('disp', 'iter'));
         tslra(j,l)=info.time;
          eslra(j,l) = sqrt(info.fmin)/norm(P(:));
       
          
      tic,  [sv,A,E,Phat,epsval,relerrold] = dist_cd(P,deg,tol,4,1);
       told(j,l)=toc;
        eold(j,l) = relerrold;

        
          tic,  [sv,A,E,Phat,epsval,relerrappsvd] = dist_cd(P,deg,tol,6,2);
       tappsvd(j,l)=toc;
        eappsvd(j,l) = relerrappsvd;  
    end
 end

% disp('svd')
% [ mean(tsvd), mean(esvd)]
%  disp('slra')
%  [ mean(tslra), mean(eslra)]
% disp('old')
% [ mean(told), mean(eold)]
% disp('appsvd')
% [ mean(tappsvd), mean(eappsvd)]