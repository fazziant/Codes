function [zvec,x,y,A,B,E]=intodegens(P,deg,epsil,h0,val,alsv,alproj,E)
%%%%%%% output 
% zvec = smallest singular value
% x = left eigenvector of B^T B associated to the smallest eigenvalue
% y = B*x
% A = Sylvester matrix associated to the starting polynomials
% B = A + epsilon * E
% E = Perturbation matrix
%%%%%%%%%%%%  input
% P = matrix containing the data polynomials
% deg is the degree of the GCD
% epsil: scalar parameter of the perturbation epsilon * E
% h0 = starting value of the step in Euler method
% val = starting singular value
% alsv  algorithm for singular triplet
% alproj  algorithm for projection
% E = perturbation matrix
  

format short
tol=1e-6;
h=h0;
hmin=1e-12;
countmax=40;
gamma=1.1;


[mP,nP]=size(P);


A=readpol(P);
mA=size(A);

% Initialization
k=1;
shift=0;

if nargin < 8
    E=zeros(mA);
    B=A+epsil*E;
  
    
if alsv==4
     [U,Sigma,V]=svd(B);
        z=Sigma(end+1-deg,end+1-deg);
       x=V(:,end+1-deg)/norm(V(:,end+1-deg));
        y=U(:,end+1-deg)/norm(U(:,end+1-deg));
else  
    [U,Sigma,V]=svd(B);
        z=Sigma(end+1-deg,end+1-deg);
       x=V(:,end+1-deg)/norm(V(:,end+1-deg));
        y=U(:,end+1-deg)/norm(U(:,end+1-deg));
    end
    
  if alproj==1
        E=-(y*x');
   
    E=Sprojgen(E,nP-1,mP);  
  else
  E=-Sfftproj(y,x,mP);
  end
    
    E=E/norm(E,'fro');
    
%   starting matrix   
    B=A+epsil*E;
    
 if alsv==4
     [U,Sigma,V]=svd(B);
        z=Sigma(end+1-deg,end+1-deg);
       x=V(:,end+1-deg);
       x=x/norm(x);
        y=U(:,end+1-deg);
        y=y/norm(y);
 else
     [y,z,x]=appisvd(B,x,y);
end
    
    zvec(k)=z;
    if alproj==1
            Edot=-(y*x');                  
    Edot=Sprojgen(Edot,nP-1,mP);
    else
     Edot=-Sfftproj(y,x,mP);
    end


    Edot=Edot- (trace(Edot'*E))*E;
    Edot=Edot/norm(Edot,'fro');
   
else

    E=E/norm(E,'fro');
    B=A+epsil*E;
    
    
if alsv==4
     [U,Sigma,V]=svd(B);
        z=Sigma(end+1-deg,end+1-deg);
       x=V(:,end+1-deg);
       x=x/norm(x);
        y=U(:,end+1-deg);
        y=y/norm(y);
else
         [U,Sigma,V]=svd(B);
        z=Sigma(end+1-deg,end+1-deg);
       x=V(:,end+1-deg);
       x=x/norm(x);
        y=U(:,end+1-deg);
        y=y/norm(y);  
end
   
    zvec(k)=z;
    if alproj==1
            Edot=-(y*x');                  
    Edot=Sprojgen(Edot,nP-1,mP);
    else
    Edot=-Sfftproj(y,x,mP);
    end


    Edot=Edot - (trace(Edot'*E))*E;
    Edot=Edot/norm(Edot,'fro');
end

Eold=E;

while h>hmin
z=zvec(k);
count=0;
  while count<=countmax
    count=count+1;
    B=A+epsil*E;

    
if alsv==4
     [U,Sigma,V]=svd(B);
        z=Sigma(end+1-deg,end+1-deg);
       x=V(:,end+1-deg)/norm(V(:,end+1-deg));
        y=U(:,end+1-deg)/norm(U(:,end+1-deg));
else
           [y,z,x]=appisvd(B,x,y);
end
     
    if (abs(z)<abs(zvec(k))) 
        if alproj==1
                Edot=-(y*x');                  
    Edot=Sprojgen(Edot,nP-1,mP);
        else
         Edot=-Sfftproj(y,x,mP);
        end

        Edot=Edot-(trace(Edot'*E))*E;
        Edot=Edot/norm(Edot,'fro');

        k=k+1;
        zvec(k)=z;
        Eold=E;
        break
    else
       % disp('bisection step')
        h=h/gamma;
        E=Eold+h*Edot;
        E=E/norm(E,'fro');
    end
   
end

if count==1
    h=h*gamma;
end
if count==countmax+1
   disp('maximum number of its reached in while loop')
   zvec(end)=val;
   E=E;
   B=A+epsil*E;
    return
end

% Error control
if (k>1) && (zvec(k)<=val)
    if abs(zvec(k)) > abs(zvec(k-1))
        disp('monotonicity broken');
       pause
    end
    if abs(zvec(k)) <= 1e-6 %tol
       disp('matrix looks singular');
        return
    end
    if (abs(zvec(k)-zvec(k-1)) <= 1e-6)  %tol
        disp('reached tolerance');
        return
    end
end

% Euler step
E=Eold+h*Edot; 
E=E/norm(E,'fro');

end