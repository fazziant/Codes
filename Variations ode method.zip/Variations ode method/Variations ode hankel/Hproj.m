function H = Hproj(E)
% Projection onto Hankel structure
% E is the matrix we want to project

tr=0;
[m,n] = size(E);
if m>n
    E=E';
    [m,n] = size(E);
    tr=1;
end
idx = hankel(1:m,m:(n-1)+m);
out = accumarray(idx(:),E(:));

L=[[1:m-1], m*ones(1,n-m+1),[m-1:-1:1]];

for i=1:length(out)
    out(i)=out(i)/L(i);
end


H=hankel(out(1:m),out(m:end));
if tr==1
    H=H';
end
