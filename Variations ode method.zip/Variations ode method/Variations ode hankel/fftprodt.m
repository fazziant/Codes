function [y] = fftprodt(M, x)
%FFTPROD matrix vector product M*x with M=Toeplitz(c,r), using fft


 c=M(:,1);
 r=M(1,:);
 m=length(c);

  ct1=[c;0;r(end:-1:2)'];
  rt1=[r, 0, c(end:-1:2)'];
T1= toeplitz(ct1,rt1);


 xh=[x;zeros(m,1)];


y= ifft(fft(ct1).*fft(xh));
 y=y(1:m);


