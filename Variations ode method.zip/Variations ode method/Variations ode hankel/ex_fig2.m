%%%%%%%%%%%%%%%%%%%%%% 
    clear, close all
% 
% % number of different (random) perturbations
 J=10;
% variance of the perturbations
 sigma = [0:.1:1];
    L=50;


 limit=120; %seconds
% % % generate a random signal as output of a system of order n
 n = 5; 
  sys0 = drss(n, 1, 0);  
  p0 = initial(sys0, rand(n, 1),L); 
 T=length(p0);
 
    h0=1e-4;

for l=1:length(sigma)
for j=1:J
    % perturbed signal 
    pt = randn(T, 1); p = p0 + sigma(l) * pt / norm(pt) * norm(p0);

    %%% run the algorithms
     disp('old')
  tic,  [costfold, eps0, p, delta, ph_odeold, epsval, sv, errold] = dist_hfreecon(p, n+1, h0,1,1); %old version 
told(j,l) = toc; eold(j,l)=errold;
%    

    sigma(l), j, disp('ipm')
 tic, [costfgmres, eps0, p, delta, ph_odegmres, epsval, sv,  errgmres] = dist_hfreecon(p, n+1, h0,2,2); 
 tgmres(j,l) = toc; egmres(j,l)=errgmres;

 
 s.m = n+1;
 s.n = L+1-n;
 s.w=[[1:n+1],(n+1)*ones(1,L+1-2*n-2),[n+1:-1:1]];
tic, [p_slra, i_slra] = slra(p, s, n); 
tslra(j,l) = toc
e_slra(j,l) = norm(p_slra - p)/norm(p);


  disp('svds')
tic, [costfsvds, eps0, p, delta, ph_odesvds, epsval, sv,  errsvds] = dist_hfreecon(p, n+1, h0,1,2); %svd
tsvds(j,l) = toc; esvds(j,l)=errsvds;


  disp('rsvd')
tic, [costfrsvd, eps0, p, delta, ph_odersvd, epsval, sv,  errrsvd] = dist_hfreecon(p, n+1, h0,7,2); %rsvd
trsvd(j,l) = toc,
ersvd(j,l)=errrsvd; 

end
end


 %%%%%plot
 plot(sigma,mean(esvds),'-og','MarkerSize',12)
hold on
plot(sigma,mean(eold),'-+b','MarkerSize',12)
plot(sigma,mean(egmres),'-dk','MarkerSize',12)
plot(sigma,mean(e_slra),'-or','MarkerSize',12)
plot(sigma,mean(ersvd),'-sk','MarkerSize',12)
xlabel('Noise level','FontSize',16)
ylabel('Relative error','FontSize',16)
legend('svds','old','gmres','slra','randomized')
lgd=legend;
lgd.FontSize=16;
lgd.Location='Best';
