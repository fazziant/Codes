%%% main body of the algorithm
function [costf,eps0,p,delta,q,epsval,sv,relerr] = dist_hfreecon(p,n,threshold,alsv,alproj,delta)
%%%% output
% costf = \| p - \hat p \|
% eps0 = starting value for eps
% p = starting time series
% delta = (final) normalized perturbation vector
% q = computed time series
% epsval = vector of the values of epsilon  during the iterations
% sv = evolution of the smallest singular value of the matrix H(\hat p)
% relerr = relative error

%%%% input
% p = starting time series
% n = number of rows of the Hankel matrix H(p)
% threshold: \sigma < threshold is the stopping criterion 
% alsv = algorithm used for the computation of the triple u, \sigma, v 
%    1 svds
%    2 gmres
%    7 random svd
% alproj = algorithm projection 
%    1 antidiagonal average
%    2 FFT
%  delta (optional) : initial guess for the (normalized) perturbation
timeiter=[];
tic;
h0=1e-6;   %step size Euler method

epsval=[];
limit=120;


%construction of H(p)
M=hankel(p(1:n),p(n:end));

% % % initial singular value
% uses always svd
 sigma=svd(M);
sv=[sigma(end)];

epsmin=0;    
 eps0=sv(1);


if sv(end)<threshold
    costf=0;
    eps0=0;
    p=p;
    q=p;
    delta=zeros(size(p));
    q=p;
    epsval=eps0;
    relerr=0;
    return
end
%first integration
 if nargin < 6
      [zvec,p,q,delta]=intodehankp(p,n,eps0,1e-6,alsv,alproj);
 else
      [zvec,p,q,delta]=intodehankp(p,n,eps0,1e-6,alsv,alproj,delta);
 end
q
costf=norm(q - p);
    
sv=[sv, zvec(end)];
epsval=[eps0];
it=0;
% iterations
while sv(end) > threshold
    it=it+1;

        epsmin=eps0;
        eps0=eps0(end)+ eps0(end)/30;
               
%     disp('integration of ODE')

% disp('freedynamic')
 [zvecf,p,q,deltaf,eps0,timefree]=freeintodehankp(p,n,eps0,1e-8,alsv,alproj,delta);
        timeiter=[timeiter, timefree];
  eps0=eps0*norm(delta);
% if sum(timeiter)>limit
%     ttot=Inf; 
%     relerr=Inf;
%     disp('out of time')
%     return
% end
  
    sv=[sv, zvecf(end)];
    epsval=[epsval, eps0];
    costf=[costf, norm(q-p)];

%      disp('con dynamic')
[zvec,p,q,delta]=intodehankp(p,n,eps0,1e-6,alsv,alproj,deltaf);

      sv=[sv, zvec(end)];

costf=[costf, norm(q - p)];
   
end
 ttot=toc
 relerr=   costf(end)/norm(p);
end