function [y] = fftprodh(M, x)
%FFTPROD matrix vector product with Hankel matrix A*x using fft
[m,n]=size(M);

J=[n:-1:1];
M2=M(:,J);
x2=x(end:-1:1);
y=fftprodt(M2,x2);

    

end

