%%%%%%%%%%%%%%%%%%%%%% 
     clear, close all
 
% % number of different (random) perturbations
 J=10;

 sigma = .1;
      L=[50:50:300];


% % % generate a random signal as output of a system of order n
 n = 5; 
  sys0 = drss(n, 1, 0); 
  
  
 h0=1e-4; %starting step-size ode-method
  for l=1:length(L)
    
   p0 = initial(sys0, rand(n, 1),L(l)); 
 T=length(p0);

for j=1:J
    % perturbed signal 
    pt = randn(T, 1); p = p0 + sigma * pt / norm(pt) * norm(p0);

    %%% run the algorithms
     
     disp('old')
 tic,  [costfold, eps0, p, delta, ph_odeold, epsval, sv, errold] =...
     dist_hfreecon(p, n+1, h0,1,1); %old version 
  told(j,l) = toc;
 eold(j,l)=errold;

 
    disp('gmres')
  tic, [costfgmres, eps0, p, delta, ph_odegmres, epsval, sv,  errgmres] =...
      dist_hfreecon(p, n+1, h0,2,2); %gmres
 tgmres(j,l) = toc;
 egmres(j,l)=errgmres;
 

 s.m = n+1;
 s.n = L(l)+1-n;
 s.w=[[1:n+1],(n+1)*ones(1,L(l)+1-2*n-2),[n+1:-1:1]];
tic, [p_slra, i_slra] = slra(p, s, n); 
tslra(j,l) = toc
e_slra(j,l) = norm(p_slra - p)/norm(p);

    
    disp('svds')
tic,  [costfsvds,eps0,p,delta,ph_odesvds,epsval,sv,errsvds] =...
    dist_hfreecon(p, n+1, h0,1,2); %svds
tsvds(j,l) = toc;
esvds(j,l)=errsvds;

   
    disp('rsvd')
 tic, [costfrsvd, eps0, p, delta, ph_odersvd, epsval, sv,  errrsvd] =...
            dist_hfreecon(p, n+1, h0,7,2); %rsvd
trsvd(j,l) = toc;
ersvd(j,l)=errrsvd;

end
end
% disp('old')
% [ mean(told), mean(eold)]
% disp('svds')
% [mean(tsvds), mean(esvds)]
% disp('gmres')
% [mean(tgmres), mean(egmres)]
% disp('slra')
% [mean(tslra), mean(e_slra)]
%  disp('rsvd')
%  [ mean(trsvd), mean(ersvd)]

