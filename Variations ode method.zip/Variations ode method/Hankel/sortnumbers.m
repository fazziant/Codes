function [vecf,ind] = sortnumbers(vec)
[slam,indx]=mysortcomplex(vec, 0);
L=find(abs(real(slam))<1e-6);
if L
vecreal=[slam(1:L(1)-1); slam(L(end)+1:end)];
vecimag=slam(L(1):L(end));
[slam2,indx2]=mysortcomplex(vecimag,2);
vecf=[slam(1:L(1)-1);slam2;slam(L(end)+1:end)];
I=indx(L);
ind=[indx(1:L(1)-1);I(indx2);indx(L(end)+1:end)];
else
    vecf=slam;
    ind=indx;
end