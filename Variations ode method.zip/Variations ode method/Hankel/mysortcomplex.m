function [slam,indx] = mysortcomplex(lambda, mod)
% sort complex numbers by real part or modulus and break ties with 
% imaginary parts or angles respectively


if mod==1
    % since "sort" sorts complex numbers by modulus, tempting to use
    % [slam,indx] = sort(lambda,'descend'); 
    % but this is a disaster if lambda is real
    [temp,indx] = sort(abs(lambda),'descend'); % sort by modulus
elseif mod==0
     [temp,indx] = sort(real(lambda),'descend'); % sort by real part
% % %      indxaux=indx;
% % %      L=find(abs(temp)<1e-12)
% % %      if L
% % % %          indx(L)
% % % %          lambda(indx)
% % %       [temp2,indx2]=sort(imag(lambda(indx(L))),'descend');
% % %       for i=1:length(L)
% % % %            j=indx2(i)
% % % % %           indx(j) = indx2(i)
% % % %         L(indx2)
% % % %          k=find(indx==L(i));
% % % %          K=find(indx2==L(i));
% % %          kk=find(indx==L(indx2(i)))
% % % %          L(i)
% % % %          k
% % % %          K
% % %          indx
% % %          indx2
% % %          indx(kk)=indxaux(L(i))
% % %          indx(L(i))=indxaux(kk)
% % % %          indx(k)=indxaux(K);
% % % %            indx(indx(k))=indxaux(k)
% % % %             indx(k)=indxaux(indxaux(k))
% % %                indxaux=indx;
% % %                
% % %       end
% % %       
% % %      end
elseif mod==2
     [temp,indx] = sort(imag(lambda),'descend'); % sort by modulus

        
end
slam = lambda(indx);
% break ties by bubble
swapping = 1;
n = length(lambda);
% assuming the applicaton is to sort eigenvalues of dense matrices,
% the overhead for this is negligible 
while swapping % break ties with imaginary parts
    swapping = 0;
    for i=1:n-1
        if (mod & abs(slam(i)) == abs(slam(i+1)) & angle(slam(i)) < angle(slam(i+1))) | ...
         (~mod & real(slam(i)) == real(slam(i+1)) & imag(slam(i)) < imag(slam(i+1)))
            slam([i i+1]) = slam([i+1 i]);
            indx([i i+1]) = indx([i+1 i]);
            swapping = 1;
        end
    end
end
