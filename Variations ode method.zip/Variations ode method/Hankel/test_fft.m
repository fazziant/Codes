ln=1000; %length p

p=randi(5,ln,1);
c=p(1:.6*ln);
r=p(.6*ln:end);

M=hankel(c,r);
[m,n]=size(M);



ct1=[c(n:m);r(2:end)];
rt1=c(n:-1:1);
T1=toeplitz(ct1,rt1);
ch=[ct1; c(1:n-1)];
T2=toeplitz(ch,rt1);
x=randi(10,n,1);
xh=[flip(x);zeros(m-1,1)];
disp('mat-vec product')
tic, M*x; toc
disp('fft product')
tic, ifft(fft(ch).*fft(xh)); toc