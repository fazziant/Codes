function H = Hfftproj(u, v)
% Projection onto Hankel structure based on fft
% u, v are s.t. E = uv^T is the matrix we want to project

if length(u) <= length(v)
L=length(u);
K=length(v);


N=L+K-1;
u2=[u; zeros(N-L,1)];
v2=[v; zeros(N-K,1)];
uh=fft(u2);
vh=fft(v2);

gp=ifft(uh.*vh);
w=[[1:L-1]';L*ones(N-2*L+2,1);[L-1:-1:1]'];

g=gp./w;
g(1:L);
g(L:end);
H=hankel(g(1:L),g(L:end));

else 
aux=u;
 u = v; 
 v = aux;

 L=length(u); 
K=length(v);


N=L+K-1;
u2=[u; zeros(N-L,1)];
v2=[v; zeros(N-K,1)];
uh=fft(u2);
vh=fft(v2);

gp=ifft(uh.*vh);
w=[[1:L]';L*ones(N-2*L,1);[L:-1:1]'];

g=gp./w;
H=hankel(g(1:L),g(L:end));
H=H';
 
end
end