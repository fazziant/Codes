function [zvec,p,q,delta]=intodehankp2(p,n,epsil,h0,alsv,alproj,Sold,delta)
% enforce the descent direction by additional convergence constraint
%%%%%%% output 
% zvec = smallest singular value H(q)
% p= starting time series
% q = p + epsilon * delta
% delta = Perturbation 

%%%%%%%%%%%%  input
% p = starting time series
% n = model order
% epsil: scalar parameter of the perturbation epsilon * E
% h0 = starting value of the step in Euler method
% alsv = algorithm for singular triplet
% alproj = algorithm for projection
% delta = perturbation (optional)
  
format short
tol=1e-6;
h=h0;
hmin=1e-12;
countmax=40;
gamma=1.2;%2;


% Initialization
k=1;
if nargin < 8

    delta=zeros(length(p),1);
    q=p; %+epsil*delta
    B=hankel(q(1:n),q(n:end));
  
 if alsv==1
    [y,sigma,x]=svds(B,1,'smallest');

     z = sigma(end);
     
 elseif alsv==2
       [Y,sigma,X]=svd(B);
     y=Y(:,n);
     x=X(:,n);
     z = sigma(n,n);
     
  elseif alsv==7
     D=hankel(q(1:n+5),q(n+5:end));
     [Y,S,X] = rsvd(D,n);
     z=S(n,n);
     y=Y(:,n);
      x=X(:,n);
 end
   xT=x';
 if alproj==1
         E=-(y*xT);                
         E=Hproj(E);
        else
        E=-Hfftproj(y,x);
        end
     
    delta=[E(:,1);E(end,2:end).'];
    delta=delta/norm(delta);

%   starting matrix   
    q=p+epsil*delta;
    B=hankel(q(1:n),q(n:end));
   
if alsv==1
    [y,sigma,x]=svds(B,1,'smallest');
     z = sigma(end);
     
 elseif alsv==2
     for j=1:n
    C(:,j)=fftprodh(B,B(j,:)');
     end
   Baux=[C, y; y', 0];
    c =[zeros(n,1); 1];
    X=gmres(Baux,c,[],1e-4);
    
    y=X(1:n)/norm(X(1:n));
    z=abs(X(n+1))/norm(X(1:n));
    x=fftprodh(B',y);
    x=x/norm(x);
        
   elseif alsv==7
     D=hankel(q(1:n+5),q(n+5:end));
     [Y,S,X] = rsvd(D,n);
     z=S(n,n);
     y=Y(:,n);
      x=X(:,n);
    
 end
 xT=x';

    zvec(k)=z;
    if alproj==1
     Edot=-(y*xT);                      
     Edot=Hproj(Edot);
    else
      Edot=-Hfftproj(y, x);
    end

    deltadot=[Edot(:,1);Edot(end,2:end).'];
     deltadot = deltadot - trace(deltadot'*delta)*delta;
    deltadot=deltadot./norm(deltadot);

else

   format long

    q=p+epsil*delta;
    B=hankel(q(1:n),q(n:end));
   
 if alsv==1
    [y,sigma,x]=svds(B,1,'smallest');
     z = sigma(end);
     
 elseif alsv==2
       [Y,sigma,X]=svd(B);
     y=Y(:,n);
     x=X(:,n);

     z = sigma(n,n);

  elseif alsv==7
     D=hankel(q(1:n+5),q(n+5:end));
     [Y,S,X] = rsvd(D,n);
     z=S(n,n);
     y=Y(:,n);
      x=X(:,n);
   
 end
xT=x';
     
    zvec(k)=z;
     if alproj==1
     Edot=-(y*xT);                         
    Edot=Hproj(Edot);
     else
      Edot=-Hfftproj(y,x);
     end

    deltadot=[Edot(:,1);Edot(end,2:end).'];
    deltadot=deltadot - trace(deltadot.'*delta).*delta;
    deltadot=deltadot/norm(deltadot);
    
end

deltaold=delta;

while h>hmin
z=zvec(k);
count=0;
  while count<=countmax
    count=count+1;
    q=p+epsil*delta;
    B=hankel(q(1:n),q(n:end));
  
    
if alsv==1
    [y,sigma,x]=svds(B,1,'smallest');
     z = sigma(end);
     
 elseif alsv==2
      for j=1:n
    C(:,j)=fftprodh(B,B(j,:)');
     end
   Baux=[C, y; y', 0];
    c =[zeros(n,1); 1];
    X=gmres(Baux,c,[],1e-4);
    
    y=X(1:n)/norm(X(1:n));
    z=abs(X(n+1))/norm(X(1:n));
    x=fftprodh(B',y);
    x=x/norm(x);
     
 elseif alsv==7
     D=hankel(q(1:n+5),q(n+5:end));
     [Y,S,X] = rsvd(D,n);
     z=S(n,n);
     y=Y(:,n);
      x=X(:,n);
 end
    if abs(z)<=abs(zvec(k))
        if alproj==1
         Edot=-(y*xT);                
         Edot=Hproj(Edot);
        else
            
         Edot=-Hfftproj(y, x);
        end

        deltadot=[Edot(:,1);Edot(end,2:end).'];
         deltadot=deltadot - trace(deltadot'*delta)*delta;
        deltadot=deltadot./norm(deltadot);

        k=k+1;
        zvec(k)=z;
        deltaold=delta;
        break
    else
      
        h=h/gamma;
        delta=deltaold+h*deltadot;
        delta=delta/norm(delta);

    end
end

if count==1
    h=h*gamma;
end
if count==countmax+1
   disp('maximum number of its reached in while loop cons')
    return
end

% Error control
if k>1
    if abs(zvec(k)) > abs(zvec(k-1))
        disp('monotonicity broken');
       pause
    end
    if abs(zvec(k)) <= 1e-6
       disp('matrix looks singular');
        return
    end
    if (abs(zvec(k)-zvec(k-1)) <= 1e-6) && (abs(zvec(k) <=Sold)
        disp('reached tolerance');
        return
     end
end

% Euler step
delta=deltaold+h*deltadot; 
delta=delta/norm(delta);

end
end