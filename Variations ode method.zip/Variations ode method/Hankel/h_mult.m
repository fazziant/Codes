function  z= h_mult(fft_p_ext, x)
  n_ext = length(fft_p_ext);
  n = length(x);
  x_ext = [x; zeros(n_ext-n,1)];
  z_ext = ifft(conj(conj(fft_p_ext) .* fft(x_ext)));
  z = z_ext(1:n);
end
