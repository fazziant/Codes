function [zvec,x, y,A,B,E]=controlodematord2t(P,dim,deg,epsil,w,h0,E)
%%%%metodo trapezi   
%%% work for normal transpose
%%%%%%% output 
% zvec = smallest singular value
% x = left eigenvector of B^T B associated to the smallest eigenvalue
% y = B*x
% A = Sylvester matrix associated to the starting polynomials
% B = A + epsilon * E
% E = Perturbation matrix

%%%%%%%%%%%%  input
% P = matrix containing the data polynomials
% deg is the degree of the GCD
% epsil: scalar parameter of the perturbation epsilon * E
% h0 = starting value of the step in Euler method
% E = perturbation matrix
 
%w=(size(P,2)/dim-1)*(1+dim);
% w=3;
format short
%zeroval=1e-14;
tol=1e-14;
h=h0;
hmin=1e-14;
countmax=40;
gamma=1.25;


mP=size(P,1)/dim;
nP=size(P,2)/dim;
%p=n;


P1=P(1:dim,:);
P2=P(dim+1:end,:);
A=[blktoep(P1,1,w); blktoep(P2,1,w)];
[mA,nA]=size(A);

% Initialization
k=1;
if nargin < 7
    E=zeros(mA,nA);
    B=A+epsil*E;
    %[z, x, y, f] = geteigvecs(A, 1, epsil, zeros(d,1), zeros(d,1), 1, esel);
%     [evec,lambda]=eig(B'*B);
%     x=evec(:,deg*dim);
     [U,Sigma,V]=svd(B);
     format long
     sigma=diag(Sigma);
     x=V(:,end+1-dim*deg);
     y=U(:,size(V,2)+1-dim*deg);
     z = sigma(end+1-dim*deg);
 %    z=sqrt(real(lambda(deg*dim,deg*dim)));
%     y=U(:,end);
%     x=V(:,end);
    
    E=-(y*x');                           %%%%%%%  diviso per z
    E=newproj(E,nP-1,dim,w+1);
    E=E/norm(E,'fro');

%   starting matrix   
%   starting matrix   
    B=A+epsil*E;
   
     [U,Sigma,V]=svd(B);
     format long
     sigma=diag(Sigma);
     x=V(:,end+1-dim*deg);
     y=U(:,size(V,2)+1-dim*deg);
     z = sigma(end+1-dim*deg);

    
    zvec(k)=z;
    K1=-(y*x');                    %%%%%%%%%%%%%%%%%%%diviso per z
    K1=newproj(K1,nP-1,dim,w+1);
    K1=K1- (trace(K1'*E))*E;
    K1=K1/norm(K1,'fro');
    
        E2=E+h/2*K1;
        E2=E2/norm(E2,'fro');
        B2=A+epsil*E2; 
    
   
      [U2,Sigma2,V2]=svd(B2);
     format long
     sigma2=diag(Sigma2);
     x2=V2(:,end+1-dim*deg);
     y2=U2(:,size(V2,2)+1-dim*deg);
     z2 = sigma2(end+1-dim*deg);
     

     
       K2=-(y2*x2');                  %%%%%%%%% diviso per z
        K2=newproj(K2,nP-1,dim,w+1);
        K2=K2-(trace(K2'*E2))*E2;
        K2=K2/norm(K2,'fro');
    
     Edot=(1/2)*(K1+K2);
     Edot=Edot/norm(Edot,'fro');
     
else
    E=newproj(real(E),nP-1,dim,w+1);
    E=E/norm(E,'fro');
    B=A+epsil*E;
  
     [U,Sigma,V]=svd(B);
     format long
     sigma=diag(Sigma);
     x=V(:,end+1-dim*deg);
     y=U(:,size(V,2)+1-dim*deg);
     z = sigma(end+1-dim*deg);

  
    zvec(k)=z;
   K1=-(y*x');                    %%%%%%%%%%%%%%%%%%%diviso per z
    K1=newproj(K1,nP-1,dim,w+1);
    K1=K1- (trace(K1'*E))*E;
    K1=K1/norm(K1,'fro');
    
        E2=E+h/2*K1;
        E2=E2/norm(E2,'fro');
        B2=A+epsil*E2; 
       % [z, x, y, f] = geteigvecs(B, 1, epsil, zeros(d,1), zeros(d,1), 1, esel);
   
      [U2,Sigma2,V2]=svd(B2);
     format long
     sigma2=diag(Sigma2);
     x2=V2(:,end+1-dim*deg);
     y2=U2(:,size(V2,2)+1-dim*deg);
     z2 = sigma2(end+1-dim*deg);
    

     
       K2=-(y2*x2');                  %%%%%%%%% diviso per z
        K2=newproj(K2,nP-1,dim,w+1);
        K2=K2-(trace(K2'*E2))*E2;
        K2=K2/norm(K2,'fro');
    
     Edot=(1/2)*(K1+K2);
     Edot=Edot/norm(Edot,'fro');
       
end

Eold=E;

while h>hmin
% Leading eigenvectors
z=zvec(k);
count=0;
  while count<=countmax
    count=count+1;
    B=A+epsil*E;
  
     [U,Sigma,V]=svd(B);
     format long
     sigma=diag(Sigma);
     x=V(:,end+1-dim*deg);
     y=U(:,size(V,2)+1-dim*deg);
     z = sigma(end+1-dim*deg);

    

    if abs(z)<abs(zvec(k))
       K1=-(y*x');                    %%%%%%%%%%%%%%%%%%%diviso per z
    K1=newproj(K1,nP-1,dim,w+1);
    K1=K1- (trace(K1'*E))*E;
    K1=K1/norm(K1,'fro');
    
        E2=E+h/2*K1;
        E2=E2/norm(E2,'fro');
        B2=A+epsil*E2; 
       % [z, x, y, f] = geteigvecs(B, 1, epsil, zeros(d,1), zeros(d,1), 1, esel);
   
      [U2,Sigma2,V2]=svd(B2);
     format long
     sigma2=diag(Sigma2);
     x2=V2(:,end+1-dim*deg);
     y2=U2(:,size(V2,2)+1-dim*deg);
     z2 = sigma2(end+1-dim*deg);

     
       K2=-(y2*x2');                  %%%%%%%%% diviso per z
        K2=newproj(K2,nP-1,dim,w+1);
        K2=K2-(trace(K2'*E2))*E2;
        K2=K2/norm(K2,'fro');
    
     Edot=(1/2)*(K1+K2);
     Edot=Edot/norm(Edot,'fro');
      
        
        k=k+1;
        zvec(k)=z;
        Eold=E;
        break
    else
        h=h/gamma;
        E=Eold+h*Edot;
        E=E/norm(E,'fro');
    end
end
%  count
%  nstep
if count==1
    h=h*gamma;
end
if count==countmax+1
%   disp('maximum number of its reached in while loop')
    return
end
% Edot=Edot-real(trace(Edot'*E))*E;

% Error control
if k>1
    if abs(zvec(k)) > abs(zvec(k-1))
        disp('monotonicity broken');
       pause
    end
    if abs(zvec(k)) <= tol
       disp('matrix looks singular');
        return
    end
    if abs(abs(zvec(k)-zvec(k-1)) <= tol) 
        disp('reached tolerance');
        return
    end
end

% trapezi
E=Eold+h*Edot; 
E=E/norm(E,'fro');
%psr=(zvec(end));

end