function [sv,dist,eps0,A,E,Phat,epsval ] = dist_uncontrgen(P,deg,tol,itmax,output,E )
%   estimates distance to uncontrollability

% default
if nargin<5
    output=0;
end
if nargin<4
    itmax=40;
end

h0=1e-4;
threshold=1e-12;
c=0.5;
epsval=[];

[mP,nP]=size(P);
n=nP-1;

%construction of A
A=readpol(P);
[mA,nA]=size(A);
sigma=svd(A);
sv=[sigma(end+1-deg)];

if output==1
    A
    pause(3)
end

% estimate interval for distance
epsmin=sv(1);    %prova
%epsmax=norm(pol1+pol2+pol3,'fro');   %prova
 epsmax=norm(A,'fro');
eps0=min(2*epsmin,(epsmin+epsmax)/2);

% eps0=epsmin;
% [epsmin,epsmax,eps0]
% pause



[zvec,x,y,A,B,E]=controlodegen(P,deg,eps0,h0);
 %[zvec,x,y,A,B,E]=controlode3ord2mp(pol1,pol2,pol3,eps0,h0);
% [zvec,x,y,A,B,E]=controlodeord2t(P,deg,eps0,h0);
sv=[sv, zvec(end)];
for it=1:itmax
    
    epsval(it)=eps0;
    if output==1
        format short e
        [it,epsmin,epsmax,eps0,abs(zvec(end))];
%       pause
    end
    abs(zvec(end))
    
    %if abs(zvec(end)) > threshold
    if abs(sv(end)) > threshold 
%       Eold=E;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%era commentato
   %%%%% Newton's method
        epsmin=eps0;
       %S=Sprojgen(2.*y*x',n,p);
       %drho=(-y'*(-S + trace(S'*E).*E )*x); 
       
       
%        [evec,lambda]=eig(B'*B);
%     x=evec(:,deg);
%     y=B*x;
%     z=sqrt(real(lambda(deg,deg)));
%      Sigma=svd(B); 
%     z=Sigma(end+1-deg);

[U,Sigma,V]=svd(B);
   z = Sigma(nA+1-deg,nA+1-deg);
   x=V(:,end+1-deg);
   x=x/norm(x);
   y=U(:,size(V,2)+1-deg); 
   y=y/norm(y);
  
    
         drho=norm(Sprojgen((y*x'),nP-1,mP),'fro');
         eps1=eps0+ (z/drho)
%             eps1=eps0+.01
        % [epsval, eps1]
        %eps1=(epsmin+epsmax)/2;

% %      %%%%  bisection
% %         epsmin=eps0;
% %         eps1=(epsmin + epsmax)/2;


% % %         epsmin=eps0;
% % %         delta=(epsmax-epsmin)/9;
% % %         epsilon=[epsmin:delta:epsmax];
% % %          eps11=epsmin;eps12=epsmax; 
% % %          %%%eps13=.2*epsmin + .8*epsmax;  eps14=.8*epsmin + .2*epsmax;
% % %          lambda11=min(svd(A + eps11*E)); lambda12=min(svd(A+eps12*E));
% % %       %%%lambda13=min(svd(A + eps13*E)); lambda14=min(svd(A+eps14*E));
% % %          inteps=interp1([eps11, eps12], [lambda11, lambda12], epsilon, 'pchip');
% % %          xx=find(inteps>0);  xy=min(epsilon(xx)); xz=find(epsilon==xy);
% % %          eps1=epsilon(xz);
         
         
% %         epsmin=eps0;
% %         delta=(epsmax-epsmin)/9;
% %         epsilon=[epsmin:delta:epsmax];
% %          eps11=epsmin;eps12=epsmax;eps13=.1*epsmin+.9*epsmax;eps14=.2*epsmin+.8*epsmax;% eps11, eps12, eps13, eps14
% %          lambda11=min(svd(A + eps11*E)); lambda12=min(svd(A+eps12*E));lambda13=min(svd(A+eps13*E));
% %          lambda14=min(svd(A+eps14*E));
% %          parab=polyfit([eps11,eps12,eps13,eps14],[lambda11,lambda12,lambda13,lambda14],3); %parab
% %          inteps=polyval(parab,epsilon); %plot(inteps)
% %          [val,index]=min(inteps); eps1=epsilon(index);


%primo coeff pol int viene 0
% % % % %        epsmin=eps0;
% % % % %        B1=A+epsmin*E;                                   B2=A+epsmax*E;
% % % % %        [evec1,lambda1]=eig(B1'*B1);                      [evec2,lambda2]=eig(B2'*B2); 
% % % % %        x1=evec1(:,1);                                    x2=evec2(:,1);
% % % % %        y1=B1*x1;                                         y2=B2*x2;
% % % % %        
% % % % %        z1=min(svd(B1));                                  z2=min(svd(B2));
% % % % %        deriv1=-norm(Sprojgen((y1*x1'),n,p),'fro')/z1;    deriv2=-norm(Sprojgen((y2*x2'),n,p),'fro')/z2;
% % % % %        
% % % % %        Matrix=[1 0 0 0; 1 1 1 1; 0 1 0 0; 0 1 2 3];
% % % % %        intp=Matrix\[z1;z2;deriv1; deriv2]; intp
% % % % %        
% % % % %        delta=(epsmax-epsmin)/19;
% % % % %        epsilon=[epsmin:delta:epsmax];
% % % % %        inteps=polyval(intp,epsilon); %plot(inteps)
% % % % %        [val,index]=min(inteps); eps1=epsilon(index);
       
       
          
        
        if eps1>epsmin & eps1<epsmax
            if abs(eps1-eps0)<tol 
                eps0=eps1;
                break
            else
                eps0=eps1;
            end
        else
            eps0=(1-c)*epsmin+c*epsmax;
        end
    else
        disp('bisection step'), it
        epsmax=eps0;
        eps0=(1-c)*epsmin+c*epsmax;
        Eold=E; %%%%%%%%%%%%%%%%%%%%%%%%%%%%%era E=Eold
    end
    zvec=[];
    Eold=E;
    disp('integration of ODE')
    if it >= 1
        [zvec,x,y,A,B,E]=controlodegen(P,deg,eps0,h0,E);
         %[zvec,x,y,A,B,E]=controlode3ord2mp(pol1,pol2,pol3,eps0,h0,E);
       %  [zvec,x,y,A,B,E]=controlodeord2t(P,deg,eps0,h0,E);
    else
        [zvec,x,y,A,B,E]=controlodegen(P,deg,eps0,h0);
    end
    disp('completed')
    sv=[sv, zvec(end)]
%    if epsmax-epsmin<tol
%        break
%    end

end
it
% format long
% zvec

% this is the computed distance;
ddd=[];
for k=1:mP
    ddd=[ddd, E(1+(k-1)*n, :)];
end
dist=eps0*norm(ddd,'fro');
B=A+eps0*E;
Phat(1,:)=B(1,1:n+1); 
for k=2:mP
Phat(k,:)=B((k-1)*n+1,nP-1:end); 
end
end