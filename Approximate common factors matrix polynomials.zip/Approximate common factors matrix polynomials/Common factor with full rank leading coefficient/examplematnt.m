function [dist, Phat, C]=examplematnt(P,dim,deg)
% clear 
% close all

 
%  load datamod2
%  load pert
%  P=[P1;P2];
% %P(1,1)=P(1,1)+.001;
% % %P(1,1)=P(1,2)+.001;
% %P=P+ones(size(P))./10;
% % %P=P+ones(size(P))./1000;
% % %P=P+randn(size(P))./10;
%  P=P+pert;
%  deg=1;
%  dim=2;



%  load data6
% load pert
%  P=[P1;P2];
% P(1,1)=P(1,1)+.001;
% P=P+ones(size(P))./100;
% P=P+randn(size(P))./10;
% P=P+pert;
%  deg=1;
%  dim=2;

% load data9
% P=[P1;P2];
% %P(1,1)=P(1,1)+.001;
% %P=P+ones(size(P))./10;
% %P=P+randn(size(P))./10;
% deg=1;
% dim=2;

% load data10
% P=[P1;P2];
% %P(1,1)=P(1,1)+.001;
% %%%P=P+ones(size(P))./100;
% P=P+randn(size(P))./100;
% deg=1;
% dim=2;

% load datamod
% P=[P1;P2];
% %P(1,1)=P(1,1)+.001;
% %P=P+ones(size(P))./100;
%   Q=randn(size(P))./100;
% % Q=[-0.006305150328285   0.003024074165377  -0.000505312775256  -0.005707643089998   0.007768417982070   0.003946755315683   0.001537707410908   0.008967452879338;
% %    0.006096250911813   0.000583198538886  -0.017557750407286   0.004942333759531   -0.022598403515310   0.000048544237189  -0.007586271567433   0.004123077020405;
% %    0.007823349704989  -0.005741339623937  -0.002573576235820   0.009914404388253    -0.005643766911304   0.004369186280282  -0.001801630971233   0.005475196872295;
% %    0.024365843580758  -0.001952124010511   0.007495418853711   0.010771401134342   0.009014914350929   0.011300727199967  -0.002077895861080   0.001478350435490];
% 
% 
%   
% P=P+Q;
% deg=1;
% dim1=2;
% dim2=2;
% dim=min([dim1,dim2]);


% P=examplematsum
% deg=1;
% dim=2;

% P=[1,2,3,4,5,1;
%     1,2,3,2,3,1];
% deg=1;
% dim1=1;
% dim2=2;

% dP = 3; d = 1; m = 2; n = 2;
% % % % [M, ph,C0] = mat_agcd_antonio(p,dim, d);
% C0 = [eye(m); rand(m*d,m)]';
% P0 = [];
% dA = dP - d;
% A0 = rand(m * (dA + 1), m*n)';
% P0 = (A0*blktoep(C0, m, dA) );
%  P = P0 + .0 * randn(size(P0));
% P1=P(1:m,:);
% P2=P(m+1:end,:);
% dim=m;
% deg=d;



% % % w=(size(P,2)/dim-1)*(1+dim);
% % % w=w-size(P,2)+dim;
% % % size(P,2)
% % % dim
w=size(P,2)/dim+1;
 
% % w=5;

%       [dist,eps0,A,E,Phat,epsval,sval ] = dist_uncontrmatnt(P,dim,deg,1e-6,w);
    [dist,eps0,A,E,Phat,epsval,sval ] = dist_uncontrmatntfreecon(P,dim,deg,1e-6,w);
% epsval
% A
% E
%spy(E)
% A+epsval(end)*E;
% if sval(end) > sval(end-1)
%     sval=sval(1:end-1);
% end
format long


%disp('estimated distance to uncontrollability'), [dist,eps0]

%disp('perturbed polynomials, phat constrained to be monic')
P
Phat
P-Phat
%norm(P-Phat)
dist=norm(P-Phat,'fro');
degpol=size(P,2)/dim-1
Prev1=zeros(size(P,1)/2,size(P,2));
Prev2=zeros(size(P,1)/2, size(P,2));
for i=1:degpol+1
    Prev1(:,2*i-1:2*i)=Phat(1:dim,end-2*i+1:end-2*i+2);
    Prev2(:,2*i-1:2*i)=Phat(dim+1:end,end-2*i+1:end-2*i+2);
end
A1=ppck(Prev1,degpol) 
A2=ppck(Prev2,degpol) 
% A1=ppck(Phat(1:2,:),degpol) 
% A2=ppck(Phat(3:4,:),degpol) 
  GCDr=grd(A1,A2,'t',1e-4)
  GCDr=grd(A1,A2,'t',1e-3)
  GCDr=grd(A1,A2,'t',1e-2)
%GCDr=grd(A1,A2,'t',1e-1,'z',1e-6)
grd(A1,A2,'t',1e-1)
gcd=mygrd(A1,A2)

% if size(gcd,2)>3 && rank(gcd(1:2,3:4))==2
%    C=gcd;
% else
%   C=grd(A1,A2,'t',1e-1);
% end

C1=grd(A1,A2)

% q=mat2cell(Phat,dim*ones(1,2),dim*ones(1,degpol+1));
% q=q';
% % q={{q{1,:}},{q{2,:}}}
% q=cell2mat(q);
C=alcf_ss(Phat',dim,deg)
%GCDl=gld(A1,A2,'t',1e-2);
% svd(readmatpol(P,2))
% svd(readmatpol(Phat,2))

svd([blktoep(P(1:dim,:),1,w); blktoep(P(dim+1:end,:),1,w)])
svd(A)
svd([blktoep(Phat(1:dim,:),1,w); blktoep(Phat(dim+1:end,:),1,w)])
 proots(A1)
 proots(A2)
%  det1=pdet(ppck(Prev1,degpol)); det1=det1(1,end-1:-1:1)
%  det2=pdet(ppck(Prev2,degpol)); det2=det2(1,end-1:-1:1)
% roots(det1)
% roots(det2)
  epsval
   sval
% % %scatter(epsval,sval)
% % semilogy(sval)
% % %  semilogy(epsval,sval)
% % 
% % % scatter(sval, epsval)
% % % set(gca,'xscale','log')
% % epsval
% Q
   semilogy(sval)