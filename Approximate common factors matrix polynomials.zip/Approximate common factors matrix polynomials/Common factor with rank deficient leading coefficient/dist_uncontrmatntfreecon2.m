function [ dist,eps0,A,E,Phat,epsval,sval ] = dist_uncontrmatntfreecon2(P,dim,deg,tol,w,itmax)

%w=2;
% default

if nargin<6
    itmax=40;
end

h0=1e-6;
threshold=1e-6;
c=0.5;
epsval=[];
sval=[];

mP=size(P,1)/dim;
nP=size(P,2)/dim;
n=nP-1;
% w=n*(1+dim)-2;

%construction of A
%A=readmatpol(P,dim);
P1=P(1:dim,:);
P2=P(dim+1:end,:);
A=[blktoep(P1,1,w); blktoep(P2,1,w)];
[mA,nA]=size(A);



% estimate interval for distance
S=svd(A);
sval=S(end+1-dim*deg);
epsmin=1e-3;%sval(1);   %prova

 epsmax=norm(A,'fro');
 %epsmax=sqrt(deg)*norm(P1-P2,'fro')
eps0=min(2*epsmin,(epsmin+epsmax)/2);
% eps0=epsmin;
% [epsmin,epsmax,eps0]
% pause



 [zvec,x,y,A,B,E]=controlodematnt(P,dim,deg,eps0,w,h0);

%
%

   sval=[sval, zvec(end)];

%      it=0;
    for it=1:itmax
%   while sval(end) > threshold
%        it=it+1;
      epsval(it)=eps0;

    
         if (sval(end)) > threshold
      bisec=0;
%    %%%%% Newton's method
         epsmin=eps0;

     [U,Sigma,V]=svd(B);
     sigma=diag(Sigma);
     l=length(sigma);
% %      
          x=V(:,l+1-dim*deg);
     y=U(:,l+1-dim*deg);
    xT=x';
%   
      z = sigma(end+1-dim*deg); 
    
         drho=norm(newproj((y*xT),nP-1,dim,w+1),'fro');
%          
         %%%%%%%   Newton
                    eps1=eps0+ (z/drho);
%            
%      %%%%%%%%%%%%  add a constant      
%            eps1=eps0+.01;
%    

%    
 
        if eps1>epsmin & eps1<epsmax
            if abs(eps1-eps0)<tol 
                disp('got epsilon star')
                eps0=eps1;
                break
            else
                eps0=eps1;
            end
        else
            disp('out of the interval')
%              pause
            eps0=(1-c)*epsmin+c*epsmax;
        end
    else
        disp('bisection step'), it
        bisec=1;
        epsmax=eps0;
        eps0=(1-c)*epsmin+c*epsmax;
%         if abs(epsmax-eps0)<tol
%             break
%         end
        Eold=E; %%%%%%%%%%%%%%%%%%%%%%%%%%%%%era E=Eold
    end
% % [epsmin, epsmax]
% % pause
% %     Eold=E;
    disp('integration of ODE')
 if eps0>epsval(end) %&& it >1
   
    disp('freedyn')
 [zvecf,xf,yf,Af,Bf,Ef]=controlodematntfree(P,dim,deg,epsval(end),eps0,w,h0,epsval(end)/eps0*E);
%%%%%%%  correction on epsilon
  eps2=eps0*norm(Ef,'fro');
  if eps2>eps0
      eps0=eps2;
  end
  sval=[sval, zvecf(end)];

 disp('condyn')
 [zvec,x,y,A,B,E]=controlodematnt(P,dim,deg,eps0,w,h0,Ef);
 sval=[sval, zvec(end)];
 
 else

     
    disp('condyn')
 [zvec,x,y,A,B,E]=controlodematnt(P,dim,deg,eps0,w,h0,E);
 sval=[sval, zvec(end)];
%  if sval(end) > threshold
%       disp('freedyn')
%       if eps0>1
%    [zvecf,xf,yf,Af,Bf,Ef]=controlodematntfree(P,dim,deg,1,eps0,w,h0,1/eps0*E);
%       else
%          [zvecf,xf,yf,Af,Bf,Ef]=controlodematntfree(P,dim,deg,1e-2,eps0,w,h0,eps0*E); 
%       end
%    sval=[sval, zvecf(end)];
%    eps0=eps0*norm(Ef,'fro');
%     disp('condyn')
%  [zvec,x,y,A,B,E]=controlodematnt(P,dim,deg,eps0,w,h0,Ef);
%  sval=[sval, zvec(end)];
%  end
     
end
disp('completed')
   end
% format long
% zvec
% 
% this is the computed distance;
% 
% S1 = max(svd(A));
% S2=  max(svd(B));
% dist = S1-S2;
B=A+eps0*E;
Phat(1:dim,:)=B(1:dim,1:dim*(n+1)); 

Phat(dim+1:2*dim,:)=B(size(B,1)/2+1:size(B,1)/2+dim,1:dim*(n+1)); % 2 is the half not the dimension
dist=norm(Phat-P,'fro');
end