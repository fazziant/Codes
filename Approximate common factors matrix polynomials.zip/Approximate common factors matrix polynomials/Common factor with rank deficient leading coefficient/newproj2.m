function S = newproj(E,n,dim1,dim2,w)
% Projection onto Sylvester structure
% E is the matrix we want to project
% n is the degree of the polynomials
% dim is the dimension of the coefficients (assumed square matrices)





for i=1:n+1
    P(1:dim1,i*dim2-1:i*dim2)=0;
    P(dim1+1:2*dim1, i*dim2-1:i*dim2) = 0;
    for j=1:w+1
        P(1:dim1,i*dim2-1:i*dim2)=P(1:dim1,i*dim2-1:i*dim2)+E(dim1*(j-1)+1:j*dim1,dim1*(j-1)+1+(i-1)*dim2:dim1*(j-1)+1+dim2-1+(i-1)*dim2);
    %%  P(1:dim1,i*dim2-1:i*dim2)=P(1:dim1,i*dim2-1:i*dim2)+E(j*dim1-1:j*dim1,j*dim2-1+(i-1)*dim2:j*dim2+(i-1)*dim2);
      P(1+dim1:2*dim1,i*dim2-1:i*dim2)=P(1+dim1:2*dim1,i*dim2-1:i*dim2)+E(dim1*(w+1)+dim1*(j-1)+1:dim1*(w+1)+j*dim1,dim1*(j-1)+1+(i-1)*dim2:dim1*(j-1)+1+dim2-1+(i-1)*dim2);
   
    end
    P(1:dim1,i*dim2-1:i*dim2)=P(1:dim1,i*dim2-1:i*dim2)./w+1;
    P(1+dim1:2*dim1,i*dim2-1:i*dim2)=P(1+dim1:2*dim1,i*dim2-1:i*dim2)./w+1;
end
P1=P(1:dim1,:);
P2=P(dim1+1:end,:);
S=[blktoep(P1,1,w); blktoep(P2,1,w)];


% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % patterns of variable parameters, example
% % p(2)=0; p(4)=0; p(6)=0; q(2)=0; q(4)=0; q(6)=0;
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% for i=1:n
%     S(i,:)   = [zeros(1,i-1),P(1,:),zeros(1,n-i)];
% end
% for k=2:m
% for i=1:n
%     S((k-1)*n+i,:) = [zeros(1,n-i),P(k,:),zeros(1,i-1)];
% end
% end
