function Edot = equation(A,epsil,dim,deg,nP,w,E)
%EQUATION Summary of this function goes here
%   Detailed explanation goes here
B=A+epsil*E;

     [U,Sigma,V]=svd(B);
     format long
     sigma=diag(Sigma);
     l=length(sigma);
     
     x=V(:,l+1-dim*deg);
     y=U(:,l+1-dim*deg);
     xT=x';
     
     
    

    
   
%     Edot=-(y*xT);                    %%%%%%%%%%%%%%%%%%%diviso per z
%     
%     Edot=newproj(Edot,nP-1,dim,w+1);
%     Edot=Edot- (trace(Edot'*E))*E;
%     Edot=Edot/norm(Edot,'fro');

end

