function [ dist,eps0,A,E,Phat,epsval ] = mydist(P,dim,deg,tol,itmax,output,E )
%   estimates distance to uncontrollability

% default
if nargin<6
    output=0;
end
if nargin<5
    itmax=100;
end

h0=1e-10;
threshold=1e-14;
c=0.5;
epsval=[];

mP=size(P,1)/dim;
nP=size(P,2)/dim;
n=nP-1;

%construction of A
A=readmatpol(P,dim);
[mA,nA]=size(A);
svd(A)

if output==1
    A
    pause(3)
end

% estimate interval for distance
S=svd(A);
epsmin=S(end+1-dim*deg);    %prova
%epsmax=norm(pol1+pol2+pol3,'fro');   %prova
 epsmax=norm(A,'fro');
eps0=min(2*epsmin,(epsmin+epsmax)/2);
% eps0=epsmin;
% [epsmin,epsmax,eps0]
% pause



[zvec,x,y,A,B,E]=controlodematnt(P,dim,deg,eps0,h0);
% [zvec,x,y,A,B,E]=controlodematord2mp(P,dim,deg,eps0,h0);
% [zvec,x,y,A,B,E]=controlodematord2t(P,dim,deg,eps0,h0);

for it=1:itmax
    
    epsval(it)=eps0;
    if output==1
        format short e
        [it,epsmin,epsmax,eps0,abs(zvec(end))];
%       pause
    end
    abs(zvec(end));
    if (zvec(end)) > threshold
%       Eold=E;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%era commentato
% % %    %%%%% Newton's method
% % %         epsmin=eps0;
% % %        %S=Sprojgen(2.*y*x',n,p);
% % %        %drho=(-y'*(-S + trace(S'*E).*E )*x); 
% % %        
% % %        
% % %      %     [evec,lambda]=eig(B'*B);
% % % %     x=evec(:,deg*dim);
% % %      [U,Sigma,V]=svd(B);
% % %      sigma=diag(Sigma);
% % % %      
% % %           x=V(:,end+1-dim*deg);
% % %      y=U(:,size(V,2)+1-dim*deg);
% % %     xT=x';
% % %      
% % % %      x=V(:,end+1-dim*deg:end+2-dim*deg);
% % % %      y=U(:,size(V,2)+1-dim*deg:end+2-dim*deg);
% % % %     xT=x';
% % %      
% % % %      for i=1:size(x,1)/2
% % % %        xx(:,:,i)=x(2*i-1:2*i,:);
% % % %       yy{i}=xx(:,:,i);
% % % %      end
% % % %      xT=cell2mat(yy);
% % %      
% % %     % y=B*x;
% % %      z = sigma(end+1-dim*deg); 
% % %  %    z=sqrt(real(lambda(deg*dim,deg*dim)));
% % %     
% % %     
% % %          drho=norm(Sprojgenmat((y*xT),nP-1,dim),'fro');
% % %          eps1=eps0+ (z/drho);
% % %          svd(A+eps1*E)
% % %         %eps1=(epsmin+epsmax)/2;

%%%%%%%%%%%%  second Newton method
epsmin=eps0;

     [U,Sigma,V]=svd(B);
     sigma=diag(Sigma);
%      
          x2=V(:,end+1-dim*deg);
     y2=U(:,size(V,2)+1-dim*deg);
    x2T=x2';
    z2 = sigma(end+1-dim*deg); 
    drho2=norm(Sprojgenmat((y2*x2T),nP-1,dim),'fro');
     
     x1=V(:,end+1-dim*deg:end+2-dim*deg);
     y1=U(:,size(V,2)+1-dim*deg:end+2-dim*deg);
    x1T=x1';
    z1 = sigma(end+2-dim*deg); 
    drho1=norm(Sprojgenmat((y1*x1T),nP-1,dim),'fro');
    
    det=z1*z2;
    derivdet=drho2*z1 + drho1*z2;
    eps1= eps0 + det/derivdet;


%      %%%%  bisection
%         epsmin=eps0;
%         eps1=(epsmin + epsmax)/2;

     
% % %         epsmin=eps0;
% % %         delta=(epsmax-epsmin)/9;
% % %         epsilon=[epsmin:delta:epsmax];
% % %          eps11=epsmin;eps12=epsmax; 
% % %          sigma1=svd(A+eps11*E); sigma2=svd(A + eps12*E);
% % %          lambda11=sigma1(end+1-deg*dim); lambda12=sigma2(end+1-dim*deg);
% % %       %%%lambda13=min(svd(A + eps13*E)); lambda14=min(svd(A+eps14*E));
% % %          inteps=interp1([eps11, eps12], [lambda11, lambda12], epsilon, 'pchip');
% % %          xx=find(inteps>0);  xy=min(epsilon(xx)); xz=find(epsilon==xy);
% % %          eps1=epsilon(xz);
         
         
% %         epsmin=eps0;
% %         delta=(epsmax-epsmin)/9;
% %         epsilon=[epsmin:delta:epsmax];
% %          eps11=epsmin;eps12=epsmax;eps13=.1*epsmin+.9*epsmax;eps14=.2*epsmin+.8*epsmax;% eps11, eps12, eps13, eps14
% %          sigma1=svd(A+eps11*E); sigma2=svd(A+eps12*E); sigma3=svd(A+eps13*E); sigma4=svd(A+eps14*E);
% %          lambda11=sigma1(end+1-dim*deg); lambda12=sigma2(end+1-dim*deg);lambda13=sigma3(end+1-dim*deg);
% %          lambda14=sigma4(end+1-dim*deg);
% %          parab=polyfit([eps11,eps12,eps13,eps14],[lambda11,lambda12,lambda13,lambda14],3); %parab
% %          inteps=polyval(parab,epsilon); %plot(inteps)
% %          [val,index]=min(inteps); eps1=epsilon(index);


%primo coeff pol int viene 0
% % % %        epsmin=eps0;
% % % %        B1=A+epsmin*E;                                   B2=A+epsmax*E;
% % % %        [evec1,lambda1]=eig(B1'*B1);                      [evec2,lambda2]=eig(B2'*B2); 
% % % %        x1=evec1(:,1);                                    x2=evec2(:,1);
% % % %        y1=B1*x1;                                         y2=B2*x2;
% % % %        
% % % %        z1=min(svd(B1));                                  z2=min(svd(B2));
% % % %        deriv1=-norm(Sprojgenmat((y1*x1'),nP-1,dim),'fro')/z1;    deriv2=-norm(Sprojgenmat((y2*x2'),nP-1,dim),'fro')/z2;
% % % %        
% % % %        Matrix=[1 0 0 0; 1 1 1 1; 0 1 0 0; 0 1 2 3];
% % % %        intp=Matrix\[z1;z2;deriv1; deriv2]; intp
% % % %        
% % % %        delta=(epsmax-epsmin)/19;
% % % %        epsilon=[epsmin:delta:epsmax];
% % % %        inteps=polyval(intp,epsilon); %plot(inteps)
% % % %        [val,index]=min(inteps); eps1=epsilon(index);
       
       
          
        
        if eps1>epsmin & eps1<epsmax
            if abs(eps1-eps0)<tol 
                eps0=eps1;
                break
            else
                eps0=eps1;
            end
        else
            eps0=(1-c)*epsmin+c*epsmax;
        end
    else
        disp('bisection step'), it
        epsmax=eps0;
        eps0=(1-c)*epsmin+c*epsmax;
        Eold=E; %%%%%%%%%%%%%%%%%%%%%%%%%%%%%era E=Eold
    end
    zvec=[];
    Eold=E;
    disp('integration of ODE')
    if it >= 1
        [zvec,x,y,A,B,E]=controlodematnt(P,dim,deg,eps0,h0,E);
       %[zvec,x,y,A,B,E]=controlodematord2mp(P,dim,deg,eps0,h0,E);
        %[zvec,x,y,A,B,E]=controlodematord2t(P,dim,deg,eps0,h0,E);
    else
      [zvec,x,y,A,B,E]=controlodematnt(P,dim,deg,eps0,h0,E);
     %[zvec,x,y,A,B,E]=controlodematord2mp(P,dim,deg,eps0,h0);
     %[zvec,x,y,A,B,E]=controlodematord2t(P,dim,deg,eps0,h0);
    end
    disp('completed')
%    if epsmax-epsmin<tol
%        break
%    end

end
% format long
% zvec

% this is the computed distance;

S1 = max(svd(A));
S2=  max(svd(B));
dist = S1-S2;
B=A+eps0*E;
Phat(1:dim,:)=B(1:dim,1:dim*(n+1)); 

Phat(dim+1:2*dim,:)=B(n*dim+1:n*dim+2,1:dim*(n+1)); 

end