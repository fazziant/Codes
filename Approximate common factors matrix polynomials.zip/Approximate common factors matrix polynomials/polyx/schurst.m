% schurst
%
% Ordered Schur decomposition
%
% The function
%
%   [S,U,ind] = schurst(C[,tol])
%
% computes the ordered complex Schur decomposition
%
%    C = USU'
%
% of the matrix C. U is unitary (UU'= I) and S is upper triangular. 
% The eigenvalues of C with negative real part appear first along 
% the diagonal of S. The vector ind contains the corresponding column 
% indices of U so that the columns of U(:,ind) span the maximal stable
% invariant subspace of C.
%
% If the optional tolerance argument tol is not specified then its 
% default value is 10*eps*max(abs(diag(T))), where T is the (not 
% necessarily ordered) Schur form of C as returned by the macro schur.
% The tolerance is used to determine the sign of the diagonal elements.

% Henrion D. 6-96
% modified by Henrion D. 4-97 : output arguments order + tolerance
% modified by Henrion D. 4-97 : U not unitary when S is complex : bug fixed
% Modified by S. Pejchova, June 26, 1997
                               
% functions used : schur, rsf2csf

function [S,U,ind] = schurst(C,tol)

if nargin < 1
 disp('usage:  [S,U,ind] = schurst(C[,tol])');
 return
end

[rC, cC] = size(C);
if (rC ~= cC),
  error('schurst: The input matrix must be square.');
end;

[U,T] = schur(C);
[U,T] = rsf2csf(U,T);
if nargin == 1,
  tol = 10.0*eps*max(abs(diag(T)));
end;

% ordering of the Schur decomposition
S = T;
order = 0;
while ~order, % while the order is not correct
 order = 1;
 for k = 1:rC-1,
  if (real(S(k,k)) >= -tol) & (real(S(k+1,k+1)) < -tol),
   order = 0; % diagonal elements to swap
   % complex Givens rotation
   b = S(k,k)-S(k+1,k+1); a = S(k,k+1);
   absa = abs(a);
   if absa == 0, c = 0; s = 1;
   else n = norm([a b]); c = absa/n; s = a/absa*(conj(b)/n);
   end;
   G = [c s;-conj(s) c];
   S(k:k+1,:) = G'*S(k:k+1,:); % row rotation on S
   S(:,k:k+1) = S(:,k:k+1)*G; % column rotation on S
   U(:,k:k+1) = U(:,k:k+1)*G; % column rotation on U
  end; % if
 end; % for k
end; % while

ind = real(diag(S)) < -tol;

