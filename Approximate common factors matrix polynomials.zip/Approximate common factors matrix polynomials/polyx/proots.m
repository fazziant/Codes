%proots
%
% Roots of a polynomial matrix
%
% The commands
%
%    r = proots(A)
%    r = proots(A[,'z'][,tol][,'all'])
%    r = proots(A,method[,'z'][,tol][,'all'])
%
% return the roots of a square polynomial matrix A.
%
% Various methods are available:
%
%    'mfl' (default)   the roots are computed as the roots of 
%                      the determinant calculated with the
%                      modified Fadeev-Laverrier algorithm;
%    'int'             the roots are computed as the roots of the
%                      determinant calculated by interpolation;
%    'eig'             the roots are computed as the generalized 
%                      eigenvalues of the block companion matrix;
%    'tri'             the roots are computed as the roots of the
%                      determinant calculated by triangularization.
%
% The input arguments 'z' and tol are used in "zeroing" (see the
% function 'pzero'). The default value of the tolerance tol is 
% computed from the degree and sizes of A. If 'z' and tol are missing
% then the macro runs without "zeroing".
%
% If the input argument 'all' is present then the macro returns all 
% roots (finite and infinite). 
%
% If the input matrix is singular then the macro returns the empty 
% matrix.

%
% functions used: pinfo, punpck, punpckv, pdet, blcomp 

% COPYRIGHT S. Pejchova, M. Sebek 1997
% $Revision: 1.4 $       $Date: 1997/05/02 10:38:09 $     $State: Exp $


function r = proots(A,arg2,arg3,arg4,arg5)

test1=0;, zeroing=0;, method='mfl';, tol=eps; allro=0;

if nargin==0
   test1=1;
elseif isstr(A)
   test1=1;
elseif nargin>1
   for i=2:nargin
       stg=['argm=arg',int2str(i),';'];
       eval(stg);
       if isstr(argm)
          if strcmp(argm,'z')
              if zeroing==0, zeroing=2; end
          elseif strcmp(argm,'mfl') | strcmp(argm,'eig') |...
              strcmp(argm,'int') | strcmp(argm,'tri')
              method=argm;
          elseif strcmp(argm,'all')
              allro=1;
          else
              test1=1;
          end
       elseif length(argm)==1
          tol=argm;
          zeroing=1;
       else
          test1=1;
       end
   end
end
if test1
   disp('usage: r = proots(A)                or  r = proots(A,''all'') ');
   disp('    or r = proots(A,''z'')            or  r = proots(A,''z'',tol) ');
   disp('    or r = proots(A,''mfl'')          or  r = proots(A,''mfl'',''all'') ');
   disp('    or r = proots(A,''mfl'',''z'')      or  r = proots(A,''mfl'',''z'',tol) ');
   disp('    or r = proots(A,''int'')          or  r = proots(A,''int'',''all'') ');
   disp('    or r = proots(A,''int'',''z'')      or  r = proots(A,''int'',''z'',tol) ');
   disp('    or r = proots(A,''eig'')          or  r = proots(A,''eig'',''all'') ');
   disp('    or r = proots(A,''eig'',''z'')      or  r = proots(A,''eig'',''z'',tol) ');
   disp('    or r = proots(A,''tri'')          or  r = proots(A,''tri'',''all'') ');
   disp('    or r = proots(A,''tri'',''z'')      or  r = proots(A,''tri'',''z'',tol) ');
   return
end

[typeA,rA,cA,degA]=pinfo(A);
if rA~=cA
   error('proots: The input matrix is not square');
end

if isnan(degA) | isinf(degA) | degA==0
   r=[];
   return
end

if zeroing==2  % default value for zeroing
   tol=norm(punpck(A))*(max(size(punpck(A))))*eps;
   ttol=1/tol;
elseif zeroing==1
   ttol=1/tol;
end

if strcmp(method,'eig')                               % generalized
                                                      % eigenvalues
   [C,D]=blcomp(A,'sep');
   r=eig(C,D);
else
   stg=['dA=pdet(A,''',method,''''];
   if zeroing > 0
      stg=[stg,',''z'',tol'];
   end
   stg=[stg,');'];
   eval(stg);
    degofdet=degA*rA;
    dA=punpckv(dA);
    nz=find(abs(dA));
    if isempty(nz)
       r=NaN*ones(degofdet,1);
       disp('proots warning: Matrix is singular to working precision.');
       disp('                Finite roots cannot be computed by this');
       disp('                 method. Try the option ''eig''.');
    else
       n=length(dA);
       dAx=zeros(1,n);
       dAx(1:n)=dA(n:-1:1);
       r=roots(dAx);
       if degofdet>(n-1)
          r=[Inf*ones(degofdet-n+1,1);r];
       end
    end   
end
if ~allro
   k=find(isinf(r)==0);
   if isempty(k), r=[];
   else,  r=r(k);
   end
   k=find(isnan(r)==0);
   if isempty(k), r=[];
   else, r=r(k);
   end
   if zeroing > 0
      k=find(abs(r) > ttol);
      if isempty(k)==0, r(k)=[];, end
   end
end
