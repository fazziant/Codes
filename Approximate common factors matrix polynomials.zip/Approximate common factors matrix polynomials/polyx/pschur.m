% pschur
%
% Test whether a polynomial matrix is Schur
% 
% The function
%
%   pschur(A)
%
% returns 1 if al the roots of the polynomial matrix A have 
% magnitude strictly less than 1. Otherwise, it returns 0.
%
% If the matrix is a constant matrix then it not is considered 
% to be Schur.

% Henrion D. 3-96
% Modified by S. Pejchova, June 26, 1997
% function used: pdet, pinfo, pdegco, punpck

function s = pschur(a)

if nargin < 1
 disp('usage:  pschur(A)');
 return
end

s = 0;
[typea, ra, ca, dega] = pinfo(a);

if (typea == 'poly') & (dega > 0),
  if (ra > 1) | (ca > 1),
    if ra ~= ca,
      error('pschur: The input matrix is not square.')
    end;
    a = pdet(a);
    dega = pdegco(a);
  end;

  % discrete-time version of Routh array on det(A)
  if finite(dega) & (dega > 0),
    i = 2; k = dega;
    a = punpck(a); a = a * sign(a(k+1));
    R = [fliplr(a); a];
    while i <= dega+1,
     row = 3+(i-2)*2;
     for j = 1:k,
      R(row,j) = R(row-2,1)*R(row-1,j+1)-R(row-2,j+1)*R(row-1,1);
     end;
     R(row+1,1:k) = fliplr(R(row,1:k));
     if (row == 3 & R(row+1,1) < eps) | (row > 3 & R(row+1,1) > -eps),
      return;
     end;
     k = k - 1;
     i = i + 1;
    end; % while i
    s = 1;
  end; % if finite
end; % if typea








