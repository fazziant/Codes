% plqg
% 
% Polynomial solution of the SISO LQG problem
%
% The function call
%
%    [y,x,regpoles,obspoles] = plqg(d,n,p,q,rho,mu)
%
% results in the solution of the SISO LQG problem defined by:
% 
%    Response of the measured output to the control input:
% 	y = P(s)u,  P(s) = n(s)/d(s)
%
%    Response of the controlled output to the control input
% 	z = Q(s)u,  Q(s) = p(s)/d(s)
%
%    Response of the measured output to the disturbance input
% 	y = R(s)v,  R(s) = q(s)/d(s)
%
%    In state space form:
%
%       x' = Ax + Bu + Gv
%       z  = Dx 
%       y  = Cx + w
%
%      P(s) = C*inv(sI-A)*B  
%      Q(s) = D*inv(sI-A)*B 
%      R(s) = C*inv(sI-A)*G
%
%    The scalar white state noise v has intensity 1 and the white
%    measurement noise w has intensity mu.
%
% The compensator C(s) = y(s)/x(s) minimizes the steady-state 
% value of
%
%    E[z^2(t) + rho*u^2(t)]
%
% The output argument regpoles contains the regulator poles and 
% obspoles contains the observer poles. Together they are the 
% closed-loop poles.

% H. Kwakernaak, May, 1997
% Modified by S. Pejchova, June 26, 1997

function [y,x,regpoles,obspoles] = plqg(d,n,p,q,rho,mu)


% Checks
if nargin~=6
 disp('usage:  [y,x,regpoles,obspoles] = plqg(d,n,p,q,rho,mu)');
 return
end
degd = pdegco(d);
if pdegco(n)>= degd
   error('plgq: n/d is not proper')
elseif pdegco(p)>= degd
   error('plgq: p/d is not proper')
elseif pdegco(q)>= degd
   error('plgq: q/d is not proper')
end


% Spectral factorizations and computation of 
% the closed-loop polynomial phi

dast = cjg(d); past = cjg(p); qast = cjg(q);
regpol = padd(pmul(dast,d),pscl(pmul(past,p),1/rho));
obspol = padd(pmul(dast,d),pscl(pmul(qast,q),1/mu));
regpoles = roots(punpckv(regpol,'rrow'));
obspoles = roots(punpckv(obspol,'rrow'));
regpoles = regpoles(find(real(regpoles)<0));
obspoles = obspoles(find(real(obspoles)<0));
phir = real(poly(regpoles)); phir = ppck(fliplr(phir),length(phir)-1);
phio = real(poly(obspoles)); phio = ppck(fliplr(phio),length(phio)-1);
phi = pmul(phir,phio);


% Solve for the compensator
% Solve for x and y
% To be modified

dnphi = pcoljoin(d,pcoljoin(n,pscl(phi,-1)));
xy1 = axb(dnphi,0,'h');
x = psel(xy1,1,1); y = psel(xy1,2,1);
