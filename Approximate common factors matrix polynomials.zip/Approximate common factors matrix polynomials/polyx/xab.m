%xab
%
% The function
%
%  [X0,K] = xab(A,B[,tol][,'minimal'])
%  [X0,K] = xab(A,B[,tol],'res'[,'minimal'])
%  [X0,K] = xab(A,B[,tol],'elo'[,'minimal')
%  [X0,K] = xab(A,B[,tol],'int'[,'minimal'][,degx][,sj[,alpha]])
%
% solves the polynomial matrix equation
%
%   XA = B
%
% where A has m rows.
%
% If only one output argument X0 is present then the macro computes 
% only a particular solution. If B is a zero matrix then this solution
% equals a polynomial basis for the left null space of A. 
% If no polynomial solution exists then  X0 = [].
%
% If both output arguments are present then a polynomial basis for 
% the left null space of A is computed and returned as K. All
% possible solutions of XA = B may be parametrized as
%
%    X = X0 + TK
%
% where T is an arbitrary polynomial matrix of compatible dimensions.
% If A is of full row rank, then K = [].
%
% The optional parameter tol allows to specify the tolerance used to
% decide whether a solution exists and to decide whether A has
% linearly dependent columns. If tol is negative then it takes its
% default value.
%
% The string 'res' indicates that the solution is computed by the
% resultant method. This is the default method.
%
% The string 'elo' indicates that elementary row operations are used.
%
% The string 'int' maeans that the solution is computed via polynomial
% interpolation. The input argument degx is the expected degree of X0,
% sj is a vector containing k distinct interpolation points, and
% alpha contains k nonzero vectors, length of each is cA. The minimal
% number of interpolation points is k = sum(di)+cA(degx+1), where di are
% column degrees of A. If degx,sj or  alpha are missing then the program
% uses simple formulas for its  constructions.
%
% If the option 'minimal' is present then the function minimizes the 
% degrees of several right-most columns in X0.

% function used: exfac, grd, pcoljoin, pdegco, pdiv, pinfo, pmul, ppck, pput,
%                prank, presult, psel, psub, punpck, pval, pzero, rwsearch 

% COPYRIGHT S. Pejchova, D. Henrion, M. Sebek 1997
% $Revision: 1.2 $      $Date: 1997/06/28 13:58:08 $    $State: Exp $

function [X0,K] = xab(A,B,arg3,arg4,arg5,arg6,arg7,arg8)

method='res'; test1=0; tol=-1; gnrl=0; minim=0; argm=[];
if nargin<2
   test1=1;
elseif isstr(A) | isstr(B)
   test1=1;
elseif nargin > 2
   if ~isstr(arg3)
      if length(arg3)==1, tol=arg3;
      else, test1=1;
      end
   end
   for i=3:min([5,nargin])
       stg=['arga=arg',int2str(i),';'];
       eval(stg);
       if strcmp(arga,'elo'), method='elo'; argm=i;
       elseif strcmp(arga,'int'), method='int'; argm=i;
       elseif strcmp(arga,'res'), argm=i;
       elseif strcmp(arga,'minimal'), minim=1; argm=i;
       elseif isstr(arga), test1=1;
       end
   end
end 
if test1
 disp('usage: [X0,K] = xab(A,B[,tol]) ');
 disp('   or: [X0,K] = xab(A,B[,tol],''res''[,''minimal'']) ');
 disp('   or: [X0,K] = xab(A,B[,tol],''elo''[,''minimal'')  ');
 disp('   or: [X0,K] = xab(A,B[,tol],''int''[,''minimal''][,degx][,sj][,alpha])');
 return
end

if nargout==2, gnrl=1; end
status = 0; K = [];
[typeA,rA,cA,degA] = pinfo(A);
[typeB,rB,cB,degB] = pinfo(B);
if isempty(A) | isempty(B)
   X0=[];  return
end;
zeroB=0;
if norm(punpck(B))<eps, zeroB=1;  end
if (cA ~= cB) & ~zeroB 
  error('xab: Inconsistent dimensions of the input matrices.');
end;
if (isnan(degA)|degA<=0) & (isnan(degB)|degB<=0)       % regular MATLAB matrices
   if zeroB
      if max(rB,cB)==1, X0=zeros(cA,rA);
      else, X0=zeros(rB,rA); end
   else, X0=punpck(B)/punpck(A); end
   K=(null((punpck(A))'))'; 
   if zeroB & ~gnrl, X0=K; end
   if strcmp(typeA,'poly')|strcmp(typeB,'poly')
      X0=ppck(X0,0); K=ppck(K,0);
   end
   return
end

if isnan(degA), degA=0;, A=ppck(A,degA); end
if isnan(degB), degB=0;, B=ppck(B,degB); end

if norm(punpck(A))<eps
   X0=ppck(zeros(rB,rA),0);
   K=ppck(zeros(cB,rA),0);
   return
end
if isinf(degA), degA=0; end
if isinf(degB), degB=0; end
%------------------------------------------------------------------
%%%%%%%%%%%%%%%   NON MINIMAL DEGREE SOLUTION   %%%%%%%%%%%%%%%%%%%
%------------------------------------------------------------------
if ~minim 
   %---------------------------------------------------------------
   %%%%%%%%%%%%%%%%%%%%%%  METHOD = 'RES'  %%%%%%%%%%%%%%%%%%%%%%%%
   %---------------------------------------------------------------
   if strcmp(method,'res')

      % initial value for degree of X

      cdA = pdegco(A,'col'); cdB = pdegco(B,'col'); % column degrees
      ifcdA = isinf(cdA); cdA(ifcdA) = zeros(1,sum(ifcdA)); % -Inf -> 0
      ifcdB = isinf(cdB); cdB(ifcdB) = zeros(1,sum(ifcdB));
      degX = max([cdB - cdA 0]);

      RA = presult(A, degX);
      delta = degA + degX - degB;
      % ----------------------------------------------------------
      % PARTICULAR SOLUTION
      % ----------------------------------------------------------

      if zeroB,                                      % is B zero ?
       X0 = ppck(zeros(rB,rA), 0); % the particular solution is also zero
      else

       % reduction or extension of B for consistent dimensions
       B = punpck(B);
       if delta < 0
        B = B(:, 1:cB*(degA + degX + 1));
       elseif delta > 0,
        B = [B zeros(rB, cB*delta)];
       end;

       % lowest possible degree for X
       if tol < 0, rkRA = rank(RA);
       else rkRA = rank(RA, tol); end; % user-supplied tolerance
       if tol < 0, newrkRA = rank([RA; B]);
       else newrkRA = rank([RA; B], tol); end;

       % highest possible degree for X
       maxdegX = (rA+rB-1)*max(degA, degB);
       stopX0=0;       
       while (newrkRA ~= rkRA),
        degX = degX + 1;
        B = [B zeros(rB, cB)];
        % stopping criterion : the kernel degree cannot exceed 
        % (rA+rB-1)*max(degA, degB)
        if (degX > maxdegX),
          X0 = []; stopX0=1;           % no polynomial solution
        break;           
        end;

        RA = presult(A, degX);
        if tol < 0, rkRA = rank(RA);
        else rkRA = rank(RA, tol); end;
        if tol < 0, newrkRA = rank([RA; B]);
        else newrkRA = rank([RA; B], tol); end;
       end;
       if ~stopX0     
        [rRA, cRA] = size(RA);

        if rkRA == rRA, % resultant has full row rank

         [Q,R] = qr(RA');
         Q1 = Q(:,1:rRA); Q2 = Q(:,rRA+1:cRA); R = R(1:rRA,:)';

         if tol < 0, tol2 = max(size(B))*norm(B)*1e6*eps;
         else tol2 = tol; end;

         if isempty(B*Q2) | (norm(B*Q2) < tol2),
           X0 = ppck(B*Q1 / R, degX); % unique solution
         else
           X0 = []; % no polynomial solution
         end;

        elseif rkRA == cRA, % resultant has full column rank

         [Q,R] = qr(RA);
         Q1 = Q(:,1:cRA); Q2 = Q(:,cRA+1:rRA); R = R(1:cRA,:);
         X0 = ppck((B / R)*Q1', degX); % one possible solution

        else % resultant has deficient rank

         [U,R,V] = svd(RA);
         Q11 = U(:,1:rkRA);
         Q21 = V(:,1:rkRA); Q22 = V(:,rkRA+1:cRA);
         R = diag(R); R = diag(1./R(1:rkRA));

         if tol < 0, tol2 = max(size(B))*norm(B)*1e6*eps;
         else tol2 = tol; end;

         if isempty(B*Q22) | (norm(B*Q22) < tol2),
           X0 = ppck(B * Q21 * R * Q11', degX); % one possible solution
         else
           X0 = []; % no polynomial solution
         end;
        end; % resultant rank
       end; % stopX0
      end; % B zero
      if tol>=0, X0=pzero(X0,tol); end
 
      if gnrl | zeroB

        % ----------------------------------------------------------
        % HOMOGENEOUS EQUATION : POLYNOMIAL LEFT NULL SPACE OF A(S)
        % ----------------------------------------------------------

        if tol < 0, rkA = prank(A);
        else rkA = prank(A,tol); end;

        if rkA < rA,

          degK = 0;
          indeprows = ones(1,rA); % independent rows
          deprows = [];

          % maximal possible kernel is (rA-1)*degA

          for deg = 0:(rA-1)*degA,

           % constant kernel for the resultant matrix
           if tol < 0, [K,dpr] = rwsearch(presult(A, deg));
           else [K,dpr] = rwsearch(presult(A, deg), tol); end;

           % extraction of "primary" dependent rows,
           % i.e. rows dependent in the polynomial sense
           for i = 1:length(dpr),
             dep = rem(dpr(i)-1,rA)+1;
             if indeprows(dep), 
               indeprows(dep) = 0; % new dependent row
               deprows = [deprows i];
               degK = deg;
             end;
           end;
          end;
          K = ppck(K(deprows,1:rA*(degK+1)), degK);
        else
          K = [];
        end;
        if tol>=0, K=pzero(K,tol); end;
      end
      if zeroB & ~gnrl, X0=K; end

   %---------------------------------------------------------------
   %%%%%%%%%%%%%%%%%%%%%%  METHOD = 'ELO'  %%%%%%%%%%%%%%%%%%%%%%%%
   %---------------------------------------------------------------
   elseif strcmp(method,'elo')
      if tol<0, zeroing=1; else, zeroing=0; end
      if zeroing
         normAB=max([norm(punpck(A)),norm(punpck(B)),]);
         tol=normAB*(max([max(size(A)),max(size(B))]))*eps*1e2;
      end
      if zeroing, strel1=['''z'');'];
      else, strel1=['tol);'];
      end

      strel=['[G,U,UI]=grd(A,'];
      strel=[strel,strel1];
      eval(strel,'G=[];');

      [typeG,rG,cG,degG]=pinfo(G);
      [typeU,rU,cU,degU]=pinfo(U);
      rankG=min(rG,cG);

      if ~isempty(G)
         strel=['B1=exfac(B,G,''r'',''elo'','];
         strel=[strel,strel1];
         eval(strel,'B1=[];');
      end

      if rankG>0 & ~isempty(U)
         P1=psel(U,[1:rankG],':');

         if rU > rankG
            K=psel(U,[(rankG+1):rU],':');
         else, K=[]; end

         X0=pmul(B1,P1,'z',tol);
         if ~zeroing
            X0=pzero(X0,tol); K=pzero(K,tol);
         end
      else
         X0=[]; K=[];
      end
      if zeroB & ~gnrl, X0=K; end
   %---------------------------------------------------------------
   %%%%%%%%%%%%%%%%%%%%%%  METHOD = 'INT'  %%%%%%%%%%%%%%%%%%%%%%%%
   %---------------------------------------------------------------
   else
      degxo=[]; sjo=[]; alphao=[]; r=1;
      if ~isempty(argm)
         if nargin > argm
            for i=(argm+1):nargin
                stg=['arga=arg',int2str(i),';'];
                eval(stg);
                if isempty(degxo)&(length(arga)==1)&(round(arga)==arga) 
                   degxo=arga;
                elseif isempty(sjo), sjo=arga;
                elseif isempty(alphao), alphao=arga;
                end
            end
         end
      end
      if tol<0
         normAB=max([norm(punpck(A)),norm(punpck(B))]);
         tol=normAB*(max([max(size(A)),max(size(B))]))*eps*1e2;
         zeroing=1;
      else, zeroing=0; end

      DAc=pdegco(A,'col'); zDAc=max(0,DAc);
      DAQc=pdegco(psel(A,1:cA,1:cA),'col'); zDAQc=max(0,DAQc);
      if zeroB, DBc=zeros(1,cA); zDBc=DBc;
      else, DBc=pdegco(B,'col'); zDBc=max(0,DBc); end
      if isempty(degxo)
         degx_col=zeros(1,cA); r=0;
         for i=1:cA
             if zDAc(i)> zDBc(i)
                degx_col(i)=max(zDAc(i)-1,0);
             else
                degx_col(i)=max(zDBc(i)-zDAQc(i),0);
             end
         end
         degxo=max(degx_col);
      end
      fA=find(DAc>0);

%      if ~isempty(alphao) & r, repl=1; else, repl=0; end
      repl=0;
      while repl<1
        alpha=alphao; sj=sjo; b_loop=0;
        for ir=degxo:((rA+rB-1)*max(degA,degB))
         degx=ir;
         if isempty(fA),  k=cA*(degx+1);
         else,  k=sum(DAc(fA))+cA*(degx+1); end
         if isempty(alpha) | b_loop,  alpha=rand(cA,k);  end
         if isempty(sj) | b_loop,  sj=(-k/20:0.1:k/20);  end
         [typeAL,rAL,cAL,degAL]=pinfo(alpha);
         [typesj,rsj,csj,degsj]=pinfo(sj);
         if strcmp(typeAL,'poly') & degAL~=0,  test1=1;  end
         if strcmp(typesj,'poly') & degsj~=0,  test1=1;  end
         if test1 | rAL<cA | cAL<k | length(sj)<k
            error('xab: Inconsistent input data for interpolation'); 
         end
         if csj<k, sj=(sj)';, end
         sj=sj(1,1:k);
         alpha=alpha(1:cA,1:k);

         % ----------------------------------------------------------
         % PARTICULAR SOLUTION
         % ----------------------------------------------------------
         if zeroB
            X0=ppck(zeros(rB,rA),0);
         else
            Xr=eye(rB,rA);  Z=zeros(rB,rB-cA);
            I=eye(rA);, BT=[];, SDL=zeros(rA*(degx+1),k);

            if k < degx+1
               v=[sj,ones(1,degx+1-k)];
            else
               v=sj;
            end
            V=rot90(vander(v));

            for j=1:k
                ALcol=(pval(A,sj(j)))*alpha(:,j);
                BLcol=(pval(B,sj(j)))*alpha(:,j); 
                BTcol=BLcol-[sj(j)^degx*Xr,Z]*ALcol;
                BT=[BT,BTcol];
                SDL(:,j)=(kron(V(1:(degx+1),j),I))*ALcol;
            end
            Sinf=isinf(pdegco(SDL,'row'));
            fSi=find(Sinf); fSno=find(Sinf==0);
            if ~isempty(fSi), SDL(fSi,:)=[]; end
            if zeroing, rkSDL = rank(SDL);     
            else rkSDL = rank(SDL, tol); end;
            [rSDL, cSDL] = size(SDL);

            if rkSDL == rSDL,              % SDL has full row rank

             [Q,R] = qr(SDL');
             Q1 = Q(:,1:rSDL); Q2 = Q(:,rSDL+1:cSDL); R = R(1:rSDL,:)';
             if isempty(BT*Q2) | (norm(BT*Q2) < tol*1e4),
               Mr = BT*Q1 / R;             % unique solution 
             else
               Mr = [];                    % no polynomial solution
             end;

            elseif rkSDL == cSDL,          % SDL has full column rank

             [Q,R] = qr(SDL);
             Q1 = Q(:,1:cSDL); Q2 = Q(:,cSDL+1:rSDL); R = R(1:cSDL,:);
             Mr =(BT / R)*Q1';             % one possible solution 

            else                           %  SDL has deficient rank

             [U,R,V] = svd(SDL);
             Q11 = U(:,1:rkSDL);
             Q21 = V(:,1:rkSDL); Q22 = V(:,rkSDL+1:cSDL);
             R = diag(R); R = diag(1./R(1:rkSDL));
             if isempty(BT*Q22) | (norm(BT*Q22) < tol*1e4),
               Mr = BT * Q21 * R * Q11';   % one possible solution
             else
               Mr = [];                    % no polynomial solution
             end;
            end; % (SDL rank)
            if ~isempty(fSi) & ~isempty(Mr)
               [rBT,cBT]=size(BT);
               X0=zeros(rBT,rSDL);
               X0(:,fSno)=Mr;
            else
               X0=Mr;
            end

            X0=X0+[zeros(rB,degx*rA),eye(rB,rA)];
            X0=ppck(X0,degx);
            if ~zeroing, X0=pzero(X0,tol); end
         end %(if zeroB)

         if ~zeroB, Res=norm(punpck(psub(B,pmul(X0,A)))); else, Res=0; end
         if r | (Res<tol*1e6)
            break;
         else
            b_loop=1;
         end
        end %(for ir=..)
        if Res > tol*1e6
         b_loop=0; repl=repl+1;
        else
         break;
        end
      end %(while repl<1)

      if Res > tol*1e6
         disp(sprintf('xab warning: The relative residue of calculation is  %g.',Res));
         strwar=['             No particular solution up to degree %g found by'];
         disp(sprintf(strwar,ir));
         disp('            interpolation. Try higher degree or another method.');
         X0=[];
      end

      % ----------------------------------------------------------
      % HOMOGENEOUS EQUATION : POLYNOMIAL LEFT NULL SPACE OF A(S)
      % ----------------------------------------------------------
      if gnrl | zeroB
       rankA=prank(A,tol);
       rowK=rA-rankA;
%       if ~isempty(alphao) & r, repl=1; else, repl=0; end
       repl=0;
       while repl<1
        alpha=alphao; sj=sjo; b_loop=0;
        for jr=0:(max(rA,cA))*degA 
          degx=jr;
          if isempty(fA),  k=cA*(degx+1);
          else, k=sum(DAc(fA))+cA*(degx+1); end
          if isempty(alpha) | b_loop,  alpha=rand(rA,k);  end
          if isempty(sj) | b_loop,  sj=(-k/20:0.1:k/20);  end
          [rsj,csj]=size(sj);
          if csj<rsj, sj=(sj)';, end
          sj=sj(1,1:k);
          alpha=alpha(1:cA,1:k);

          Bo=ppck(zeros(cA),0); rBo=cA; cBo=cA;
          Xr=eye(rBo,rA);  Z=zeros(rBo,rBo-cA);
          I=eye(rA);, BT=[];, SDL=zeros(rA*(degx+1),k);

          if k < degx+1
            v=[sj,ones(1,degx+1-k)];
          else
            v=sj;
          end
          V=rot90(vander(v));
          for j=1:k
            ALcol=(pval(A,sj(j)))*alpha(:,j);
            SDL(:,j)=(kron(V(1:(degx+1),j),I))*ALcol;
          end
          K=(null(SDL'))';
          [rK,cK]=size(K);
          if rK > rowK
             [QK,RK]=qr(K);  diagRK=diag(RK);
             [YR,IR]=sort(abs(diagRK)); IR=IR(1:rK-rowK);
             K(IR,:)=[]; [rK,cK]=size(K);       
          end
          NormK=norm(K);
          K=ppck(K,degx);
          if ~zeroing,  K=pzero(K,tol); end
          NormKA=norm(punpck(pmul(K,A,'z',tol)));
          if (r | ((NormKA<tol*1e6)&(NormK>tol)))&(rK==rowK)
            break
          else
            degx=degx+1; b_loop=1;
          end
        end %(for jr=..)
        if (NormKA>tol*1e6)|(NormK<tol)
          b_loop=0; repl=repl+1;
        else
          break;
        end
       end %(while repl<1)

       if (NormKA>tol*1e6)|(NormK<tol)
         disp(sprintf('xab warning: No non-zero solution of homogenous equation up to degree %g',jr));
         disp('             by interpolation. Try higher degree or another method.');
         K=[];
       end
      end  %(if gnrl)
      if zeroB & ~gnrl, X0=K; end
   end

%------------------------------------------------------------------
%%%%%%%%%%%%%%    MINIMAL DEGREE SOLUTION     %%%%%%%%%%%%%%%%%%%%%
%------------------------------------------------------------------
else
   strout=['[X,K]=xab(A,B,tol,method'];
   if ~isempty(argm)
     if nargin>argm
       for i=argm+1:nargin
         strout=[strout,',arg',int2str(i)];
       end
     end
   end
   strout=[strout,');'];
   eval(strout,'error(lasterr)');
   test2=0;
   if ~isempty(K)
      [typeK,rK,cK,degK]=pinfo(K);
      [typeX,rX,cX,degX]=pinfo(X);
      rankK=prank(K);
      if rankK~=rK, test2=1;
      else
        Ksq=psel(K,':',[(cK-rK+1):cK]);
        if prank(Ksq)==rankK, ixsq=[(cK-rK+1):cK]; ixres=[1:cK-rK];  %(4)
        else
          ixsq=cK; ixres=[]; Ksq=psel(K,':',cK); raK=1;
          for i=cK-1:-1:1
              Ka=pcoljoin(psel(K,':',i),Ksq);
              if prank(Ka)>raK, raK=raK+1; Ksq=Ka; ixsq=[i,ixsq];
              else, ixres=[i,ixres]; end
              if raK==rankK
                 if i>1, ixres=[1:i-1,ixres]; end
                 break; 
              end
          end
          if length(ixsq)~=rankK, test2=1;
          end
        end %(if prank(Ksq)) 
        if ~test2
             Kres=psel(K,':',ixres);
             Xsq=psel(X,':',ixsq);
             Xres=psel(X,':',ixres);
             if tol >= 0
               str_tol=[',tol'];
             else, str_tol=[]; end
             str_min=['[T,Xmsq]=pdiv(Xsq,Ksq,''z'''];
             str_min=[str_min,str_tol,');'];
             eval(str_min,'T=[]; Xmsq=[]; ');
             Xmres=[];
             if ~isempty(T) & ~isempty(Xmsq)
              str_min=['Xmres=psub(Xres,pmul(T,Kres,''z''',str_tol,'),''z''',str_tol,');'];
              eval(str_min,'Xmres=[];');
             end
             if (isempty(Xmres)&~isempty(Xres))|isempty(T)|isempty(Xmsq)
              test2=1;
             end
        end %(if ~test2)
      end %(if rankK)
      if ~test2
        Xm=zeros(rX,(length(ixsq)+length(ixres)));
        Xm=pput(Xm,':',ixsq,Xmsq);
        Xm=pput(Xm,':',ixres,Xmres);
        if tol >= 0, Xm=pzero(Xm,tol); end
      end                        
   else
      test2=1; 
   end; % (~isempty(K)) 
   if test2
      X0=X;
      disp('xab warning: Degree cannot be reduced by division.');
   else
      X0=Xm;
   end
end;

