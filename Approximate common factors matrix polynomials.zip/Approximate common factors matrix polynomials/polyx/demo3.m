%demo3
%
% Solution of the SISO LQG problem

% H. Kwakernaak, June, 1997

disp('Demo 3: Solution of the SISO LQG problem')

% Define the problem

n1 = ppck([10004 4 1],2); n2 = ppck([90036 12 1],2); n = pmul(n1,n2);
d1 = ppck([0 0 1],2); d2 = ppck([2501 2 1],2); 
d3 = ppck([22509 6 1],2); d = pmul(d1,d2,d3);


% Scale the polynomials

d = pscale(d,1/100); n = pscale(n,1/100);
[degd,dd] = pdegco(d); 
d = pscl(d,1/dd); n = pscl(n,1/dd);

p = n; q = n;
rho = 1; mu = 1e-6;


% Spectral factorizations and computation of phi

dast = cjg(d); past = cjg(p); qast = cjg(q);
regpol = padd(pmul(dast,d),pscl(pmul(past,p),1/rho));
obspol = padd(pmul(dast,d),pscl(pmul(qast,q),1/mu));
regpoles = roots(punpckv(regpol,'rrow'));
obspoles = roots(punpckv(obspol,'rrow'));
regpoles = regpoles(find(real(regpoles)<0));
obspoles = obspoles(find(real(obspoles)<0));
phir = real(poly(regpoles)); phir = ppck(fliplr(phir),length(phir)-1);
phio = real(poly(obspoles)); phio = ppck(fliplr(phio),length(phio)-1);
phi = pmul(phir,phio);


% Solve for the compensator
% Solve for x and y with y of minimal degree

[x,y] = axbyc(d,n,phi,'minimal');


% Plot the closed-loop step response

Z = pval(phi,0)/pval(n,0); nZ = pmul(n,Z);
figure(2), step(punpckv(nZ,'rrow'),punpckv(phi,'rrow')), grid