%psel
%
% Select specified rows and columns of a polynomial matrix
%
% The command
%
%    S = psel(P,Irow,Icol)
%
% selects specific rows and columns of the polynomial matrix P in
% accordance with the row and column numbers given in Irow and Icol.
% To select all the rows or all the colums substitute the string ':'
% for Irow or Icol, respectively.

% $Revision: 1.2 $	$Date: 1997/06/28 13:12:45 $	$State: Exp $

function S = psel(P,Irow,Icol);

if nargin ~= 3
   disp('usage: S = psel(P,Irow,Icol)')
   return
end

[typeP,rP,cP,degP] = pinfo(P);
if isempty(P), S=[]; return, end
if isstr(Irow)
   if strcmp(Irow,':')
      Irow = 1:rP;
   else
      error('psel: Illegal row specification');
   end
end
if isstr(Icol)
   if strcmp(Icol,':')
      Icol = 1:cP;
   else
      error('psel: Illegal column specification');
   end
end
if typeP == 'poly'
   if min(Irow) <= 0 | max(Irow) > rP 
      error('psel: Inconsistency in the row numbers');
   elseif min(Icol) <= 0 | max(Icol) > cP 
         error('psel: Inconsistency in the column numbers');
   end
   Pt = punpck(P);
   Pt = ppck(Pt(Irow,:),degP);
   [typeP,rP,cP,degP]=pinfo(Pt);
   Pt = ptransp(Pt);
   Pt = punpck(Pt);
   Pt = ppck(Pt(Icol,:),degP);
   S = ptransp(Pt);
else
   S = P(Irow,Icol);
end
