%presult
%
% Sylvester resultant matrix of a polynomial matrix
%
% The function
%
%   B = presult(A,h)
%
% builds the Sylvester resultant of order h of the polynomial
% matrix A(s) = A0 + A1*s + ... An*s^n, defined as 
%
% B = [ A0  A1  ..  ..  An  0   0   ..  ..  ..  ..  .. 0  |   row #1
%     | 0   A0  A1  ..  ..  An  0   0   ..  ..  ..  .. 0  |   row #2
%     | 0   0   A0  A1  ..  ..  An  0   ..  ..  ..  .. 0  |   row #3
%     | ..  ..  ..  ..  ..  ..  ..  ..  ..  ..  ..  .. .. |   
%     | 0   0   0 ..            ..  ..  0   A0  A1  .. An ]   row #(h+1)

% Henrion D. 3-96
% functions used : pinfo, punpck

function B = presult(A, h)

if (nargin < 2),
  disp('usage: B = presult(A,h)');
  return;
else
  [typeh, rh, ch, degh] = pinfo(h);
  if ~strcmp(typeh, 'cons') | (rh ~= 1) | (ch ~= 1),
    error('presult: The second input argument must be scalar');
  elseif (h < 0),
    error('presult: The second input argument must be nonnegative');
  end;
end;

B = [];
[typeA, rA, cA, degA] = pinfo(A);

if ~strcmp(typeA, 'empt'),
  R = punpck(A);
  for i = 1:h+1,
    B = [B; zeros(rA, (i-1)*cA) R zeros(rA, (h-i+1)*cA)];
  end;
end;

