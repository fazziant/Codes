% cgivens1
%
% Given two complex numbers x and y the function
%
%    [c,s] = cgivens1(x,y)
%
% computes a real number c and a complex number s such that
%
%    [  c    s ]
%    [ -s'   c ]
%
% is unitary and
%
%    [  c    s ] [ x ]  =  [ z ]
%    [ -s'   c ] [ y ]     [ 0 ]

% Huibert Kwakernaak
% Revised, April 26, 1997
% Modified by S. Pejchova, June 16, 1997

function [c,s] = cgivens1(x,y)

if nargin~=2
 disp('usage:  [c,s] = cgivens1(x,y)');
 return
end
if x == 0
   if y == 0
      c = 1; s = 0;
   else
      c = 0; s = 1;
   end
else
   c = abs(x)/sqrt(abs(x'*x+y'*y));
   s = c*y'/x';
end
