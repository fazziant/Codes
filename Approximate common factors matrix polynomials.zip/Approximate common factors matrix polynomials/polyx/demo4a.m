%demo4a
%
% Application: SISO mixed sensitivity problem, Part 1

% H. Kwakernaak, June, 1997

disp('Demo4: SISO mixed sensitivity problem')

% Define the various polynomials

c = 1; r = 1;
n = ppck(1,0); d = ppck([0 0 1],2); m = ppck([1 sqrt(2) 1],2);
a1 = ppck(1,0); b1 = a1; b2 = a1; a2 = ppck([c c*r],1);


% Define the various polynomial matrices

D1 = ppck(zeros(3,2),0); D1 = pput(D1,1,1,b1); D1 = pput(D1,2,2,b2);
D2 = ppck(zeros(3,1),0); D2 = pput(D2,1,1,a1); D2 = pput(D2,3,1,d);
N1 = ppck(zeros(3,1),0); N1 = pput(N1,3,1,pscl(m,-1));
N2 = ppck(zeros(3,1),0); N2 = pput(N2,2,1,a2); N2 = pput(N2,3,1,pscl(n,-1));


% Left-to-right conversion

Q = ppck(eye(3),0); 
Q = pput(Q,1,1,b1); Q = pput(Q,2,2,b2); Q = pput(Q,3,3,m);
N2D2 = pcoljoin(N2,D2);
[Del,Lam] = lr(N2D2,Q);


% Define gamma

gamma = 4   % Comment this line out if gamma is pre-defined


% Second polynomial spectral factorization

Jgamma = eye(3); Jgamma(3,3)= -gamma^2;
DelDel = pmul(cjg(Del),Jgamma,Del);
[Gam,J] = pjsf(DelDel,'ext',1);


% Computation of the compensator

xy = rl(pmul([1 0],Gam),Lam);
x = psel(xy,1,1); y = psel(xy,1,2);


% Computation of the closed-loop poles

phi = padd(pmul(n,y),pmul(d,x));
clpoles = proots(phi)