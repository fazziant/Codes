% HW1

close all
clear all

% 1

a = [ 1 0 0 ; 1 1 0 ; 0 1 1 ];
b = [ 1 0 0 ]';
c = [ 0 0 1 ];

r = 1;
q = c'*c;

p = zeros(3,3,51); p(:,:,51) = q;
k = zeros(1,3,50);
e = zeros(1,50);
for i = 50:-1:1
   p(:,:,i) = q + a'*p(:,:,i+1)*a - a'*p(:,:,i+1)*b*1/(r+b'*p(:,:,i+1)*b)*b'*p(:,:,i+1)*a;
   k(:,:,i) = -1/(r+b'*p(:,:,i+1)*b)*b'*p(:,:,i+1)*a;
   e(i) = norm(p(:,:,i+1) - p(:,:,i),'fro');
end

figure, plot(0:49,e), 
title('Riccati recursion convergence') 
xlabel('iter. step, k') 
ylabel('||P(k)-P(k+1)||_F')

k1 = k(1,1,:); k2 = k(1,2,:); k3 = k(1,3,:);
figure, plot(0:49,k1(:),'r-',0:49,k2(:),'b-',0:49,k3(:),'g-') 
title('Feedback gain'), 
xlabel('iter. step, k'), 
ylabel('k_1(t) - red, k_2(t) - blue ,k_3(t) - green')

[v,l] = eig(p(:,:,1)); 
x0 = v(:,find(max(diag(l))));
x0 = x0/norm(x0)

u = zeros(1,51);
x = zeros(3,52); x(:,1) = x0;
j = 0;
for t = 1:50
  u(t) = k(:,:,t)*x(:,t);
  x(:,t+1) = a*x(:,t) + b*u(:,t);
  j = j + u(t)^2 + x(:,t)'*q*x(:,t);
end

figure, plot(u), 
title('Control'), 
xlabel('t'), 
ylabel('y(t)')
x1 = x(1,:); x2 = x(2,:); x3 = x(3,:);
figure, plot(1:52,x1(:),'r',1:52,x2(:),'b',1:52,x3(:),'g'), 
title('States'), 
xlabel('t'), 
ylabel('x_1(t) - red, x_2(t) - blue, x_3(t) - green')

