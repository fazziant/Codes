% pdiagred
%
% Diagonal reduction of a para-Hermitian polynomial matrix
%
% Given a para-Hermitian matrix Z(s) = Z'(-s) the function
%
%   [Zred,U,UI] = pdiagred(Z)
%   [Zred,U,UI] = pdiagred(Z,tol)
%
% produces a diagonally reduced para-Hermitian matrix Zred and a 
% unimodular matrix U such that
%
%   Zred(s) = U'(-s)*Z(s)*U(s) 
%
% UI is the inverse of U.
%
% If the optional tolerance parameter tol is not present then its 
% default value is 1e-8.

% Henrion D. 6-96
% Modified by Henrion D. 4-97 : also returns UI
% Modified by Henrion D. 6-97 : bug fixed in diagonal degree computation
% Modified by S. Pejchova, June 26, 1997

% macros used : pinfo,pdegco,pzero,psub,cjg,ppck,psing,pput,pmul,cjg

function [Zred,U,UI] = pdiagred(Z,tol)

if nargin < 1
 disp('usage:  [Zred,U,UI] = pdiagred(Z[,tol])');
 return
end
[typeZ,n,cZ,degZ] = pinfo(Z);

if (n ~= cZ),
  error('pdiagred: The input matrix must be square');
elseif finite(pdegco(pzero(psub(cjg(Z),Z)))),
  error('pdiagred: The input matrix must be para-Hermitian');
elseif psing(Z),
  error('pdiagred: The input matrix is singular');
end;

if nargin == 1,
  tol = 1e-8;
end;

U = ppck(eye(n), 0);
UI = U;
Zred = Z;
reduced = 0;

% half diagonal degrees
D = pdegco(Zred, 'dia');

while ~reduced,

 % diagonal leading coefficient corresponding
 % to half diagonal degrees D(1),..,D(n)
 ZL = zeros(n);
 for i = 1:n, for j = 1:n,
  if D(i)+D(j) <= degZ,
   ZL(i, j) = (-1)^D(i) * Zred(i,j+(D(i)+D(j))*n);
  end;
 end; end;

 reduced = (min(svd(ZL)) > tol) | ~any(D);

 if ~reduced, % if matrix is not diagonally reduced
  N = null(ZL); deflation = 0;

  reduced = 1;
  i = 1; 
  while (i <= size(N,2)),
   e = N(:, i);
   hideg = []; maxi = -1;
   for i = 1:n,
    if abs(e(i)) > tol; % active index set
     if D(i) >= maxi,
      if D(i) > maxi,
       maxi = D(i); hideg = i;
      else
       hideg = [hideg i]; % highest degree active index set
      end;
     end;
    end;
   end;
   k = 0; maxi = -1;
   for i = hideg,
    if abs(e(i)) > maxi,
     maxi = abs(e(i)); k = i; % index corresponding to maximal element
    end;
   end;

   % deflation
   if D(k) > 0,
    reduced = 0;
    a = e/e(k);

    % build matrix U(s) and its inverse UI(s)
    V2 = ppck(eye(n), 0); V2I = V2;
    for i = 1:n,
     if i ~= k,
      d = D(k) - D(i);
      V2 = pput(V2, i, k, ppck([zeros(1,d) a(i)], d));
      V2I = pput(V2I, i, k, ppck([zeros(1,d) -a(i)], d));
     end;
    end;
    Zred = pmul(cjg(V2), Zred, V2, 'z', tol);
    U = pmul(U, V2, 'z', tol);
    UI = pmul(V2I, UI, 'z', tol);

    D(k) = D(k) - 1;
    % half diagonal degree can be smaller
    while (abs(Zred(k, k+2*n*D(k))) <= tol) & (D(k) > 0),
      D(k) = D(k) - 1;
    end;

   end; % if D(k)

   i = i + 1;
  end;
  
 end; % if reduced

end; % while



