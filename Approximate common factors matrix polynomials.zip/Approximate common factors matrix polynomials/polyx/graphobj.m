% graphobj
%
% The command
%
%    [menu1,mov1,step_plot] = graphobj(menu1,mov1,step_plot,A)
%
% allows to select and control next step of reduction if the input 
% argument 'menu1' = 1, or creates 2-D or 3-D graphics object from 
% the  matrix  A if 'mov1' = 1. The input argument step_plot carries 
% more detailed information about the next step.

% COPYRIGHT S. Pejchova, M. Sebek  1997
% $Revision: 1.1 $      $Date: 1997/06/26 11:38:00 $    $State: Exp $

function [menu1,mov1,step_plot] = graphobj(menu1,mov1,step_plot,A)

test1=0;
if nargin~=4
   test1=1;
elseif ~(menu1==0 | menu1==1) | ~(mov1==0 | mov1==1) | length(step_plot)~=3
   test1=1;
elseif isstr(A)
   test1=1;
end
if test1
 disp('usage:  [menu1,mov1,step_plot] = graphobj(menu1,mov1,step_plot,A)');
 return;
end;
if step_plot(3)==1
   M=ptransp(A);
else
   M=A;
end
if mov1
   if step_plot(2)==1
      matplot(M);
      pause(0.1);
   elseif step_plot(2)==2
      matplot3(M);
      pause(0.1);
   end
end
if menu1
   if step_plot(1) < 1
      degrees=pdegco(M,'ent')

      nextstep=menu('Next Step','Continue Step-by Step',...
                    'Skip Next Several Step','Skip Next 10 Steps',...
                    'Continue without Interruption',...
                    'Control to Keyboard','Quit');
      if nextstep==2
         step_plot(1)=input('How many steps to skip?  ');
      elseif nextstep==3
         step_plot(1)=10;
      elseif nextstep==4
         menu1=0;
      elseif nextstep==5
         keyboard;
      elseif nextstep==6
         menu1=0;
         step_plot(1)=15;
      end
   end
   step_plot(1)=step_plot(1)-1;
   step_plot(1)=max(0,step_plot(1));
end
