% dphsym
%
% The function
%
%   [Btilda,n] = dphsym(A[,J])
%
% constructs the polynomial matrix B~(d) which is d^n times the 
% discrete-time para-Hermitian matrix B(d) = A*(d) J A(d), that is,
%
%	B(d) = A*(d) J A(d) = B*(d) = B~(d)/d^n
%
% with n the degree of A(d). Here * denotes the discrete-time 
% conjugate of a polynomial matrix and J is a constant symmetric 
% matrix whose default value is the unit matrix.
%
% If J is not symmetric then it is replaced with (J+J')/2.
%
% If A and J are regular Matlab matrices then the result is the
% product A'*J*A.

% Henrion D. 2-96
% functions used : pinfo, pmul, dcjg
% Modified by Henrion D. 4-97: (J+J')/2 if J is non-symmetric
% Modified by S. Pejchova, June 26, 1997

function [Btilda,n] = dphsym(A,J)

if nargin<1
 disp('usage:  [Btilda,n] = dphsym(A[,J])');
 return
end
[typeA, rA, cA, n] = pinfo(A);

if nargin == 1,
  J = eye(rA);
else
  [typeJ, rJ, cJ, degJ] = pinfo(J);
  if degJ > 0,
    error('dphsym: The second input argument must be constant.');
  elseif rJ ~= cJ,
    error('dphsym: The second input argument must be square.');
  elseif rJ ~= rA,
    error('dphsym: The input matrices must have the same size.');
  end;
end;

J = (J+J')/2;

if (typeA == 'empt'),
  n = 0;
  Btilda = [];
elseif (typeA == 'cons'),
  n = 0;
  Btilda = A'*J*A;
elseif isinf(n),
  n = 0;
  Btilda = A;
else
  Btilda = pmul(dcjg(A), J, A);
end;

end % function
