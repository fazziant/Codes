%demo4
%
% Application -- SISO mixed sensitivity problem

% H. Kwakernaak, June, 1997

disp('Demo4: SISO mixed sensitivity problem')

% Define the various polynomials

c = 1; r = 1;
n = ppck(1,0); d = ppck([0 0 1],2); m = ppck([1 sqrt(2) 1],2);
a1 = ppck(1,0); b1 = a1; b2 = a1; a2 = ppck([c c*r],1);
gmin = .5; gmax = 10; accuracy = 1e-4; tol = 1e-4;


% Run the macro mixed

[y,x,gopt] = mixed(n,m,d,a1,b1,a2,b2,gmin,gmax,accuracy,tol,1);


% View the results

disp('y ='),pdp(y)
disp('x ='),pdp(x)
gopt


% Compute the closed-loop poles

dx = pmul(d,x); ny = pmul(n,y); phi = padd(dx,ny);
clpoles = proots(phi)


% Plot the sensitivity functions

omega = logspace(-2,2); j = sqrt(-1);
numS = pval(dx,j*omega);
numT = pval(ny,j*omega);
Phi = pval(phi,j*omega);
S = numS./Phi; T = numT./Phi;
figure(1);
loglog(omega,abs(S),'c'); hold on
loglog(omega,abs(T),'y'); grid on
xlabel('omega')
