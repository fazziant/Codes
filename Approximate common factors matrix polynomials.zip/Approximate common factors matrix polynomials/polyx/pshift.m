% pshift
%
% Modification of the degree of a polnomial matrix
%
% The function
%
%   Q = pshift(P, d)
%
% returns a polynomial matrix Q(s) = s^d P(s).
% The input argument P is a polynomial matrix,
% and d is a scalar which may be negative.

% Henrion D. 3-96
% Modified by S. Pejchova, June 26, 1997
% functions used : pinfo, pdegco, ppck

function Q = pshift(P,d)

if nargin < 1
 disp('usage:  Q = pshift(P[,d])');
 return
end

if (nargin == 1) | (d == 0),
  Q = P;
  return;
end;

[typeP,rP,cP,degP] = pinfo(P);
if (typeP == 'cons'),
  P = ppck(P,0); degP = 0;
end;
if (typeP == 'empt'),
  Q = [];
  return;
end;
if isinf(degP),
  degP = 0;
end;

% minimal degree of P

mdegP = 0;
while (norm(pdegco(P, mdegP), inf) == 0) & (mdegP < degP),
  mdegP = mdegP + 1;
end;

if (d < -mdegP),
  error('pshift: The result is not a polynomial matrix');
else
  % insertion of zeros and shifting
  Q = ppck([zeros(rP, cP*(mdegP+d)) P(1:rP, 1+mdegP*cP:(degP+1)*cP)], degP+d);
end;


