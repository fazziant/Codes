ell = 2; p = 2; m = 2; n = ell * p;
z=0;

%%%%%%% starting ss representation
a = [1 1 1 0;
    .1 3 5 0;
    0 -1 -1 0;
    0 0 0 1];
b =[1 2;
    .1 .5;
    0 1
    z z];
c = [1 2 .1 .3; 3 .1 .1 .5];
d = [ones(2,2)];

 sys = ss(a, b, c, d, 1)


[n rank(ctrb(sys))]
ctrb(sys)
pause

 %%%%%%  starting kernel representation
  [R, P1, P2]=ss2rmimo(sys)

  pause
 format long

P=[reshape(P1,size(P1,1),size(P1,2)*size(P1,3)),reshape(P2,size(P2,1),size(P2,2)*size(P2,3))]
% pause
PP1=P(:,1:end/2);
PP2=P(:,end/2+1:end);
% 

pause
P11=ppck(PP1,2);
P22=ppck(PP2,2);
P111=ppck([P1(:,:,3),P1(:,:,2),P1(:,:,1)],2);
P222=ppck([P2(:,:,3),P2(:,:,2),P2(:,:,1)],2);
P111=ppck([P1(:,:,3)*inv(P1(:,:,1)),P1(:,:,2)*inv(P1(:,:,1)),P1(:,:,1)*inv(P1(:,:,1))],2)
P222=ppck([P2(:,:,3)*inv(P1(:,:,1)),P2(:,:,2)*inv(P1(:,:,1)),P2(:,:,1)*inv(P1(:,:,1))],2)
disp('starting pol kernel  representation')
pause
display('left common factor')
gld(P11,P22)

display('right common factor')
grd(P11,P22)

pause
display('roots')

proots(P111)
proots(P222)
format short
pause

P111t=ppck([P1(:,:,3)',P1(:,:,2)',P1(:,:,1)'],2);
P222t=ppck([P2(:,:,3)',P2(:,:,2)',P2(:,:,1)'],2);
P111t=ppck([P1(:,:,3)'*inv(P1(:,:,1)'),P1(:,:,2)'*inv(P1(:,:,1)'),P1(:,:,1)'*inv(P1(:,:,1)')],2);
P222t=ppck([P2(:,:,3)'*inv(P1(:,:,1)'),P2(:,:,2)'*inv(P1(:,:,1)'),P2(:,:,1)'*inv(P1(:,:,1)')],2);


disp('resultant for transposed polynomials (having rcf)')
res2=[presult(P111t,3); presult(P222t,3)]
pause
format long
disp('svalues resultant exact polynomials')
svd(res2)
pause


zhat=.01;
%%%% perturbed ss representation
ahat=a;chat=c;dhat=d;
bhat=b; bhat(end, :) = zhat;
syshat=ss(a,bhat,c,d,1);

%%%% check the rank of controllability matrix
[n rank(ctrb(syshat))]

%%%%% kernel representation perturbed system
[Rhat, P1hat, P2hat]=ss2rmimo(syshat);
 Phat=[reshape(P1hat,size(P1hat,1),size(P1hat,2)*size(P1hat,3));reshape(P2hat,size(P2hat,1),size(P1hat,2)*size(P1hat,3))]

 
disp('polynomials (transposed) perturbed system')
P111hatt=ppck([P1hat(:,:,3)',P1hat(:,:,2)',P1hat(:,:,1)'],2)
P222hatt=ppck([P2hat(:,:,3)',P2hat(:,:,2)',P2hat(:,:,1)'],2)
P111hatt=ppck([P1hat(:,:,3)'*inv(P1hat(:,:,1)'),P1hat(:,:,2)'*inv(P1hat(:,:,1)'),P1hat(:,:,1)'*inv(P1hat(:,:,1)')],2)
P222hatt=ppck([P2hat(:,:,3)'*inv(P1hat(:,:,1)'),P2hat(:,:,2)'*inv(P1hat(:,:,1)'),P2hat(:,:,1)'*inv(P1hat(:,:,1)')],2)
pause

disp('common factor')
gld(P111hatt,P222hatt)
grd(P111hatt,P222hatt)
disp('roots')
proots(P111hatt)
proots(P222hatt)
pause

disp('resultant perturbed polynomials')
reshat=[presult(P111hatt,3);presult(P222hatt,3)]

disp('singular values resultant')
format long
svd(reshat)
pause

poly1=[P1hat(:,:,3)'*inv(P1hat(:,:,1)'),P1hat(:,:,2)'*inv(P1hat(:,:,1)'),P1hat(:,:,1)'*inv(P1hat(:,:,1)')];
poly2=[P2hat(:,:,3)'*inv(P1hat(:,:,1)'),P2hat(:,:,2)'*inv(P1hat(:,:,1)'),P2hat(:,:,1)'*inv(P1hat(:,:,1)')];

    [dist1, Phatnum1, Cf1]=examplematnt([poly1;poly2],p,1);
    [dist2, Phatnum2, Cf2]=examplematntcsing([poly1;poly2],p,1);
    disp('distance behavioral sense')
% [norm(Phatnum1-[poly1;poly2], 'fro'), dist1]
% [norm(Phatnum2-[poly1;poly2], 'fro'), dist2]
 dist=min([dist1,dist2])
    
 disp('classic distance')
[upper, lower ,z] = dunc_trisect(a, bhat)
pause

%%%%%%%%second part
%%%%%%  starting (exact) ss representation
[Ahat,Bhat,Chat,Dhat]=lmf2ss(ppck([P1(:,:,3)',P1(:,:,2)',P1(:,:,1)'],2),ppck([P2(:,:,3)',P2(:,:,2)',P2(:,:,1)]',2))
pause

%%%%%%% perturbed kernel representation
P1pert=[P1(:,:,3)'*inv(P1(:,:,1)'),P1(:,:,2)'*inv(P1(:,:,1)'),P1(:,:,1)'*inv(P1(:,:,1)')]+.001*[randn(2,4), zeros(2,2)]
P2pert=[P2(:,:,3)'*inv(P1(:,:,1)'),P2(:,:,2)'*inv(P1(:,:,1)'),P2(:,:,1)'*inv(P1(:,:,1)')]+0.001*[randn(2,4),zeros(2,2)]
disp('perturbed pol above')
pause

%%%%%%%% perturbed ss representation
[Ahat2,Bhat2,Chat2,Dhat2]=lmf2ss(ppck(P1pert,2),ppck(P2pert,2))
pause

disp('distance behaviors')
%%%%%%% common factor having rank deficient leading coefficient
[dist3, Phatnum3, Cf3]=examplematntcsing([P1pert;P2pert],p,1);
%%%%%%vcommon factor having full rank leading coefficient
[dist4, Phatnum4, Cf4]=examplematnt([P1pert;P2pert],p,1);
distance=min([dist3,dist4])

disp('classic distance')
[upper, lower ,z] = dunc_trisect(Ahat2, Bhat2)

disp('norm perturbation')
norm([P1pert;P2pert] - [[P1(:,:,3)'*inv(P1(:,:,1)'),P1(:,:,2)'*inv(P1(:,:,1)'),P1(:,:,1)'*inv(P1(:,:,1)')]; [P2(:,:,3)'*inv(P1(:,:,1)'),P2(:,:,2)'*inv(P1(:,:,1)'),P2(:,:,1)'*inv(P1(:,:,1)')]],'fro')
pause

[size(Ahat), rank(ctrb(Ahat,Bhat))]
pause
svd(ctrb(Ahat,Bhat))



