%%%%%%%%%%%%%%%%%%%%%% 
            clear, close all
 
 h0=1e-4; %starting step-size ode-method
 addpath('rsvd/')
% % number of different (random) perturbations
J=10; 


 sigma = .1;
     L=[50:50:300];


% % % generate a random signal as output of a system of order n
 n = 5; 
  sys0 = drss(n, 1, 0); 
  
  d=2; %n+d is the dimension of the data Hankel matrix
 
  for l=1:length(L)
    
      p0 = initial(sys0, rand(n, 1),L(l)); 
 T=length(p0);

for j=1:J
    % perturbed signal 
    pt = randn(T, 1); p = p0 + sigma * pt / norm(pt) * norm(p0);

    %%% run the algorithms
  %Hank-rsvd
    disp('rsvd')
    l, j
 tic, [costfrsvd, eps0, p, delta, ph_odersvd, epsval, sv,  errrsvd] =...
            dist_hfreecon(p, n+d , n, 1e-6,7,2); %rsvd
trsvd(j,l) = toc;
ersvd(j,l)=errrsvd;

    % Hank-svds
     disp('old')
     l, j
 tic,  [costfold, eps0, p, delta, ph_odeold, epsval, sv, errold] =...
     dist_hfreecon(p, n+d, n, 1e-6,1,1); %old version 
  told(j,l) = toc;
 eold(j,l)=errold;

%%%%%%% slra
 % s.m = n+1;
 % s.n = L(l)+1-n;
 % s.w=[[1:n+1],(n+1)*ones(1,length(p)-2*(n-2)),[n+1:-1:1]];
s.m = n+1;
s.w=[[1:n+d],(n+d)*ones(1,length(p)-2*(n+d)),[n+d:-1:1]];
%s.n=length(p)+1-(n+d);
 %s.tts = s2s(s, length(p)); 
[p_slra, i_slra] = slra(p, s, n);
tslra(j,l) = toc
% H=hankel(p_slra(1:7),p_slra(7:end));
% svd(H)
% pause
e_slra(j,l) = norm(p_slra - p)/norm(p);

   %Hank-svds-FFT
    disp('svds')
    l, j
tic,  [costfsvds,eps0,p,delta,ph_odesvds,epsval,sv,errsvds] =...
    dist_hfreecon(p, n+d, n, 1e-6,1,2); %svds
tsvds(j,l) = toc;
esvds(j,l)=errsvds;

relerrtot=errrsvd+errold+errsvds
% if a run does not converge in due time, the error is set to -1.
%In this case, the corresponding run is discurded and
%a new perturbation is generated
  while relerrtot<0
      
     pt = randn(T, 1); p = p0 + sigma * pt / norm(pt) * norm(p0);

    %%% run the algorithms
  %Hank-rsvd
    disp('rsvd')
    l, j
 tic, [costfrsvd, eps0, p, delta, ph_odersvd, epsval, sv,  errrsvd] =...
            dist_hfreecon(p, n+d, n, 1e-6,7,2); %rsvd
trsvd(j,l) = toc;
ersvd(j,l)=errrsvd;

    % Hank-svds
     disp('old')
     l, j
 tic,  [costfold, eps0, p, delta, ph_odeold, epsval, sv, errold] =...
     dist_hfreecon(p, n+d, n, 1e-6,1,1); %old version 
  told(j,l) = toc;
 eold(j,l)=errold;

 %%%%%%% slra
 % s.m = n+1;
 % s.n = L(l)+1-n;
 % s.w=[[1:n+1],(n+1)*ones(1,length(p)-2*(n-2)),[n+1:-1:1]];
s.m = n+1;
s.w=[[1:n+d],(n+d)*ones(1,length(p)-2*(n+d)),[n+d:-1:1]];
[p_slra, i_slra] = slra(p, s, n);
tslra(j,l) = toc
% H=hankel(p_slra(1:7),p_slra(7:end));
% svd(H)
% pause
e_slra(j,l) = norm(p_slra - p)/norm(p);

   %Hank-svds-FFT
    disp('svds')
    l, j
tic,  [costfsvds,eps0,p,delta,ph_odesvds,epsval,sv,errsvds] =...
    dist_hfreecon(p, n+d, n, 1e-6,1,2); %svds
tsvds(j,l) = toc;
esvds(j,l)=errsvds;

relerrtot=errrsvd+errold+errsvds
  end
end
  end

