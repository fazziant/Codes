% -------------------------------------------------
% function c_f_newton_iter
% -------------------------------------------------
%
% Computes fast iterative refinement using Newton's method.
%
% [z,res]=c_f_newton_iter(f,g,z,q1,q2)
%
% f, g -> polynomials whose GCD is sought,
% z -> tentative GCD (to be refined),
% q1, q2 -> tentative cofactors (to be refined).
%

function [z,res]=c_f_newton_iter(f,g,z,q1,q2,f_nearness,optflag);

K=norm(z)^2+norm(q1)^2+norm(q2)^2;
% set tolerance for nearness and maximum number of iterations
tol=1e-15;
max_num_iter=20;
grado=length(z)-1;
N=length(f)-1;
M=length(g)-1;
allow=1;
num_iter=0;
while allow==1
    num_iter=num_iter+1;
    altro_Z=c_iterfast(f,g,q1,q2,z,K,optflag);
    altro_z=fliplr((altro_Z(1:grado+1)).'); % new gcd
    altro_q1=fliplr((altro_Z(grado+2:2+N)).');
    altro_q2=fliplr((altro_Z(N+3:N+3+M-grado)).'); % new cofactors
    s_nearness=[norm(conv(altro_q1,altro_z)-f), norm(conv(altro_q2,altro_z)-g)];
    if (norm(s_nearness)<tol)||(num_iter>max_num_iter)
        allow=0;
        z=altro_z;
        q1=altro_q1;
        q2=altro_q2;
        f_nearness=s_nearness;
    elseif (s_nearness>=f_nearness)
        allow=0;
    else
        z=altro_z;
        q1=altro_q1;
        q2=altro_q2;
        f_nearness=s_nearness;
    end
end
res=f_nearness;