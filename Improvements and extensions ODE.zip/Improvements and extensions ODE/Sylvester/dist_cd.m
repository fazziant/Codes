% main body
function [sv,A,E,Phat,epsval,relerr ] = dist_cd(P,deg,tol,alsv,alproj)
%%%%%%%  output
% sv  d_th singular value at each step
% A  starting Sylvester matrix
% E  final (normalized) perturbation
% Phat  computed perturbed polynomials
% epsval  vector containing the values of epsilon at each step
% relerr  relative error
    
%%%%%%%% input
% P matrix whose rows contain the coefficients of the data polynomials
% deg degree of the approximate GCD
% tol stopping tolerance
%alsv algorithm used for the computation of the triplet u, \sigma, v
%  4 svd
%  6 [Alg.1, 10]
%  alproj  algorithm for the projection
%   1 diagonal averaging
%   2  fft
    

itmax=200;
h0=1e-6;
threshold=1e-6;
c=0.5;
epsval=[];

[mP,nP]=size(P);
n=nP-1;

%construction of Sylvester
A=readpol(P);
[mA,nA]=size(A);
L=min(mA,nA);

% starting singular value
% uses svd for all methods
z=svd(A);
sv=[z(L+1-deg)];
if sv(end)<tol
    disp('the polynomials have a common factor')
    E=zeros(size(A));
    Phat=P;
    epsval=[];
    relerr=0;
    return
end


% estimate interval for distance
 epsmin=sv(end);  
 epsmax=norm(A,'fro');
eps0=min(2*epsmin,(epsmin+epsmax)/2);

% first integration
[zvec,x,y,A,B,E]=intodegens(P,deg,eps0,h0,sv(1),alsv,alproj);

sv=[sv, zvec(end)];
len=[length(zvec)];
% cycle
for it=1:itmax
    epsval(it)=eps0;
  
    if abs(sv(end)) > threshold 

   %%%%% Newton-bisection method
     bis=0;
        epsmin=eps0;

            [U,Sigma,V]=svd(B);
       z = Sigma(L+1-deg,L+1-deg);
       x=V(:,L+1-deg);
       y=U(:,L+1-deg); 
             drho=norm(Sfftproj(y,x,mP),'fro');
                eps1=(eps0+ (z/drho));
      
          
        
        if (eps1>epsmin) && (eps1<epsmax)
            if abs(eps1-eps0)<1e-6
                eps0=eps1;
                break
            else
                eps0=eps1;
            end
        else
            eps0=(1-c)*epsmin+c*epsmax;
        end
 % it
 [zvec,x,y,A,B,E]=intodegens(P,deg,eps0,h0,sv(end),alsv,alproj,E);

sv=[sv, zvec(end)];

 

    else
        disp('bisection step'), it
        bis=1;
        epsmax=eps0;
        eps0=(1-c)*epsmin+c*epsmax;
         if abs(eps0-epsmax)<1e-6 
      
                break
         end
           [zvec,x,y,A,B,E]=intodegens(P,deg,eps0,h0,1,alsv,alproj,E);
           
           sv=[sv, zvec(end)];
          
    end
    
end

if  sv(end)<threshold 
% this is the computed distance;
ddd=[];
for k=1:mP
    ddd=[ddd, E(1+(k-1)*n, :)];
end
dist=eps0*norm(ddd,'fro');
B=A+eps0*E;
Phat(1,:)=B(1,1:n+1); 
for k=2:mP
Phat(k,:)=B((k-1)*n+1,1:n+1); 
end

relerr=norm(Phat(:) - P(:),'fro')/norm(P(:));

else
    Phat=P;
    relerr=-1;
end

end