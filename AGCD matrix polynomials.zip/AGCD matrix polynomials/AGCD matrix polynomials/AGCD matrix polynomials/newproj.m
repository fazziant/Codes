function S = newproj(E,n,dim,w)
% Projection onto Sylvester structure
% E is the matrix we want to project
% n is the degree of the polynomials
% dim is the dimension of the coefficients (assumed square matrices)





for i=1:n+1
    P(1:dim,dim*(i-1)+1:i*dim)=0;
    P(dim+1:2*dim, dim*(i-1)+1:i*dim) = 0;
    for j=1:w
      P(1:dim,dim*(i-1)+1:i*dim)=P(1:dim,dim*(i-1)+1:i*dim)+E(dim*(j-1)+1:j*dim,dim*(j-1)+1+(i-1)*dim:j*dim+(i-1)*dim);
      P(1+dim:2*dim,dim*(i-1)+1:i*dim)=P(1+dim:2*dim,dim*(i-1)+1:i*dim)+E(w*dim+dim*(j-1)+1:w*dim+j*dim,dim*(j-1)+1+(i-1)*dim:j*dim+(i-1)*dim);
    end
    P(1:dim,dim*(i-1)+1:i*dim)=P(1:dim,dim*(i-1)+1:i*dim)./w;
    P(1+dim:2*dim,dim*(i-1)+1:i*dim)=P(1+dim:2*dim,dim*(i-1)+1:i*dim)./w;
end
P1=P(1:dim,:);
P2=P(dim+1:end,:);
S=[blktoep(P1,1,w-1); blktoep(P2,1,w-1)];


