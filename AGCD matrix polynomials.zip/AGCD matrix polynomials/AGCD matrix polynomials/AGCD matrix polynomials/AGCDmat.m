function [dist, Phat, P, C]=AGCDmat(P,dim,deg,P0,noise,nnoise)
% outputs
% dist = distance between polynomials coefficients
% Phat = perturbaed polynomials
% C = common factor

% inputs
% P = polynomials (stacked one below the other)
%      P=[P_{1,n}, ..., P_{1,0};  P_{2,n}, ..., P_{2,0}]
% dim = dimension of the coefficients
% deg = degree commeon factor


  [dist,Phat] = dist_agcd(P,dim,deg);
   while dist < 0
       P = P0 + noise(nnoise) * randn(size(P0));
       [dist,Phat] = dist_agcd(P,dim,deg);
   end
   
% format long

% degpol=size(P,2)/dim-1;
% Prev1=zeros(size(P,1)/2,size(P,2));
% Prev2=zeros(size(P,1)/2, size(P,2));
% for i=1:degpol+1
%     Prev1(:,2*i-1:2*i)=Phat(1:dim,end-2*i+1:end-2*i+2);
%     Prev2(:,2*i-1:2*i)=Phat(dim+1:end,end-2*i+1:end-2*i+2);
% end
% A1=ppck(Prev1,degpol) ;
% A2=ppck(Prev2,degpol) ;


%   GCDr=grd(A1,A2,'t',1e-2);
% 
%   C=GCDr;
%  proots(C);
 C=alcf_ss(Phat',dim,deg);
