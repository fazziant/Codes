function H = moshank(w, i, j)
if nargout < 3, j = []; end, N = length(w); 
H = [];
for k = 1:N, 
w{k};
H = [H blkhank(w{k}, i, j)];
end