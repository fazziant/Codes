function Mc = multmat2(C, m, dA)
n = size(C, 2); dC1 = size(C, 1) / m;
Mc = zeros((dC1 + dA) * m, (dA + 1) * m);
for i = 0:dA
    Mc((i * m + 1):((i + dC1) * m), (i * n + 1):((i + 1) * n)) = C;
end
