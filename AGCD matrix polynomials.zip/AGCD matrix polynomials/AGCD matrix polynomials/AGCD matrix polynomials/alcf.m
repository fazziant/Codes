function [Ch, Ph, f, info] = alcf(P, m, d, Cini)
dP = size(P, 1) / m - 1; dA = dP - d;
Cini = Cini / Cini(1:m, :);
Cini = Cini(m+1:end, :);
[Ch, f, ~, info] = fminsearch(@(x) costfun(x, P, m, dA), Cini);


[~, Ph] = costfun(Ch, P, m, dA);
Ch = [eye(size(Ch, 2)); Ch];