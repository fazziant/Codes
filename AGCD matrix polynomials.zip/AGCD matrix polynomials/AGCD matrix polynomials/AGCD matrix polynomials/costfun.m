function [f, Ph] = costfun(C, P, m, dA)
C = [eye(size(C, 2)); C];
Mc = multmat2(C, m, dA);
Ph = Mc * (Mc \ P);
f = norm(P - Ph, 'fro');
