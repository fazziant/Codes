% adj
%
% The function
%     B = adj(A[,detA])
% computes the adjoint of the square and non-singular polynomial 
% matrix A. It is defined as the product of the determinant and the
% inverse of A and is also a polynomial matrix. If the determinant 
% of A is available then it may be passed to the function as the
% input argument detA.

% [1] P. Stefanidis et al. "Numerical Operations with Polynomial Matrices"
%     Lect. Notes in Control and Information Sciences 171, Springer-Verlag.
% Henrion D. 3-96, algorithm 3.2 p.83 of [1]
% Modified by S. Pejchova, June 26, 1997
% $Revision: 1.7 $	$Date: 1996/10/18 09:45:36 $	$State: Exp $

% functions used : presult, pdet, inv
% and also : pinfo, pdegco, ppck, kron, det

function B = adj(A, P)

if nargin<1
 disp('usage:  B = adj(A[,detA])');
 return
end
[typeA, rA, cA, degA] = pinfo(A);
if (typeA == 'empt'),
  B = [];
  return;
elseif (rA ~= cA),
  error('adj: Input must be square');
elseif psing(A),
  error('adj: Input is singular to working precision');
elseif (typeA == 'cons'),
  B = det(A)*inv(A);
  return;
elseif (rA == 1), % adjoint of a polynomial
  B = ppck(1, 0);
  return;
elseif (rA == 2), % adjoint of a 2x2 matrix
  B = pscl(A, -1);
  B = pput(B, 1, 1, psel(A, 2, 2));
  B = pput(B, 2, 2, psel(A, 1, 1));
  return;
end;

degB = degA*(rA-1); % maximum possible degree for the adjoint

Z0 = pinv(presult(A, degB)); % resultant pseudo-inverse matrix
if exist('P') == 0,
  P = pdet(A);
end;
degP = pdegco(P);

% resolution of the LSE (3.40 of [1]) A(s)*X(s)=det(A(s))*eye(n)
X11 = Z0(1:rA*(degP+1), 1:rA*(degB+1));
B = ppck(kron(punpck(P), eye(rA)) * X11, degB);



