% exfac
%
% Extraction of a polynomial matrix factor.
%
% The command
%
%    A = exfac(C,G [,'z'][,tol])
%    A = exfac(C,G,'l','res'['z'][,tol])
%    A = exfac(C,G,'l','elo'['z'][,tol])
%
% extracts a given left divisor G from the polynomial matrix C
% such that C = G*A. The command
%
%       A = exfac(C,G,'r','res'['z'][,tol])
%       A = exfac(C,G,'r','elo'['z'][,tol])
%
% extracts a given right divisor G from C such that C = A*G. The 
% default action is left division (string 'l').
%
% The string 'elo' or 'res' is the input parameter for the method.
% If the string is 'res' then the left divisor is a solution of 
% the equation A*X = B (see the macro 'axb'). If the string for 
% the method is 'elo' then the divisor is extracted by elementary 
% operations. The default method is 'res'.
%
% The input arguments 'z' and tol are used in "zeroing" (see the
% function 'pzero'). The default value of the tolerance tol is 
% computed from the degree and sizes of the input matrices. If 
% 'z' and tol are missing then the macro runs without "zeroing".
% THE USE OF ZEROING IS STRONGLY RECOMMENDED !!!

% function used: pinfo, punpck, ppck, psel, pmul, pput, psub,
%                prowjoin, pzero, axb, ptransp, pstairso

% COPYRIGHT S. Pejchova, M. Sebek 1997
% $Revision: 1.0 $      $Date: 1997/04/16 16:38:08 $    $State: Exp $

function A = exfac(Co,Go,arg3,arg4,arg5,arg6)

test1=0; tol=eps; method='res'; zeroing=0; ftype=0;

if nargin<2
   test1=1;
elseif isstr(Co) | isstr(Go)
   test1=1;
elseif nargin>2
   for i=3:nargin
       stg=['argm=arg',int2str(i),';'];
       eval(stg);
       if isstr(argm)
          if strcmp(argm,'elo') | strcmp(argm,'res')
              method=argm;
          elseif strcmp(argm,'z')
             if zeroing==0, zeroing=2; end  
          elseif strcmp(argm,'r')
             ftype=1; 
          elseif ~strcmp(argm,'l')
              test1=1;
          end
       elseif length(argm)==1
          tol=argm; zeroing=1;
       else
          test1=1;
       end
   end
end

if test1 
   disp('usage: A = exfac(C,G,''z'',tol) ');
   disp('or     A = exfac(C,G,''l'',''elo'',''z'',tol) ');
   disp('or     A = exfac(C,G,''l'',''res'',''z'',tol) ');
   disp('or     A = exfac(C,G,''r'',''elo'',''z'',tol) ');
   disp('or     A = exfac(C,G,''r'',''res'',''z'',tol) ');
   disp('THE USE OF ZEROING IS STRONGLY RECOMMENDED !!! ');
   return
end

if ftype
   Go=ptransp(Go);
   Co=ptransp(Co);
end
[typeG,rG,cG,degG]=pinfo(Go);
[typeC,rC,cC,degC]=pinfo(Co);
A=[];
if isempty(Co) | isempty(Go), return, end
if rC~=rG 
   error('exfac: Inconsistent dimensions of the input matrices');
end
NormC=norm(punpck(Co)); if NormC==0, NormC=1; end
NormG=norm(punpck(Go)); if NormG==0, NormG=1; end
C=pscl(Co,1/NormC);
G=pscl(Go,1/NormG);
if zeroing==2
   tol=(max(max(size(punpck(C))),max(size(punpck(G)))))*eps*1e2;
elseif zeroing==1
   tol=tol*(NormG/NormC);
end
if isinf(degG) | norm(punpck(G))<tol
   error('exfac: The factor to be extracted is zero');
end
if isinf(degC) | norm(punpck(C))<tol
   A=zeros(cG,cC);
   if strcmp(typeG,'poly') | strcmp(typeC,'poly')
      A=ppck(A,0);
   end
   if ftype, A=ptransp(A); end
   return
end

if strcmp(method,'elo')
   if zeroing > 0
      [GS,US,VS,UIS,VIS,rl]=pstairso(G,'low',tol);
   else
      [GS,US,VS,UIS,VIS,rl]=pstairso(G,'low');   
   end
   [typeGS,rGS,cGS,degGS]=pinfo(GS);
   CS=pmul(US,C);
   r=max(rl);
   zeroG=find(rl==0);
   if isempty(zeroG)==0
      Cunp=punpck(CS);
      if norm(Cunp(zeroG,:))>tol
         error('exfac: The given factor cannot be extracted');
      end
   end
   for i=1:r
       ind=find(rl==i);, li=length(ind);
       E=ppck(zeros(li,cC),0);
       for s=1:li
          row_i=ind(s);
          if i>1
             B=psel(GS,row_i,[1:(i-1)]);
             if zeros > 0
                D=pmul(B,A,'z',tol);
             else, D=pmul(B,A); end
             E=pput(E,s,':',psub(psel(CS,row_i,':'),D,'z',tol));
          else
             E=pput(E,s,':',psel(CS,row_i,':'));
          end
          ar=fliplr(punpck(psel(GS,row_i,i)));
          for j=1:cC
              pr=fliplr(punpck(psel(E,s,j)));
              [ur,vr]=deconv(pr,ar);
              if norm(vr,inf) > tol
                 error('exfac: Division with remainder');
              end
              if zeroing > 0
                 u=pzero(ur(length(ur):-1:1),tol);
              else
                 u=ur(length(ur):-1:1);
              end
              E=pput(E,s,j,ppck(u,length(u)-1));
          end
       end
       if li>1
          Aux=psel(E,1,':');
          for s=2:li
              NormAux=norm(punpck(psub(Aux,psel(E,s,':'))));
              if NormAux>tol
                 error('exfac: The given factor cannot be extracted');
              end
          end
       end

       A=prowjoin(A,psel(E,1,':'));
   end
   [typeA,rA,cA,degA]=pinfo(A);
   if r<rA
      AL=punpck(psel(A,[(r+1):rA],':'));
      if norm(AL,inf)>tol
         error('exfac: The given factor cannot be extracted');
      end
   end
   if cGS > rA
      A=prowjoin(A,zeros(cGS-rA,cA));
   end
   if zeroing > 0
      A=pmul(VS,A,'z',tol);
   else
      A=pmul(VS,A);
   end
elseif strcmp(method,'res')
   if zeroing > 0
      A=axb(G,C,tol);
   else
      A=axb(G,C);   
   end
   if isempty(A)
      error('exfac: The given factor cannot be extracted');
   end
end
if zeroing > 0, A=pzero(A,tol); end
A=pscl(A,NormC/NormG);
Res=(norm(punpck(psub(Co,pmul(Go,A)))))/max(NormC,NormG);
if Res > tol*(NormC/NormG)*1e4
   disp(' ');
   disp(sprintf('exfac warning: The relative residue of calculation is  %g',Res));
   disp('                Try to change the tolerance.');
end
if ftype
   A=ptransp(A);
end
if strcmp(typeG,'cons') & strcmp(typeC,'cons')
   [typeA,rA,cA,degA]=pinfo(A);
   if strcmp(typeA,'poly') & degA <= 0
      A=punpck(A);
   end
end
