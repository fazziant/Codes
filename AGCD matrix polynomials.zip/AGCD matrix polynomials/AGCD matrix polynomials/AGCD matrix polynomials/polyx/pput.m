%pput
%
% Substitute polynomial entries into a polynomial matrix
%
% The command
%
%    S = pput(P,I,J,M)
%
% puts the entries of the polynomial matrix M into the 
% polynomial matrix P as specified by the row indices I 
% and the column indices J.
%
% If I and J are scalars and M is a scalar polynomial then
%
%    P(I,J) = M
%
% If I is a vector of length lI and J is a vector of length lJ
% then  
%
%    P(I(i),J(j)) = M(i,j) 
%
% for every i = 1, 2, ..., lI and j = 1, 2, ..., lJ.
%
% If the largest index occurring in I or J is greater than the 
% numbers of rows or columns of P then the matrix P is supplemented 
% with zero rows or columns.
%
% I and J can also be the string ':' and then have the standard 
% Matlab meaning.
%
% If the matrix M is empty then the corresponding rows or columns 
% are removed from P.

% COPYRIGHT S. Pejchova, M. Sebek 1997
% $Revision: 1.3 $	$Date: 1997/04/14 11:18:20 $	$State: Exp $

function S = pput(P,I,J,M);

if nargin ~= 4
   disp('usage: S = pput(P,I,J,M)')
   return
end

[typeP,rP,cP,degP] = pinfo(P);
if typeP == 'cons' | degP==-Inf
   degP=0;
end

[typeM,rM,cM,degM] = pinfo(M);
if typeM == 'cons' | degM==-Inf
   degM=0;
end

if typeP=='empt'
   if typeM=='empt'
      S=[];
      return
    else
      P=zeros(rM,cM);, typeP=typeM;
      rP=rM;, cP=cM;, degP=0;
   end
end

if isstr(I)
   if strcmp(I,':')
      I = 1:rP;
   else
      error('pput: Illegal string specification for rows');
   end
end
if isstr(J)
   if strcmp(J,':')
      J = 1:cP;
   else
      error('pput: Illegal string specification for columns');
   end
end

[rI,cI]=size(I);, [rJ,cJ]=size(J);
if ((rI > 1) & (cI > 1)) | ((rJ >1) & (cJ >1))
   error('pput: The row or column indices are not vectors');
end

if ((rM~=0)&(length(I)~=rM))|((cM~=0)&(length(J)~= cM))
   error('pput: Indices inconsistent with the substituting matrix ');
end
test1=0;,test2=0;
if typeM=='empt'
   if length(J)==cP
      if norm((sort(J)-(1:cP)),inf)<eps*1e4
         if length(I)==rP
            if norm((sort(I)-(1:rP)),inf) < eps*1e4
               S=[];
               return
            else
               test2=1;
            end
         else
            test2=1;
         end
         if test2
            k=find(I <= rP);
            S=punpck(P);
            S(I(k),:)=[];
            if typeP=='poly'
               S=ppck(S,degP);
            end
            return
         end
      else
         test1=1;
      end
   else
      test1=1;
   end
   if test1
      if length(I)==rP
         if norm((sort(I)-(1:rP)),inf) < eps*1e4 
            test1=0;
         end
      end
   end
   if test1
      error('pput: Indices inconsistent when substituting an empty matrix');
   end
end

if (min(I) <= 0) | (min(J) <= 0)
   error('pput: Negative or zero index specification');
end
if typeP == 'poly' | typeM == 'poly'
   Pt = punpck(P);
   Mt = punpck(M);
   if max(I) > rP
      Pt=[Pt; zeros(max(I)-rP, (degP+1)*cP)];
      rP=max(I);
   end
    if max(J) > cP
       Po=zeros(rP,(degP+1)*max(J));
       for i=1:degP+1
           Po(:,(i-1)*max(J)+1:(i-1)*max(J)+cP)=Pt(:,(i-1)*cP+1:i*cP);
       end
       Pt=Po;, cP=max(J);
   end

   if (degP > degM)&(isempty(M)==0)
       Mt=[Mt, zeros(rM,cM*(degP-degM))];
       degM=degP;
    elseif degM > degP
       Pt=[Pt, zeros(rP,cP*(degM-degP))];
       degP=degM;
   end

   Ia = cP*ones(size(J));

   Iaux=J;
   for i=1:degP
       Iaux=[Iaux,i*Ia+J];
   end
   if typeM=='empt'
      Pt(:,Iaux)=[];
     else   
      Pt(I,Iaux)=Mt;
   end
   S = ppck(Pt,degP);
elseif typeM=='empt'
      P(:,J)=M; S=P;
else
      P(I,J)=M; S=P;
end
