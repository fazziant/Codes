%xaybc
%
% The function
%
%  [X0,Y0,R,S] = xaybc(A,B,C[,tol][,'minimal])
%  [X0,Y0,R,S] = xaybc(A,B,C[,tol],'res'[,'minimal'])
%  [X0,Y0,R,S] = xaybc(A,B,C[,tol],'elo'[,'minimal')
%  [X0,Y0,R,S] = xaybc(A,B,C[,tol],'int'[,'minimal'][,degx][,sj[,alpha]])
%
% solves the polynomial matrix equation
%
%     XA + YB = C
%
% If only two output arguments X0, Y0 are present then the macro 
% computes only a particular solution. If C is a zero matrix then 
% the rows of [X Y] form a polynomial basis for the left null space 
% of [A' B']'. If no polynomial solution exists then X0 = Y0 = [].
%
% If all output argument are present then a polynomial basis for the 
% left null space of [A' B']' is computed. This allows to parametrize
% all solutions of XA + YB =C as
%
%    X = X0 + T*R
%    Y = Y0 + T*S
%
% where T is an arbitrary polynomial matrix of compatible dimensions.
% If [A' B']' has full row rank then R = S = [].
%
% The optional argument tol is used to decide whether a solution 
% exists and to perform kernel extraction. If tol is negative then it 
% takes its default value.
%
% The string 'res' indicates that the solution is computed by the
% resultant method. This is the default method.
%
% The string 'elo' indicates that elementary row operations are used.
%
% The string 'int' means that the solution is computed via polynomial 
% interpolation. In this case the optional input argument degx is 
% the expected degree of X0; sj is a vector containing k distinct 
% interpolation points, and alpha contains k nonzero vectors, each
% with length cA. The minimum number of interpolation points is 
% k = sum(di) + cA(degx+1), where the entries of di are the column 
% degrees of [A' B']'. If degx, sj or alpha is missing then the  
% program uses simple formulas for their construction.
%
% If the option 'minimal' is present then the function computes a 
% solution with minimal column degrees of Y0. 

% functions used: xab, prowjoin, psel, pdiv, psub, pmul

% COPYRIGHT S. Pejchova, D. Henrion, M. Sebek 1997
% $Revision: 1.1 $      $Date: 1997/06/09 13:15:08 $    $State: Exp $

function [X0,Y0,R,S] = xaybc(A,B,C,arg4,arg5,arg6,arg7,arg8,arg9)

method='res'; test1=0; tol=-1; minim=0; argm=[];
if nargin<3
   test1=1;
elseif isstr(A) | isstr(B) | isstr(C)
   test1=1;
elseif nargin > 3
   if ~isstr(arg4)
      if length(arg4)==1, tol=arg4;
      else, test1=1;
      end
   end
   for i=4:min([6,nargin])
       stg=['arga=arg',int2str(i),';'];
       eval(stg);
       if strcmp(arga,'elo'), method='elo'; argm=i;
       elseif strcmp(arga,'int'), method='int'; argm=i;
       elseif strcmp(arga,'res'), argm=i;
       elseif strcmp(arga,'minimal'), minim=1; argm=i;
       elseif isstr(arga), test1=1;
       end
   end
end 
if test1
 disp('usage: [X0,Y0,R,S] = xaybc(A,B,C[,tol]) ');
 disp('   or: [X0,Y0,R,S] = xaybc(A,B,C[,tol],''res''[,''minimal'']) ');
 disp('   or: [X0,Y0,R,S] = xaybc(A,B,C[,tol],''elo''[,''minimal'')  ');
 disp('   or: [X0,Y0,R,S] = xaybc(A,B,C[,tol],''int''[,''minimal''][,degx][,sj][,alpha])');
 return
end


[typeA,rA,cA,degA] = pinfo(A);
[typeB,rB,cB,degB] = pinfo(B);
if isempty(A) | isempty(B) | isempty(C)
   X0=[]; Y0=[]; R=[]; S=[];  
   return
end;

if (cA ~= cB)
  error('xaybc: Inconsistent dimensions of the input matrices.');
end;

strout=['=xab(prowjoin(A,B),C,tol,method'];
if ~isempty(argm)
   if nargin>argm
     for i=argm+1:nargin
       strout=[strout,',arg',int2str(i)];
     end
   end
end
strout=[strout,');'];
if nargout>2 | minim
   strout=['[XY,RS]',strout];
else
   strout=['XY',strout];
end
eval(strout,'error(lasterr)');

if ~isempty(XY),
    X0 = psel(XY, ':', 1:rA);
    Y0 = psel(XY, ':', rA+1:rA+rB);
else
    X0 = []; Y0 = [];
end;
if nargout > 2 | minim
   if ~isempty(RS),
      R = psel(RS, ':', 1:rA);
      S = psel(RS, ':', rA+1:rA+rB);
   else
      R = []; S = [];
   end
end;
if minim
   if tol >= 0
      str_tol=[',tol'];
   else, str_tol=[]; end
   str_min=['[Q,Ym]=pdiv(Y0,S,''z'''];
   str_min=[str_min,str_tol,');'];
   eval(str_min,'Q=[]; Ym=[]; ');
   Xm=[];
   if ~isempty(Ym) & ~isempty(Q)
      str_min=['Xm=psub(X0,pmul(Q,R,''z''',str_tol,'),''z''',str_tol,');'];
      eval(str_min,'Xm=[];');
   end
   if ~isempty(Ym) & ~isempty(Xm)&(norm(isnan(punpck(Xm)))<eps)&...
      (norm(isnan(punpck(Ym)))<eps)
      X0=Xm; Y0=Ym;
   else
      disp('xaybc warning: Degree cannot be reduced by division.');
   end
end
 
 
