% gld
%
% Greatest left divisor
%
% The function
%
%    G = gld(N1,N2,..,Nk[,'t',tol][,'z'[,EPS]])
%    G = gld(N1,N2,..,Nk,'res'[,'t',tol][,'z'[,EPS]])
%    [G,V,VI] = gld(N1,N2,...,Nk,'tri'[,'z'][,tol])
%
% computes a greatest left divisor G of the polynomial matrices 
% N1, N2, ..., Nk that all have the same row dimension m.
% In the form
%
%    G = gld(N1,N2,..,Nk[,'t',tol][,'z'[,EPS]])
%    G = gld(N1,N2,..,Nk,'res'[,'t',tol][,'z'[,EPS]])
%
% Gaussian elimination without row permutations is used.
% For a matrix S to be reduced the tolerance in testing for 
% nonzero pivots is
%
%    max(size(S))*1e4*eps*norm(S,'inf') by default
%    tol if both optional arguments 't' and tol are present
%
% If the optional 'z' argument is present then the result is 
% furthermore zeroed with a tolerance
%
%    1e3*eps by default;
%    EPS if this optional argument is present.
%
% In the form
%
%   [G,V,VI] = gld(N1,N2,...,Nk,'tri'[,'z'][,tol])
%
% where the method is 'tri' and k<=7, the routine relies on
% triangularization by elementary column operations. A unimodular
% matrix V is obtained so that
%
%    [N1 N2 ... Nk]*V = [G  0].
%
% For two input matrices A and B the matrix G is the greatest common 
% left divisor. The unimodular matrix V may be split into two pairs 
% of right coprime polynomial matrices (P,Q) and (R,S) such that
%
%          V = [ P R |      AP + BQ = G
%              | Q S ]      AR + BS = 0
%
% The inverse matrix VI = V^(-1) is also computed. 
% The input arguments 'z' and tol are used in "zeroing" (see 'pzero'). 
% The default value of the tolerance tol is computed from the degrees 
% and sizes of the input matrices. If 'z' and tol are missing then
% the macro runs  without "zeroing".
%
% The function is dual to grd,

% function used: grd, pinfo, ppck, pdegco, pstairs, pput,
%                pcoljoin

% COPYRIGHT S. Pejchova, D. Henrion, M. Sebek 1997
% $Revision: 1.0 $      $Date: 1997/04/25 11:10:08 $    $State: Exp $

function [G,V,VI]=gld(N1,N2,N3,N4,N5,N6,N7,N8,N9,N10)

method='res'; test1=0; argdel=[];
if nargin==0
   test1=1;
elseif isstr(N1)
   test1=1;
elseif nargin>1
   for i=2:nargin
       stg=['argm=N',int2str(i),';'];
       eval(stg);
       if isstr(argm)
          if strcmp(argm,'tri'), method='tri'; argdel=i;
          elseif strcmp(argm,'res'), argdel=i;
          elseif ~(strcmp(argm,'t')|strcmp(argm,'z'))
                 test1=1;
          end
       end
   end
end
if nargout > 1, method='tri'; end
if test1
   disp('usage: G = gld(N1,N2,..,Nk,''t'',tol,''z'',EPS) ');
   disp('    or G = gld(N1,N2,..,Nk,''res'',''t'',tol,''z'',EPS) ');
   disp('    or [G,V,VI] = gld(N1,N2,..,Nk,''tri'',''z'',tol) ');
   return
end
if ~isempty(argdel)
   argres=2:nargin; argres(argdel-1)=[];
   stgout='[G';
   if nargout==3 | strcmp(method,'tri')
      stgout=[stgout,',V,VI'];
   end
   stgall=[stgout,']=gld(N1'];
   for i=argres
       stgall=[stgall,',N',int2str(i)];
   end
   stgall=[stgall,');'];
   eval(stgall);
else
   if strcmp(method,'res')
      num = nargin; argm = ['ptransp(N1)'];
      for i = 2:num,
          argm = [argm ',ptransp(N' int2str(i) ')'];
      end;
      argm = ['ptransp(grd(' argm '))'];
      G = eval(argm,'error(lasterr)');
   elseif strcmp(method,'tri')
      zeroing=0; num=nargin;
      if nargin>1
         for ls=nargin:-1:(max(2,nargin-1))
             st=['argm=N',int2str(ls),';'];
             eval(st);
             if isstr(argm)
                if strcmp(argm,'z')
                   num=num-1;
                   if zeroing==0, zeroing=2; end
                else, num=0;
                end
             elseif length(argm)==1
                tol=argm; zeroing=1; num=num-1; 
             end
         end
      end
      if num < 1
         disp('usage: [G,V,VI] = gld(N1,N2,..,Nk,''z'',tol) ');
         return
      end
      A=N1;, F=N1;
      if num > 1
         for j=2:num
             strB=['B=N',int2str(j),';'];
             eval(strB);
             F=pcoljoin(A,B);
             A=F;
         end
      end
      [typeF,rF,cF,degF]=pinfo(F);
      if isempty(F)
         G=[];, V=[];, VI=[];
         return;
      end
      if isinf(degF) | (norm(punpck(F),inf)<eps)
         G=[]; V=[];, VI=V; return
      end
      if zeroing==2
         [G,V,VI]=pstairs(F,'z');
      elseif zeroing==1
         [G,V,VI]=pstairs(F,tol);
      else
         [G,V,VI]=pstairs(F);
      end
      [DGc,LGc]=pdegco(G,'col');
      cG=length(DGc);
      while DGc(1,cG)<0
            G=pput(G,':',cG,[]);
            DGc=pdegco(G,'col');
            cG=length(DGc);
      end
      [typeG,rG,cG,degG]=pinfo(G);
      if rG ~= cG
         disp('gld warning: The greatest left divisor is not square');
      end
   end
end
