%demo2: Signal processing example
%
% Computation of the covariance matrix function of an ARMA process

% M. Sebek, June, 1996

disp('Demo 2: Computation of the covariance matrix')
disp('        function of an ARMA process')

% Example 1

% Data

A = ppck([1 -2.4 1.43],2);
C = 1;
pdp(A,'z'),C


% Solve the polynomial equation

B = dphsym(C)
X = daxxa2b(A,B);
pdp(X,'z')


% Long division

N = 40;
r = pdiv(pshift(X,N),A);
r = punpckv(r,'rcol');
r(1) = r(1)+r(1)';

plot(0:N,r,'o')
title('Covariance function - Example 1')
xlabel('tau'), ylabel('r'), grid on


% Example 2

% Data

A = ppck([1 0 -2 0;6 1 0 -2.5],1);
C = eye(2,2);
pdp(A,'z'),C


% Solve the polynomial equation

B = dphsym(C);
X = ptransp(daxxa2b(ptransp(A),ptransp(B))); 
pdp(X,'z') 


% Long division

N = 10;
r = pdiv(pshift(X,N),A,'l'); 
r = punpckv(r,'rcol');
r(1:2,1:2) = r(1:2,1:2)+r(1:2,1:2)'; 


% Plot

figure(2), clg
subplot(2,2,1), plot(0:N,r(1:2:2*N+1,1),'o')
axis([0 N 0 1]), grid on, xlabel('tau'), ylabel('r11')
subplot(2,2,2), plot(0:N,r(1:2:2*N+1,2),'o')
axis([0 N 0 1]),grid on, xlabel('tau'), ylabel('r12')
subplot(2,2,3), plot(0:N,r(2:2:2*N+2,1),'o')
axis([0 N 0 4]),grid on, xlabel('tau'), ylabel('r21')
subplot(2,2,4), plot(0:N,r(2:2:2*N+2,2),'o')
axis([0 N 0 4]),grid on, xlabel('tau'), ylabel('r22')
