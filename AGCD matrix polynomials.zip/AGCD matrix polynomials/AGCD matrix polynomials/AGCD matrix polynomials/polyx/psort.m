%psort
%
% Sort the columns of a polynomial matrix by descending degree
%
% The command
%
%     [S,I] = psort(A)
%
% sorts the columns of the polynomial matrix A by descending degree.
% The indexes used in the sort are stored in I.

% function used: pinfo, pdegco, psel

% Rens Strijbos, S. Pejchova
% $Revision: 1.0 $      $Date: 1995/11/30 11:02:47 $      $State: Exp $     

function [S,I] = psort(A);

if nargin ~= 1
   disp('usage: [S,I] = psort(A)');
   return
end

[typeA,rA,cA,degA] = pinfo(A);
if strcmp(typeA,'empt')
   S = [];, I=[];
   return
end
if strcmp(typeA,'cons')
   A = ppck(A,0);
end
if isinf(degA)
   S=A;, I=1:cA;
   return
end

deg = pdegco(A,'col');
[deg,I] = sort(-deg);
S = psel(A,':',I);
if strcmp(typeA,'cons')
   S=punpck(S);
end
