%newtpol
%
% The command
%
%    p = newtpol(f,SJ)
%
% calculates the vector p = [p0,p1,...,pn] of coefficients
% in the Newton representation 
% 
%    p(s) = p0+p1*(s-s0) + p2*(s-s0)*(s-s1) + ...
%                    ... + pn*(s-s0)*(s-s1)* ... *(s-s(n-1))
%
% of the polynomial p(s) that results from interpolating the
% given values  p(sj) = fj for j = 0:n. 
% 
% The input parameter f is the vector f=[f0,f1,..,fn] of the 
% values in the given distinct complex points SJ = [s0,s1,...,sn].

% S. Pejchova, 1995
% $Revision: 1.1 $       $Date: 1995/12/06 16:12:57 $     $State: Exp $

function p = newtpol(f,SJ)

if nargin ~= 2
   disp('usage: p = newtpol(f,SJ) ');
   return
end

[rS,cS]=size(SJ);
[rf,cf]=size(f);
if (rS>1 & cS>1) | (rf>1 & cf>1)
   error('newtpol: The input arguments are not vectors');
end
if rS==0 | cS==0 | rf==0 | cf==0
   error('newtpol: The input vectors are empty');
end

m=length(SJ);, n=length(f);

if m~=n
   error('newtpol: Inconsistent dimensions of the input vectors');
end

p=f;
for k=1:n-1
     for i=n:-1:k+1
         p(i)=(p(i)-p(i-1))/(SJ(i)-SJ(i-k));
     end
end


