Polynomial Toolbox for MATLAB (c)
Version 1.5   30-June-97
Copyright (c) 1997 by the Polynomial Toolbox Team
Didier Henrion, Ferda Kraffer, Huibert Kwakernaak, 
Sonja Pejchova, Michael Sebek, Rens C. W. Strijbos

For all information about the Polynomial Toolbox
visit http://www.math.utwente.nl/polbox

Installation
============

PC

Copy this set of m-files in a subdirectory, for instance
c:\matlab\toolbox\polbox. To make the toolbox accessible to
MATLAB, place this line in the startup.m file in your MATLAB
work directory:

P = path; path(P,'c:\matlab\toolbox\polbox');

If the file startup.m does not exist then create it.

UNIX

Copy this set of m-files in a subdirectory, for instance
/toolbox/polbox. To make the toolbox accessible to MATLAB, 
place this line in the startup.m file in your MATLAB work 
directory:

P = path; path(P,'/toolbox/polbox');

If the file startup.m does not exist then create it.