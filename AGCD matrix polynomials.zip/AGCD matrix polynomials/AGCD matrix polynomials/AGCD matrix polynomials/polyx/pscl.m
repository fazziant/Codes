%pscl
%
% Multiply a polynomial matrix by a scalar
%
% The command
%
%    C = pscl(A,factor)
%
% multiplies the polynomial matrix A by the scalar number factor, 
% that is, all elements of A are multiplied by this number.

% $Revision: 1.4 $	$Date: 1997/04/15 14:43:52 $	$State: Exp $

function C = pscl(A,factor)

if nargin ~= 2
   disp('usage: C = pscl(A,factor)')
   return
end

[rf,cf] = size(factor);
if rf ~= 1 | cf ~= 1
   error('pscl: The second argument should be a scalar')
   return
else
   [typeA,rA,cA,degA] = pinfo(A);

   if typeA == 'poly'
      C = punpck(A);
      C = factor * C;
      if degA < 0, degA=0; end
      C = ppck(C,degA);
   else
      C = factor * A;
   end
end
