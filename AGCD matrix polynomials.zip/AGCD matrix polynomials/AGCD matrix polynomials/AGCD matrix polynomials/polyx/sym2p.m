% sym2p
%
% Symbolic to polynomial matrix format
%
% The function
%
%    Apoly = sym2p(Asym[,var])
%
% converts a symbolic matrix Asym of the Symbolic Toolbox format
% into a polynomial matrix Apoly of the Polynomial Toolbox format,
%
% Entries in Asym must be simplified polynomial expressions in the 
% single indeterminate 'var' (with default value 's').

% Henrion D. 5-97
% Modified by S. Pejchova, June 26, 1997
%
% functions used :
% Symbolic Toolbox : sym, symsize, collect, maple
% Polynomial Toolbox : ppck, pput

function Apoly = sym2p(Asym,var)

if nargin < 1
 disp('usage:  Apoly = sym2p(Asym[,var])');
 return
end
if nargin == 1,
  var = 's';
elseif ~isstr(var),
  error('Input argument ''var'' must be a string');
end;

[nr,nc] = symsize(Asym);
Apoly = ppck(zeros(nr,nc),0);

for r = 1:nr,
 for c = 1:nc,

  p = sym(Asym,r,c); % extract symbolic polynomial entry
  p = collect(p,var); % collect polynomial coefficients

  % access Maple kernel to extract symbolic coefficients
  maple(['ans := ' p]);
  [coef status] = maple(['seq(coeff(",' var ',k),k=0..degree(ans))']);
  if status > 0, % error raised by Maple
    error(['entry (' int2str(r) ',' int2str(c) ') is not ' ...
           'polynomial']);
  end;

  % try to evaluate symbolic coefficients
  error_string = ['error([''entry ('' int2str(r) '','' int2str(c) '') ' ...
     'cannot be evaluated''])'];
  coef = eval(['[' coef ']'], error_string);

  % build corresponding polynomial entry
  if ~isempty(coef),
    Apoly = pput(Apoly, r, c, ppck(coef, length(coef)-1));
  else
    eval(error_string);
  end;

 end; % for each column
end; % for each row
  
