%pdegco
%
% Various degrees and corresponding leading coefficient matrices of
% a polynomial matrix
%
% The command
%
%    [degP,PL] = pdegco(P) 	    returns the degree degP and the 
%                                   leading coefficient matrix PL
%                                   of the polynoial matrix P.
%    Pi = pdegco(P,i)               returns the coefficient matrix Pi 
%                                   corresponding to the power i.
%    [degPr,Pr] = pdegco(P,'row')   returns the vector of row degrees 
%                                   of P and the row leading 
%                                   coefficient matrix Pr.
%    [degPc,Pc] = pdegco(P,'col')   returns the vector of column 
%                                   degrees of P and the column 
%                                   leading coefficient matrix Pc.
%    [DEGP,PL] = pdegco(P,'ent')    returns the matrix DEGP of degrees
%                                   of the entries of P and the matrix
%                                   PL of the corresponding scalar 
%                                   leading coefficients. 
%    [DEGP,PL] = pdegco(P,'dia')    returns for a para-Hermitian 
%                                   polynomial matrix P(s) = P'(-s) 
%                                   a vector DEGP of half diagonal 
%                                   degrees of P and the diagonal 
%                                   leading coefficient matrix PL.

% S. Pejchova, 1995
% Modif. Henrion D. 6-96 option (6)
% Henrion D. 4-97 case when diagonal degrees are not unique
% $Revision: 1.3 $	$Date: 1996/04/18 15:35:22 $	$State: Exp $

function [DEGP,PL] = pdegco(P,L)

if nargin < 1
   disp('usage: [degP,PL] = pdegco(P) ');
   disp('   or: [Pi] = pdegco(P,i) ');
   disp('   or: [degPr,Pr] = pdegco(P,''row'') ');
   disp('   or: [degPc,Pc] = pdegco(P,''col'') ');
   disp('   or: [DEGP,PL] = pdegco(P,''ent'') ');
   disp('   or: [DEGP,PL] = pdegco(P,''dia'') ');
   return
end

[typeP,rP,cP,degP] = pinfo(P);
if typeP == 'cons'
   if max(max(norm(P,1))) > 0,
     degP=0;
   else
     degP=-Inf;
   end;
end

if nargin == 1
   L=degP;
end

if typeP == 'poly' | typeP =='cons'
   if isstr(L)==0                            %%%% [Pi] = pdegco(P,i)
       if degP < 0
           PL=zeros(rP,cP);
           DEGP=-Inf;
           if nargin == 2 & nargout <= 1,
	     DEGP=PL;
           end;
       elseif (L > degP) | ((L < 0)&(degP>=0))
           error('pdegco: The second input argument exceeds the degree of the polynomial matrix');
       else
           PL=P(1:rP,L*cP+1:cP*(L+1));
           DEGP=L;
           if nargin ==2 & nargout <= 1
              DEGP=PL;
           end
       end

   elseif (L(1:3)=='ent') | (L(1:3)=='row') | (L(1:3)=='col') | (L(1:3)=='dia')
     if degP >= 0

       if L(1:3)=='ent'                %%%% [DEGP,PL] = pdegco(P,'ent')

           DEGP=zeros(rP,cP); PL=zeros(rP,cP);
           Paux1=ones(rP,cP);

           for i=degP+1:-1:1
               Paux2=Paux1.*P(1:rP,cP*(i-1)+1:cP*i);
               R = Paux2 & Paux2;
               DEGP=DEGP+(i-1)*R;
               PL=PL+Paux2;
               R = ~R;
               Paux1=R.*Paux1;
           end
           [I,J]=find(Paux1);
           if ~(isempty(I))
              for k=1:length(I)
                  DEGP(I(k),J(k))=-inf;
              end
           end

       elseif L(1:3)=='row'                  %%%% [degPr,Pr] = pdegco(P,'row')
           [DEGP,PR]=pdegco(P,'ent');
           if (cP > 1),
             DEGP=max(DEGP')';
           end;
           PL=zeros(rP,cP);

           for j=1:rP
               if DEGP(j) >= 0
                  PL(j,:)=P(j,(DEGP(j)*cP+1):cP*(DEGP(j)+1));
               end
           end


       elseif L(1:3)=='col'
                                        %%%% [degPc,Pc] = pdegco(P,'col')
           [DEGP,PC]=pdegco(P,'ent');
           if (rP > 1),
             DEGP=max(DEGP);
           end;
           PL=zeros(rP,cP);

           for i=1:cP
               if DEGP(i) >= 0
                  PL(:,i)=P(1:rP,DEGP(i)*cP+i);
               end 
          end

       elseif L(1:3)=='dia'        %%%%%% for para-Hermitian P, pdegco(P,'dia')

	[typeP,n,cP,degP] = pinfo(P);
	if (n ~= cP),
		error('pdegco: The input matrix is not square');
	end;
	if ~isinf(pdegco(pzero(psub(P,cjg(P))))),
		error('pdegco: The input matrix is not para-Hermitian');
	end;

	D = pdegco(P,'ent'); % entry degrees
	T = isinf(D);
	% entry degrees -Inf corresponding to zero polynomials
	% are set to 0
	for i = 1:n,
		rowT = T(:,i);
		if any(rowT),
			% zero polynomial is of zero degree
			D(rowT,i) = zeros(sum(rowT),1);
		end;
	end;

	% are diagonal degrees half the degrees of diagonal entries ?
	halfdiag = 1;
        for i = 1:n, for j = i+1:n,
		if 2*D(i,j) > D(i,i)+D(j,j),
			halfdiag = 0;
		end;
	end; end;
	
	if halfdiag,

		% if halfdiag = 1 diagonal degrees are half the
		% degrees of diagonal entries

		ddiag = diag(D)/2;
	
	else

		disp('pdegco warning: The half diagonal degrees are not unique');

		% computation of the
		% smallest diagonal degrees sdiag(i) such that D(i,j) <= di+dj
		ddiag = [D(1,1)/2 zeros(1,n-1)];
		for i = 2:n,
			ddiag(i) = max([D(i,1:i-1)-ddiag(1:i-1) D(i,i)/2]);
		end;

	end; % if halfdiag

	PL = zeros(n); % diagonal leading coefficient
	for i = 1:n, for j = 1:n,
		if ddiag(i)+ddiag(j) <= degP,
			b = P(i,j+(ddiag(i)+ddiag(j))*n);
			PL(i,j) = (-1)^ddiag(i)*b;
		end;
	end; end;

	DEGP = ddiag;

      end

     else                            %%%%%  degP < 0

       PL=zeros(rP,cP);
       if L=='ent'
           DEGP=-inf*ones(rP,cP);
       elseif L=='row'
           DEGP=-inf*ones(rP,1);
       else
           DEGP=-inf*ones(1,cP);
       end
     end
   else
       error('pdegco: Illegal input string');
   end
else
   DEGP=[];
   PL=[];
end
