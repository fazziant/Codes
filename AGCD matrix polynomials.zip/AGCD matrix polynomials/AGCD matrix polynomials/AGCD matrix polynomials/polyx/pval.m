%pval
%
% Evaluate a polynomial matrix
%
% The function
%
%    AL=pval(S,SJ)
%
% evaluates the polynomial matrix S in the complex point SJ.
% If SJ is a vector of points SJ = [s1,s2,...,sL]  then
% AL is a block "vector" of values AL = [S(s1),S(s2),...,S(sL)].
 
% used function: pinfo

% S. Pejchova, R.C.W. Strijbos, 1996
% $Revision: 1.4 $       $Date: 1997/06/27 18:33:07 $     $State: Exp $

function [AL] = pval(S,SJ)

if nargin ~= 2
   disp('usage: [AL] = pval(S,SJ)');
   return
end

[typeS,rS,cS,degS]=pinfo(S);
S=punpck(S);
if typeS == 'empt'
   AL=[];
else
   if isnan(degS)
      degS=0;
   end
   [rL,cL]=size(SJ);
   if isempty(SJ)
      error('pval: The vector of evaluation points is empty. ');
   elseif  rL>1 & cL>1
      error('pval: The evaluation points input is not a vector. ');
   else
      L=length(SJ);
      if norm(S) < eps
         AL=zeros(rS,L*cS);
      else
         SJF=ones(rS,1)*SJ;
         onesSJ=ones(size(SJ));
         for c = 1:cS
             ALc=S(1:rS,c+degS*cS)*onesSJ;
             for i=degS:-1:1
                 ALc=ALc.*SJF+S(1:rS,c+(i-1)*cS)*onesSJ;
             end
             for n=1:L
                 AL(:,c+(n-1)*cS)=ALc(:,n);
             end
         end
      end
   end
end
