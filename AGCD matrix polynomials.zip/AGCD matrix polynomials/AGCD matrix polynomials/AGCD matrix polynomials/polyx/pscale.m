% pscale
%
% Scale a polynomial matrix
%
% The function call
%
%    Q = pscale(P,a)
%
% results in the polynomial matrix Q given by Q(s) = P(s/a).
% Without the second input argument, the call
%
%   [Q,a] = pscale(P)
%
% scales P automatically while taking the scaling factor as
%
%   a = [norm(Pd)/norm(P0)]^(1/degP)
%
% P0 is the constant coefficient matrix, and Pd the highest 
% coefficient matrix. Automatic scaling makes the norm of the
% constant coefficient matrix equal to that of the highest 
% coefficient matrix. If the automatic scaling factor a is 
% greater than 1e-4/eps then the scaling factor is reset to 1.

% H. Kwakernaak, March, 1992
% Corrected, May 22, 1992
% Revised, May 21, 1997
% Modified by S. Pejchova, June 26, 1997

function [Q,a] = pscale(P,a)

% Preparation

if nargin<1
 disp('usage:  [Q,a] = pscale(P[,a])');
 return
end
[type,rP,cP,degP] = pinfo(P);

if strcmp(type,'cons') | strcmp(type,'empt')
   Q = P;
   if nargin == 1
      a = 1;
   end
   return
else
   P = punpck(P);
end

if degP == 0
   Q = P; degQ = degP;
   if nargin == 1
      a = 1;
   end
   return
end

if nargin == 1 & degP > 0
   P0 = P(:,1:cP); 
   Pd = P(:,degP*cP+1:(degP+1)*cP);
   if norm(P0) == 0
      a = inf;
   else
      a = (norm(Pd)/norm(P0))^(1/degP);
   end
   if a > 1e-4/eps
      a = 1;
   end
end

Q = [];
for i = 0:degP
   QQ = P(:,i*cP+1:(i+1)*cP);
   Q = [Q QQ/a^i];
end

Q = ppck(Q,degP);
