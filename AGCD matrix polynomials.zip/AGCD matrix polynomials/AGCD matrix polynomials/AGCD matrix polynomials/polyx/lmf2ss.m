% lmf2ss
%
% Controller-form realization from left matrix fraction description.
%
% Given two polynomial matrices Ne and De such that
%
%    De(s) is row reduced 
%    H(s) = inv(De(s))*Ne(s) is proper
%
% the function
%
%    [A,B,C,D] = lmf2ss(Ne,De[,tol])
%
% returns the controller-form realization (A,B,C,D) of 
% H(s) = inv(De(s))*Ne(s):
%
%    H(s) = D + C*inv(sI-A)*B.
%
% If Ne(s) and De(s) are left coprime then the realization is minimal.
% The tolerance tol (with default value eps) is used in testing whether
% De is row reduced.

% Henrion D. 6-96
% $Revision: 1.1 $	$Date: 1996/10/07 14:21:54 $	$State: Exp $
% Modified by Henrion D. May 22, 1997
% - tolerance added
% - statement about minimality corrected
% Modified by S. Pejchova, June 26, 1997

% From T. Kailath "Linear Systems" Prentice-Hall 1980, pp. 406-407

% Dual of rmf2ss

function [A,B,C,D] = lmf2ss(Ne,De,tol)

if nargin < 2
 disp('usage:  [A,B,C,D] = lmf2ss(Ne,De[,tol])');
 return
end
if nargin < 3,
  [A,C,B,D] = rmf2ss(ptransp(Ne), ptransp(De));
else
  [A,C,B,D] = rmf2ss(ptransp(Ne), ptransp(De), tol);
end;

A = A'; B = B'; C = C'; D = D';

