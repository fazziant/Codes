%pinterp
%
% Interpolation of a polynomial matrix
%
% The function
%
%    Q = pinterp(R,s)
%
% computes the polynomial matrix Q of degree q-1 so that
%
%    Q(si) = Ri, i = 1, 2, ..., q 
% 
% with q the number of interpolation points.
%
%    R = [R1 R2 ... Rq] 
%
% is the row block matrix of the interpolation values, and
%
%    s = [s1 s2 ... sq] 
%
% is the row or column vector of the interpolation points.

% Henrion D. 2-96
% uses ppck

function Q = pinterp(R,s)

if nargin ~= 2,
  disp('usage: Q = pinterp(R,s)');
  return;
elseif (size(s,1) ~= 1) & (size(s,2) ~= 1),
  error('pinterp: The second input argument must be a vector');
else
  if size(s,2) == 1,
    s = s'; % s must be a row vector
  end;
  q = size(s,2);
  [p, m] = size(R); m = m/q;
  if round(m) ~= m,
    error('pinterp: The input arguments must have the same number of elements');
  end;
end;  

d = q-1; % degree of polynomial matrix Q
Rl = zeros(p, q); Ql = zeros(p, m*(d+1)); Q = zeros(p, m*(d+1));

for cQ = 1:m,
 for np = 1:q,
  Rl(:, np) = R(:, cQ+(np-1)*m);
 end;
 for rQ = 1:p,

  % resolution of the Vandermonde system
  % using the special method based on Newton polynomial
  % described in G. H. Golub, C. E. Van Loan "Matrix computations"
  % 2nd edition - Johns Hopkins University Press, p. 178

  for k = 0:d-1,
   for i = d:-1:k+1,
    Rl(rQ, i+1) = (Rl(rQ, i+1) - Rl(rQ, i))/(s(i+1) - s(i-k));
   end;
  end;
  for k = d-1:-1:0,
   for i = k:d-1,
    Rl(rQ, i+1) = Rl(rQ, i+1) - Rl(rQ, i+2)*s(k+1);
   end;
  end;
  Ql(rQ, 1+(cQ-1)*(d+1):cQ*(d+1)) = Rl(rQ, :);

 end;
end;

for dQ = 1:d+1,
 for cQ = 1:m,
  Q(:,cQ+(dQ-1)*m) = Ql(:,dQ+(cQ-1)*(d+1));
 end;
end;

Q = ppck(Q, d);



