function TP = blktoep(P, n, T)
m = size(P, 1);
l1 = size(P, 2) / n;

TP = zeros((T+1) * m, (l1 + T - 1) * n + m);
for i = 1:T+1
    TP((i - 1) * m + (1:m), (i - 1) * m + (1:size(P,2))) = P;
end