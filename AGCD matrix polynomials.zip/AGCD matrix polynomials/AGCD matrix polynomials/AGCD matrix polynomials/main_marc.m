% main_marc.m
clear all
close all
rng(123)        % reset random number generator
noise = linspace(0,1,6);
% for nnoise = 2:6
%     for nsample = 1:50
%         [nnoise,nsample]
%         pause
%         rng(nsample);
        dP = 3; d = 1; m = 2; n = 2;
        C0 = [eye(m); rand(m*d,m)]';
        P0 = [];
        dA = dP - d;
        A0 = rand(m * (dA + 1), m*n)';
        P0 = (A0*blktoep(C0, m, dA) );
        for nnoise = 1:6
    for nsample = 1:5
        nnoise
        nsample
        P = P0 + noise(nnoise) * randn(size(P0));
        dim=m;
        deg=d;
         [dist, Phat, P, C]=AGCDmat(P,dim,deg,P0,noise,nnoise);
        Gode(nsample,nnoise) = dist;
        [G2, ~, dH] = alcf_ss(P', m, deg);
        Gss(nsample,nnoise) = dH;
        [Cfmin, Ph, f, ~] = alcf(P', m, d, C);
          Gfmin(nsample,nnoise) = f;
          
    end
end
