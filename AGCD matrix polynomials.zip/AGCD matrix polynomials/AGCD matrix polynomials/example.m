clear
close all

dP = 3; d = 1; m = 2; n = 2;
 C0 = [eye(m); rand(m*d,m)]';
 P0 = [];
 dA = dP - d;
 A0 = rand(m * (dA + 1), m*n)';
 P0 = (A0*blktoep(C0, m, dA) );
  P = P0 + .1 * randn(size(P0));
 P1=P(1:m,:);
 P2=P(m+1:end,:);
 dim=m;
 deg=d;

 w=5;