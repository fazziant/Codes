function [ dist,A,E,Phat] = dist_agcd(P,dim,deg,tol,itmax)


if nargin<5
    itmax=40;
end

h0=1e-6;
threshold=1e-6;
c=0.5;
epsval=[];
sval=[];
kappa=.001;

mP=size(P,1)/dim;
nP=size(P,2)/dim;
n=nP-1;
% w=n*(1+dim)-2;

%construction of A
P1=P(1:dim,:);
P2=P(dim+1:end,:);
w=deg*(dim+1);
A=[blktoep(P1,1,w); blktoep(P2,1,w)];
[mA,nA]=size(A);


%starting values
S=svd(A);
sval=S(end+1-dim*deg);
epsmin=1e-8;   

 epsmax=norm(A,'fro');
eps0=min(2*epsmin,(epsmin+epsmax)/2)



 [zvec,x,y,A,B,E]=ode_c(P,dim,deg,eps0,w,h0);

%
%

   sval=[sval, zvec(end)];
dist=0;
Phat=P;
   
     it=0;
  while sval(end) > threshold
       it=it+1;
      epsval(it)=eps0;

    
          epsmin=eps0;

     [U,Sigma,V]=svd(B);
     sigma=diag(Sigma);
     l=length(sigma);
% %      
          x=V(:,l+1-dim*deg);
     y=U(:,l+1-dim*deg);
    xT=x';
%   
      z = sigma(end+1-dim*deg); 
    
%            
%      %%%%%%%%%%%%  add a constant      
         eps0=eps0+.2;
%    

    disp('integration of ODE')
    
    disp('freedyn')
 [zvecf,xf,yf,Af,Bf,Ef]=ode_free(P,dim,deg,epsval(end),eps0,w,h0,epsval(end)/eps0*E);

 
  sval=[sval, zvecf(end)];
   eps0= eps0*norm(Ef,'fro');

 disp('condyn')
 [zvec,x,y,A,B,E]=ode_c(P,dim,deg,eps0,w,h0,Ef);

zvecf(end), zvec(1);
     disp('completed')

 sval=[sval, zvec(end)];
 if sval(end) < threshold
     epsval=[epsval, eps0];
 end

B=A+eps0*E;
Phat(1:dim,:)=B(1:dim,1:dim*(n+1)); 

Phat(dim+1:2*dim,:)=B(size(B,1)/2+1:size(B,1)/2+dim,1:dim*(n+1)); % 2 is the half not the dimension
D=[dist, norm(Phat-P,'fro')];
  end
 dist=sum(D); 