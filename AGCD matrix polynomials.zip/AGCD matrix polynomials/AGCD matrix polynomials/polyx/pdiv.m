%pdiv
%
% Polynomial matrix division
%
% For a given polynomial matrix N and a given square nonsingular
% polynomial matrix divisor D the function calculates the polynomial 
% matrix quotient Q and polynomial matrix remainder R.
%
% In the form
%
%    [Q,R] = pdiv(N,D)           
%    [Q,R] = pdiv(N,D,'r')           the macro performs right 
%                                    polynomial matrix division such 
%                                    that N = Q*D + R such that the 
%                                    rational matrix R*D^(-1) is
%                                    strictly proper;
%
%    [Q,R] = pdiv(N,D,'l')           the macro performs left 
%                                    polynomial matrix division such 
%                                    that N = D*Q + R with D^(-1)*R 
%                                    is strictly proper.
% In the form
%
%    [Q,R] = pdiv(N,D,'z'[,tol])
%    [Q,R] = pdiv(N,D,'r','z'[tol])
%    [Q,R] = pdiv(N,D,'l','z'[tol])  "zeroing" is performed (see the 
%                                    function 'pzero'). The default 
%                                    value of the optional tolerance 
%                                    parameter tol is computed from 
%                                    the degree and sizes of the input
%                                    matrices. If 'z' and tol are 
%                                    missing then the macro runs 
%                                    without "zeroing".

% functions used:  pinfo, punpck, ptransp, pscl, pcolred, pmul, pdegco,
%                  ppck, padd, psub, psel, pput, pzero

% COPYRIGHT S.Pejchova, M. Sebek  1997
% $Revision: 1.1 $	$Date: 1997/06/28 13:31:51 $	$State: Exp $

function [Q,R] = pdiv(No,Do,arg3,arg4,arg5)

test1=0; tol=eps; zeroing=0; divtype=0;
if nargin<2
   test1=1;
elseif isstr(No) | isstr(Do)
   test1=1;
elseif nargin>2
   for i=3:nargin
       stg=['argm=arg',int2str(i),';'];
       eval(stg);
       if isstr(argm)
          if  strcmp(argm,'l')
             divtype=1; 
          elseif strcmp(argm,'z')
             if zeroing==0, zeroing=2; end   
          elseif ~strcmp(argm,'r')
              test1=1;
          end
       elseif length(argm)==1
          tol=argm; zeroing=1;
       else
          test1=1;
       end
   end
end

if test1 
   disp('usage: [Q,R] = pdiv(N,D,''z'',tol) ');
   disp('or     [Q,R] = pdiv(N,D,''r'',''z'',tol) ');
   disp('or     [Q,R] = pdiv(N,D,''l'',''z'',tol) ');
   return
end

[typeN,rN,cN,degN]=pinfo(No);
[typeDo,rDo,cDo,degDo]=pinfo(Do);
if isempty(No) | isempty(Do)
   Q=[]; R=[]; return
end
if rDo~=cDo
   error('pdiv: The matrix divisor is not square');
end

if typeDo=='cons' & typeN=='cons'
   if divtype, Q=Do\No; else, Q=No/Do; end
   R=zeros(rN,cN);
   return;
end
NormN=norm(punpck(No));
NormD=norm(punpck(Do));
Nx=No; Dx=Do;

if divtype
   No=ptransp(No); Nx=ptransp(Nx); Dx=ptransp(Dx);
   Do=ptransp(Do); nnx=cN; cN=rN; rN=nnx;
end
if (rDo > 1) & (cN ~= rDo), % division by a polynomial is always possible
   error('pdiv: The input matrices are not compatible');
end
if degDo <= 0 | isnan(degDo)
   No=punpck(No); Do=punpck(Do);
   Q=No(:,1:cN)/Do; R=ppck(zeros(rN,cN),0);
   if isnan(degN)|degN<0, degN=0; end
   if degN>0
      for i=1:degN
          Q=[Q,No(:,(cN*i+1):(i+1)*cN)/Do];
      end
   end
   Q=ppck(Q,max(0,degN));
   if divtype, Q=ptransp(Q); R=ptransp(R); end
   return
end

if isinf(degN) | NormN<tol
   if divtype
      Q=ppck(zeros(cN,rN),0); R=ppck(zeros(cN,rN),0);
   else
      Q=ppck(zeros(rN,cN),0); R=ppck(zeros(rN,cN),0);
   end
   return
end

if NormN==0, NormN=1; end
if NormD==0, NormD=1; end
No=pscl(No,1/NormN); Do=pscl(Do,1/NormD);
if zeroing==2
   tol=(max(max(size(punpck(No))),max(size(punpck(Do)))))*eps*1e2;
elseif zeroing==1
   tol=tol*(NormD/NormN);
end

[D,Ur,UIr]=pcolred(Do);             % D in column reduced form D=Do*Ur
[typeD,rD,cD,degD]=pinfo(D);
N=pmul(No,Ur);
if typeD=='cons', degD=0; typeD='poly'; D=ppck(D,0); end

E=eye(rD);, degE=0;, degDif=zeros(1,cD);
DL=pdegco(D,degD);
if det(DL)==0
   [degDc,Dc]=pdegco(D,'col');
   degDif=degD-max(degDc,0);
   degE=max(degDif);   
   if isinf(degE), degE=0;, end
   if degE > 0
      E=[E,zeros(rD,degE*cD)];
      for i=1:cD
          if degDif(i) > 0
             E(:,degDif(i)*cD+i)=E(:,i);
             E(:,i)=zeros(rD,1);
          end
      end
   end
end

EP=ppck(E,degE);
if zeroing > 0
   NE=pmul(N,EP,'z',tol); DE=pmul(D,EP,'z',tol);
else
   NE=pmul(N,EP); DE=pmul(D,EP);       % DE regular pol.matrix DE=D*EP    
end

R=NE;
Q=ppck(zeros(rN,cN),0);

[degNE,NEL]=pdegco(NE);
[degDE,DEL]=pdegco(DE);

while degNE >= degDE
      L=NEL/DEL;
      LS=ppck([zeros(rN,cN*(degNE-degDE)),L],(degNE-degDE));
      W=isinf(L);
      if norm(W-ones(size(W)),inf) < tol
         Q=LS;
         R=ppck(zeros(rN,cN),0);
         break;
      end
      if zeroing > 0
         R=psub(R,pmul(LS,DE,'z',tol),'z',tol);
         Q=padd(Q,LS,'z',tol);
      else, R=psub(R,pmul(LS,DE)); Q=padd(Q,LS);
      end
      [degNE,NEL]=pdegco(R);
end

if degE > 0
   for i=1:cN
       if degDif(i)>0
          SR=psel(R,':',i);
          [m,n]=size(SR);
          if isinf(SR(1,n))==0
             Sred=SR(1:rN,(1+degDif(i)):degNE+1);
             SP=ppck(Sred,(degNE-degDif(i)));
             R=pput(R,':',i,SP);
          end
       end
    end
end
if zeroing > 0
   R=pmul(R,UIr,'z',tol);
else
   R=pmul(R,UIr);
end
if zeroing > 0
   Q=pzero(Q,tol); R=pzero(R,tol);
end

Q=pscl(Q,NormN/NormD);
R=pscl(R,NormN);

Res=(norm(punpck(psub(Nx,padd(pmul(Q,Dx),R)))))/max(NormN,NormD);
if Res > tol*(NormN/NormD)*1e4
   disp(' ');
   disp(sprintf('pdv warning: The relative residue of calculation is  %g',Res));
   disp('             Try to change the tolerance.');
end

if divtype
   Q=ptransp(Q);
   R=ptransp(R);
end
