%pcolred
%
% The function 
%
%    [D,V,VI,residue] = pcolred(A[,'z'][,tol])
% 
% brings the polynomial matrix A into column reduced form D by
% elementary column operations. D = A*V, where V is the unimodular 
% transform. matrix. The columns of D are arranged according to 
% descending degree. If the input matrix A does not have full 
% column rank then it is reduced to the form  D = [D~ 0], with 
% D~ column reduced.
%
% The input arguments 'z' and tol are used in "zeroing" (see the
% function 'pzero') and in determining the rank of the leading 
% coefficient matrix. The default value of tol is computed from the
% degree and sizes of A. If 'z' and tol are missing then the macro 
% runs without "zeroing".
%
% The unimodular matrix VI is the inverse of V. The output argument 
% residue is the relative residue of calculation.

% functions used: pinfo, ppck, pdegco, pmul, pput

% R. Strijbos, S. Pejchova, 1997
% $Revision: 1.5 $      $Date: 1997/04/08 10:02:11 $    $State: Exp $

function [D,V,VI,residue] = pcolred(A,arg2,arg3)

test1=0; tol=eps; zeroing=0;
if nargin==0
   test1=1;
elseif isstr(A)
   test1=1;
elseif nargin>1
   for i=2:nargin
       stg=['argm=arg',int2str(i),';'];
       eval(stg);
       if isstr(argm)
          if strcmp(argm,'z')
             if zeroing==0, zeroing=2; end   
          else
             test1=1;
          end
       elseif length(argm)==1
          tol=argm; zeroing=1;
       else
          test1=1;
       end
   end
end

if test1
   disp('usage: [D,V,VI,residue]=pcolred(A,''z'',tol) ');
   return
end

[typeA,rA,cA,degA]=pinfo(A);

V=ppck(eye(cA),0);, VI=V;, residue=0;
if isempty(A) | isinf(degA)
   D=A;
   return
end
if isnan(degA)
   degA=0;, A=ppck(A,degA);
end

if degA < 0
   D=A;
else
   D=ppck(A(1:rA,1:(1+degA)*cA),degA);      %'clearing'
end

[typeD,rD,cD,degD]=pinfo(D);
if isinf(degD)
   if strcmp(typeA,'cons')
      D=punpck(D); V=punpck(V); VI=V;
   end
   return
end

Degofcol=pdegco(D,'col');
fd=find(~isinf(Degofcol));
degofre=sum(Degofcol(fd));
NormD=norm(punpck(D)); 
if cD > 1

D=pscl(D,1/NormD); 
if zeroing==2
   tol=norm(punpck(D))*(max(size(punpck(D))))*eps*1e2;
elseif zeroing==1
   tol=tol/NormD;
end

nullL=eye(cD);
b=(degD+1)*cD+2;
Eps=1; epsold=eps;
                                              %MAIN LOOP
while (norm(Eps) > tol) & (b > 0) 
      [DegD,Dlc] = pdegco(D,'col');
      act=find(DegD >= 0);

      eps_=tol;
      nullL=null(Dlc(:,act));
      eps_=epsold;

      if isempty(nullL)                       %cancel extraction procedure
         break;
      end                                
      e=zeros(cD,1);
      e(act)=nullL(:,1);
      act=find(abs(e)>tol*norm(e));
      act=act';
      hact=find(DegD(act)==max(DegD(act)));
      hact=act(hact);
      k=find(abs(e(hact))==max(abs(e(hact))));
      k=hact(k(1));                           %pivot
      T=ppck(eye(cD),0);, TI=T;
      for i=1:cD
          if (i~=k) & (abs(e(i)) > tol*norm(e))
             degs=DegD(k)-DegD(i);
             s=[zeros(1,degs),1]*e(i)/e(k);
             T=pput(T,i,k,ppck(-s,degs));
             TI=pput(TI,i,k,ppck(s,degs));
          end
      end
      if zeroing > 0
         D=pmul(D,TI,'z',tol);
         V=pmul(V,TI,'z',tol); VI=pmul(T,VI,'z',tol);
       else
         D=pmul(D,TI);
         V=pmul(V,TI); VI=pmul(T,VI);
       end
      [Dga,Dla]=pdegco(D,'col');
      if Dga(k)==DegD(k)
         Daux=punpck(D);
         Daux(:,DegD(k)*cD+k)=zeros(rD,1);
         D=ppck(Daux,max(DegD));
      end

      Eps=punpck(psub(T,eye(cD),'z',tol));
      b=b-1;
end   
if b==0 | (norm(Eps) <= tol)  
   disp('pcolred warning: Reduction terminated - infinite loop.')
end
if zeroing > 0, D=pzero(D,tol); end
DegD=pdegco(D,'col');
fnew=find(~isinf(DegD));
degsum=sum(DegD(fnew));
D=pscl(D,NormD);
[D,I] = psort(D);                             %column  degrees  in
V = psel(V,':',I);                            %   descending order
VI = psel(VI,I,':');
if (degsum>=0)&(degsum > degofre)
   disp(' ');
   disp('pcolred warning: The resulting degree may not be correct!');
   disp('                 Try to change the tolerance.');
end

end %(cD>1)
if NormD ~= 0                                 %residue check
   residue = (norm(punpck(psub(D,pmul(A,V)))))/NormD;
 else
   residue = norm(punpck(psub(D,pmul(A,V))));
end
if strcmp(typeA,'cons')
   [typeD,rD,cD,degD]=pinfo(D);
   [typeV,rV,cV,degV]=pinfo(V);
   [typeVI,rVI,cVI,degVI]=pinfo(VI);
   if degD <= 0, D=punpck(D);, end
   if degV <= 0, V=punpck(V);, end
   if degVI <= 0, VI=punpck(VI);, end
end
