%pcoljoin
%
% The command
%
%    P = pcoljoin(P1,P2)
%
% results in a polynomial matrix P given by
%
%    P = [P1 P2]

% $Revision: 1.3 $	$Date: 1996/07/19 09:11:25 $	$State: Exp $

function P = pcoljoin(P1,P2)

if nargin ~= 2
   disp('usage: P = pcoljoin(P1,P2)')
   return
end

[typeP1,rP1,cP1,degP1] = pinfo(P1);
[typeP2,rP2,cP2,degP2] = pinfo(P2);

if typeP1 == 'poly' | typeP2 == 'poly'
   P1 = punpck(P1);
   P2 = punpck(P2);
   if isempty(P1)
      P = P2;
      degP = degP2;
   elseif isempty(P2)
      P = P1;
      degP = degP1;
   else
      if isnan(degP1)
         degP1 = 0;
      end
      if isnan(degP2)
         degP2 = 0;
      end
      if rP1 ~= rP2
         error('pcoljoin: The input matrices have different numbers of rows');
      end
      rP = rP1; cP = cP1+cP2;
      if degP1 >= degP2
         degP = degP1;
      else
         degP = degP2;
      end
   
      P = zeros(rP,(degP+1)*cP);
      for i = 1:degP1+1
          P(:,(i-1)*cP+1:(i-1)*cP+cP1) = P1(:,(i-1)*cP1+1:i*cP1);
      end
      for i = 1:degP2+1
          P(:,(i-1)*cP+cP1+1:i*cP) = P2(:,(i-1)*cP2+1:i*cP2);
      end
   end
   P = ppck(P,degP);
else
   P = [ P1 P2];
end
