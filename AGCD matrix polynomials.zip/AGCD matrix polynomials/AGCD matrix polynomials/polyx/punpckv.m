%punpckv
%
% Convert a polymomial matrix to a regular matrix arranged in 
% various ways
%
% The command punpckv is a variant of the macro "punpck". Given
% a polynomial matrix Q = Q0 + Q1*s + ... + QN*s^N it returns a 
% constant matrix formed from the coefficient matrices in
% different ways.
%
% The command
%
%    C = punpckv(Q)
%    C = punpck(Q,'row')     puts the coefficient matrices of Q in
%                            block row form like punpck
%                               C = [ Q0, Q1, ..., QN]
%
%    C = punpck(Q,'col')     puts the coeficients in block column 
%                            form
%                              C = [ Q0 |
%                                  | Q1 |
%                                  | ...|
%                                  | QN ]
%
%   C = punpck(Q,'rrow')     puts the coefficients in reversed block 
%                            row form
%                               C = [ QN, Q(N-1), ..., Q0]
%
%   C = punpck(Q,'rcol')      produces the reversed block column form
%                              C = [ QN  |
%                                  | ... |
%                                  | Q1  |
%                                  | Q0  ]

% function used: pinfo

% $Revision: 1.0 $      $Date: 1996/03/13 14:56:37 $    $State: Exp $

function C = punpckv(Q,str)

if nargin==1, str='row';, end
test1=0;
if nargin==0 | nargin > 2
   test1=1;
elseif isstr(Q) | isstr(str)==0
   test1=1;
end
if test1
   disp('usage: C = punpckv(Q)');
   disp('    or C = punpckv(Q,''row'') ');
   disp('    or C = punpckv(Q,''col'') ');
   disp('    or C = punpckv(Q,''rrow'') ');
   disp('    or C = punpckv(Q,''rcol'') ');
   return
end
if strcmp(str,'row')|strcmp(str,'col')|strcmp(str,'rrow')|strcmp(str,'rcol')
   [typeQ,rQ,cQ,degQ] = pinfo(Q);
   if isnan(degQ)
      C=Q;
      return
   elseif degQ==0 | isinf(degQ)
      C=Q(1:rQ,1:cQ);
      return
   end
   C=[];
   Q=Q(1:rQ,1:(degQ+1)*cQ);
   if strcmp(str,'row'), C=Q;, end
   if strcmp(str,'col')
      for i=1:degQ+1
          C=[C;Q(:,(i-1)*cQ+1:i*cQ)];
      end
   end
   if strcmp(str,'rrow')
      for i=1:degQ+1
          C=[C, Q(:,(degQ+1-i)*cQ+1:cQ*(degQ+2-i))];
      end
   end
   if strcmp(str,'rcol')
      for i=1:degQ+1
          C=[C;Q(:,(degQ+1-i)*cQ+1:cQ*(degQ+2-i))];
      end
   end
else
   error('punpckv: Illegal input string');
end
