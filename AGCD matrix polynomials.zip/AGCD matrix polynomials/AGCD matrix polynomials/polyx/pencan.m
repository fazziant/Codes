% pencan  
%
% The function
%
%   [C,Q,Z] = pencan(P)
%   [C,Q,Z] = pencan(P[,'ord'][,tol])
%
% transforms the square nonsingular real pencil P(s) = P0 + P1*s 
% to the real Kronecker canonical form 
%
%   Q*P(s)*Z = diag(a+sI,I+se)
%
% The real matrix a is in real Schur form, that is, it is upper 
% block triangular with the real eigenvalues on the diagonal and the 
% complex eigenvalues in 2-by-2 blocks on the diagonal.  The real 
% matrix e is upper triangular with zeros on the diagonal and, hence, 
% is nilpotent. Q and Z are real nonsingular. 
%
% If the option 'ord' is included then a is in block diagonal form 
% a = diag(a1,a2), with a1 and a2 both in real Schur form.  All
% eigenvalues of a1 have nonnegative real parts and those of a2 have 
% strictly negative real parts.
%
% The number tol is an optional tolerance to decide which eigenvalues 
% of the pencil are infinite.

% Huibert Kwakernaak, October 2, 1996
% Revised December 30, 1996
% Corrected February 4, 1997
% Revised April, 1996
% Modified by S. Pejchova, June 16, 1997

function [C,Q,Z] = pencan(P,p1,p2)


% Preparation
if nargin < 1
 disp('usage:  [C,Q,Z] = pencan(P[,''ord''][,tol])');
 return
end
[mattype,rP,cP,degP] = pinfo(P);

if mattype == 'poly' & rP == cP & degP == 1
   n = cP; PP = punpck(P);
   P0 = PP(:,1:n);
   P1 = PP(:,n+1:2*n);
else
   error('pencan: The first argument is not a square pencil')
end

if imag(PP) ~= zeros(size(PP)) 
   error('pencan: The pencil needs to be real')
end

if nargin == 1
   option = '';
   epp = eps;
elseif nargin == 2 
   if isstr(p1)
      option = p1;
      epp = eps;
   else 
      epp = p1;
      option = '';
   end
elseif nargin == 3
   option = p1;
   epp = p2;
elseif nargin > 3
   error('pencan: Too many input arguments')
end
if ~ (strcmp(option,'ord') | strcmp(option,''))
   error('pencan: Unknown option')
end

ordered = strcmp(option,'ord');


% Ordered QZ transformation

if ordered
   method = 'full';
else
   method = 'partial';
end
[A,E,Q,Z] = qzord(-P0,P1,method,epp);


% Partition the pencil

I = find(abs(diag(E))>epp*norm(E)*max(size(E))^2); 
n1 = length(I); n2 = n-n1;

E11 = E(1:n1,1:n1); E12 = E(1:n1,n1+1:n); E22 = E(n1+1:n,n1+1:n); 
A11 = A(1:n1,1:n1); A12 = A(1:n1,n1+1:n); A22 = A(n1+1:n,n1+1:n); 
Q1 = Q(1:n1,:); Q2 = Q(n1+1:n,:); 
Z1 = Z(:,1:n1); Z2 = Z(:,n1+1:n); 


% Null the 12-block

if n1>0 & n2>0
   AA = ppck([A11 E11],1); BB = ppck([A22 E22],1); CC = ppck(-[A12 E12],1);
   [V,W] = plyap(AA,BB,CC);
   Q1 = Q1+W*Q2;
   Z2 = Z2+Z1*V; 
end



% In the ordered case, structure the 11-block

if ordered
   d1 = diag(E); d2 = diag(A); d = d2(I)./d1(I);
   n11 = length(find(real(d)<0)); 
   n12 = length(find(real(d)>=0)); 
   e11 = E11(1:n11,1:n11); 
   e12 = E11(1:n11,n11+1:n1);
   e22 = E11(n11+1:n1,n11+1:n1);
   a11 = A11(1:n11,1:n11); 
   a12 = A11(1:n11,n11+1:n1);
   a22 = A11(n11+1:n1,n11+1:n1);
   q1 = Q1(1:n11,:); q2 = Q1(n11+1:n1,:);
   z1 = Z1(:,1:n11); z2 = Z1(:,n11+1:n1);
   if n11>0 & n12>0
      aa = ppck([a11 e11],1);
      bb = ppck([a22 e22],1);
      cc = ppck(-[a12 e12],1);
      [v,w] = plyap(aa,bb,cc);
      E11(1:n11,n11+1:n1) = zeros(n11,n12);
      A11(1:n11,n11+1:n1) = zeros(n11,n12);
      q1 = q1+w*q2; z2 = z2+z1*v; 
   end
end


% Make E11 and -A22 equal to unit matrices

if ordered
   a11 = e11\a11; q1 = e11\q1; e11 = eye(size(e11)); 
   a22 = e22\a22; q2 = e22\q2; e22 = eye(size(e22)); 
else
   A11 = E11\A11; Q1 = E11\Q1; E11 = eye(size(E11)); 
end
E22 = -A22\E22; Q2 = -A22\Q2; A22 = -eye(size(A22));


% Make the decomposition real

if ordered
   ba = [ imag(q1); real(q1) ];
   [u,s,v] = svd(ba); uv = u(:,n11+1:2*n11)';  % left null space
   ri = uv(:,1:n11)+sqrt(-1)*uv(:,n11+1:2*n11); 
   q1 = real(ri*q1);
   a11 = real(ri*a11/ri);
   z1 = real(z1/ri);
   ba = [ imag(q2); real(q2) ];
   [u,s,v] = svd(ba); uv = u(:,n12+1:2*n12)';  % left null space
   ri = uv(:,1:n12)+sqrt(-1)*uv(:,n12+1:2*n12); 
   q2 = real(ri*q2);
   a22 = real(ri*a22/ri);
   z2 = real(z2/ri);
else
   ba = [ imag(Q1); real(Q1) ];
   [u,s,v] = svd(ba); uv = u(:,n1+1:2*n1)';  % left null space
   ri = uv(:,1:n1)+sqrt(-1)*uv(:,n1+1:2*n1); 
   Q1 = real(ri*Q1);
   A11 = real(ri*A11/ri);
   Z1 = real(Z1/ri);
end

ba = [ imag(Q2); real(Q2) ];
[u,s,v] = svd(ba); uv = u(:,n2+1:2*n2)';  % left null space
ri = uv(:,1:n2)+sqrt(-1)*uv(:,n2+1:2*n2); 
Q2 = real(ri*Q2);
E22 = real(ri*E22/ri);
Z2 = real(Z2/ri);


% Transform A11 and E33 to real Schur form

if ordered
   [u,a11] = schur(a11);
   q1 = u'*q1; z1 = z1*u;
   [u,a22] = schur(a22);
   q2 = u'*q2; z2 = z2*u;
else
   [u,A11] = schur(A11);
   Q1 = u'*Q1; Z1 = Z1*u;
end
[u,E22] = schur(E22);
Q2 = u'*Q2; Z2 = Z2*u;


% Rearrange the final result

if ordered
   Q = [q1; q2; Q2];
   Z = [z1 z2 Z2];
   AA = [     a11       zeros(n11,n12)  zeros(n11,n2)
         zeros(n12,n11)      a22        zeros(n12,n2)
         zeros(n2,n11)  zeros(n2,n12)        A22     ];
   EE = [     e11       zeros(n11,n12)  zeros(n11,n2)
         zeros(n12,n11)      e22        zeros(n12,n2)
         zeros(n2,n11)  zeros(n2,n12)        E22     ];
else
   Q = [Q1; Q2];
   Z = [Z1  Z2];
   AA = [     A11     zeros(n1,n2)
         zeros(n2,n1)     A22     ];
   EE = [     E11     zeros(n1,n2)
         zeros(n2,n1)     E22     ];
end
C0 = -AA; C1 = EE;
C = ppck([C0 C1],1);


% Check

Eps1 = norm(Q*P0*Z-C0,1);
Eps2 = norm(Q*P1*Z-C1,1);
Nrm = max(norm(P0,1),norm(P1,1));
Eps = max(Eps1,Eps2)/Nrm;
if Eps > 1e-6
   disp(sprintf('pencan warning: Relative residue %g',Eps));
end
