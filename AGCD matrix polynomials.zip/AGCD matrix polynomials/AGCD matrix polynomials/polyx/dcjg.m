% dcjg
%
% The function 
%
%   [Atilda,n] = dcjg(A)
%
% returns a polynomial matrix A~(d) which is d^n times the 
% discrete-time conjugate of A(d), with n the degree of A(d), 
% that is,
%
%	A*(d) = A'(1/d) = A~(d)/d^n
%
% If the input matrix is a regular Matlab matrix then Atilda = A'.

% Henrion D. 2-96
% Modified by S. Pejchova, June 26, 1997
% $Revision: 1.1 $	$Date: 1996/10/07 09:07:24 $	$State: Exp $

% functions used : pinfo, ppck, pdegco

function [Atilda,n] = dcjg(A)

if nargin~=1
 disp('usage:  [Atilda,n] = dcjg(A)');
 return
end
[typeA, rA, cA, n] = pinfo(A);

if (typeA == 'empt')
  Atilda = [];
elseif (typeA == 'cons')
  Atilda = A';
elseif isinf(n),
  Atilda = ppck(punpck(A)', 0);
else
 
  Atilda = [];
  for i = n:-1:0,
    Atilda = [Atilda pdegco(A, i)'];
  end;
  Atilda = ppck(Atilda, n);

end % if typeA

end % function
