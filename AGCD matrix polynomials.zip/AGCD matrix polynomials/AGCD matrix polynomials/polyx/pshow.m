%pshow
%
% Print a polynomial matrix on screen in a well-arranged form
%
% The command
%
%   pshow(A)
%
% prints on the screen the type, size and degree of the input 
% matrix A together with its coefficient matrices.

% S. Pejchova, 1995
% $Revision: 1.2 $      Date: 1995/12/05  12:02:13 $      $State: Exp $

function f=pshow(A)

if nargin ~=1
   disp('usage: pshow(A) ');
   return
end

[typeA,rA,cA,degA]=pinfo(A);

if typeA=='poly'
   A=punpck(A);
   if degA < 0
      disp(sprintf('            (%g x %g) zero polynomial matrix of degree -Inf',rA,cA));
      disp('      ');
      disp(A);

    else
      disp(sprintf('            (%g x %g) polynomial matrix of degree %g.',rA,cA,degA));
      disp('    ');

      for i=1:(degA+1)
          disp(sprintf('     Coefficient matrix at power  %g',i-1));
          disp(A(1:rA,(i-1)*cA+1:cA*i));
      end
   end

 elseif typeA=='cons'
   disp(sprintf('            (%g x %g) constant matrix',rA,cA));
   disp('      ');
   disp(A);
 else
   disp('            Input is empty matrix.');
end
    
