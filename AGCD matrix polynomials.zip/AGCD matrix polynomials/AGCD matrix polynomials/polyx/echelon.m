% echelon
%
% Computation of the echelon (or Popov) form of a polynomial matrix.
%
%   [E,U,indices] = echelon(D[,form])
%
% Given an n-by-n polynomial matrix row-reduced polynomial matrix D 
% the commands
%
%   [E,U,indices] = echelon(D)
%   [E,U,indices] = echelon(D,'row')
%
% the function returns the row polynomial echelon form E of D with
%
% - its row degrees arranged in ascending order
% - the degree of every pivot element
%   - larger than the degree of every right-hand-side element in the 
%     same row,
%   - larger than or equal to the degree of every left-hand-side element
%     in the same row,
%   - larger than the degree of every other element in the same column.
%
% Clearly E is both column reduced and row reduced. The unimodular 
% matrix U(s) satisfies
%
%     U(s)D(s) = E(s)
%
% while
%
%    indices(1:n,1) contains the pivot (column) indices of E(s),
%    indices(1:n,2) contains the row degrees of E(s),
%    indices(1:n,3) contains the column degrees of E(s).
% 
% If form = 'col', then D needs to be column reduced and E is in 
% column polynomial echelon form, satisfying the properties listed
% above with 'row' replaced by 'column' and vice-versa.

% Henrion D. 4-96
% Modified by S. Pejchova, June 26, 1997
% $Revision: 1.3 $	$Date: 1996/11/22 16:06:53 $	$State: Exp $

function [E,U,indices] = echelon(D,form)

if nargin < 1
 disp('usage:  [E,U,indices] = echelon(D[,form])');
 return
end
if nargin < 2,
  form = 'row';
elseif ~strcmp(form,'row') & ~strcmp(form,'col'),
  error('echelon: The optional input parameter is incorrect.');
end;

[typeD, n, cD, degD] = pinfo(D);

if n ~= cD,
  error('echelon: The input matrix must be square.');
elseif psing(D),
  error('echelon: The input matrix must be nonsingular.');
end;

[deg,Dcol] = pdegco(D,'col');
[deg,Drow] = pdegco(D,'row');
if (rank(Drow) < n) & (form == 'row')
  error('echelon: The input matrix must be row reduced')
elseif (rank(Dcol) < n) & (form == 'col')
  error('echelon: The input matrix must be column reduced')
end;

if form == 'col',
  D = ptransp(D);
end;

% Resultants of increasing degree are built until
% all pivot elements are found (i.e. until there's no more "primary"
% dependent rows).

shift = 0;
notfound = 1:n; % absent pivot indices

while any(notfound),

  degS = 0; k = 1;
  notfound = 1:n; % absent pivot indices
  pdr = zeros(n, 1); % primary dependent rows indices
  notproper = 0; % properness of G(s) = D^-1(s)

  while ~notproper & any(notfound),

    R = presult(prowjoin(D, -eye(n)), degS);
    [S, dr] = rwsearch(R); rS = size(S, 1);
    degS = degS + 1;
    pivot = rem(dr-1, 2*n);
    if any(pivot < n), % linearly dependent row in the upper part ..
       notproper = 1; % .. so G(s) is not proper
       D = pshift(D, 1); % compute G(s) = d^(-shift)D^-1(s)
       shift = shift + 1;
    else
       pivot = pivot-n+1; % pivot indices
       for i = 1:rS,
         j = find(~(notfound - pivot(i)));
         if ~isempty(j), % primary dependent row
           notfound(j(1)) = 0;
           pdr(k) = i; k = k + 1;
         end;
      end;
    end;
  end;
end;

% selection of the primary dependent rows
S = ppck(S(pdr, :), degS - 1);

% pivot indices, row degrees and column degrees
pivot = pivot(pdr);
rdeg = fix((dr(pdr)-1)/(2*n)) - shift;
[void, ind] = sort(pivot); cdeg = rdeg(ind);
indices = [pivot rdeg cdeg];

U = pzero(psel(S, 1:n, 1:n));
E = pshift(pzero(psel(S, 1:n, n+1:2*n)), -shift);

if form == 'col',
  U = ptransp(U);
  E = ptransp(E);
end;



