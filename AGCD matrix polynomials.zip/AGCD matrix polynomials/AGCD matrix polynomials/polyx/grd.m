% grd
%
% Greatest right divisor
%
% The function
%
%    G = grd(N1,N2,..,Nk[,'t',tol][,'z'[,EPS]])
%    G = grd(N1,N2,..,Nk,'res'[,'t',tol][,'z'[,EPS]])
%    [G,V,VI] = gld(N1,N2,...,Nk,'tri'[,'z'][,tol])
%
% computes a greatest right divisor G of the polynomial matrices 
% N1, N2, ..., Nk that all have the same column dimension m.
% In the form
%
%    G = grd(N1,N2,..,Nk[,'t',tol][,'z'[,EPS]])
%    G = grd(N1,N2,..,Nk,'res'[,'t',tol][,'z'[,EPS]])
%
% Gaussian elimination without row permutations is used.
% For a matrix S to be reduced the tolerance in testing for 
% nonzero pivots is
%
%    max(size(S))*1e4*eps*norm(S,'inf') by default
%    tol if both optional arguments 't' and tol are present
%
% If the optional 'z' argument is present then the result is 
% furthermore zeroed with a tolerance
%
%    1e3*eps by default;
%    EPS if this optional argument is present.
%
% In the form
%
%   [G,V,VI] = grd(N1,N2,...,Nk,'tri'[,'z'][,tol])
%
% where the method is 'tri' and k<=7, the routine relies on
% triangularization by elementary column operations. A unimodular
% matrix V is obtained so that
%
%    [ N1 |*V = [ G |
%    | N2 |     | 0 ]
%    | .. |
%    | Nk ]
%
% For two input matrices A and B the matrix G is the greatest common 
% right divisor. The unimodular matrix V may be split into two pairs 
% of left coprime polynomial matrices (P,Q) and (R,S) such that
%
%          U = [ P R |      PA + QB = G
%              | Q S ]      RA + SB = 0.
%
% The inverse matrix VI = V^(-1) is also computed. 
% The input arguments 'z' and tol are used in "zeroing" (see 'pzero'). 
% The default value of the tolerance tol is computed from the degrees 
% and sizes of the input matrices. If 'z' and tol are missing then
% the macro runs  without "zeroing".
%
% The function is dual to gld,

% functions used: pinfo, ppck, pdegco, pstairs, pput,
%                prowjoin

% COPYRIGHT S. Pejchova, D. Henrion, M. Sebek 1997
% $Revision: 1.0 $      $Date: 1997/04/28 15:30:08 $    $State: Exp $

function [G,U,UI]=grd(N1,N2,N3,N4,N5,N6,N7,N8,N9,N10)

method='res'; test1=0; argdel=[];
if nargin==0
   test1=1;
elseif isstr(N1)
   test1=1;
elseif nargin>1
   for i=2:nargin
       stg=['argm=N',int2str(i),';'];
       eval(stg);
       if isstr(argm)
          if strcmp(argm,'tri'), method='tri'; argdel=i;
          elseif strcmp(argm,'res'), argdel=i;
          elseif ~(strcmp(argm,'t')|strcmp(argm,'z'))
                 test1=1;
          end
       end
   end
end
if nargout > 1, method='tri'; end
if test1
   disp('usage: G = grd(N1,N2,..,Nk,''t'',tol,''z'',EPS) ');
   disp('    or G = grd(N1,N2,..,Nk,''res'',''t'',tol,''z'',EPS) ');
   disp('    or [G,U,UI] = grd(N1,N2,..,Nk,''tri'',''z'',tol) ');
   return
end
if ~isempty(argdel)
   argres=2:nargin; argres(argdel-1)=[];
   stgout='[G';
   if nargout==3 | strcmp(method,'tri')
      stgout=[stgout,',U,UI'];
   end
   stgall=[stgout,']=grd(N1'];
   for i=argres
       stgall=[stgall,',N',int2str(i)];
   end
   stgall=[stgall,');'];
   eval(stgall);
else
   if strcmp(method,'res')
      n = 0; ind = 1;
      zeroing = 0; tolerance = 0;
      while ind <= nargin,
       last = eval(['N' int2str(ind)]);
       if isstr(last), 
        if last == 'z', % zeroing argument
         if ind == nargin - 1,
          ind = ind + 1;  zeroeps = eval(['N' int2str(ind)]);
          [type,r,c] = pinfo(zeroeps);
          if ~isstr(zeroeps) & (type == 'cons') & (r == 1) & (c == 1),
           zeroing = 2; % user supplied zeroing
          else
           error('grd: The EPS argument must be scalar');
          end;
         elseif ind == nargin,
          zeroing = 1; % default zeroing
         else
          error('grd: Invalid argument following ''z''.');
         end;
        elseif last == 't', % tolerance argument
         tolerance = 1;
         if ind == nargin,
          error('grd: The tolerance must be specified.');
         else
          ind = ind + 1; tol = eval(['N' int2str(ind)]);
          [type,r,c] = pinfo(tol);
          if ~(~isstr(tol) & (type == 'cons') & (r == 1) & (c == 1)),
           error('grd: Invalid tolerance value');
          end;
         end;
        else
         error('grd: Invalid string argument');
        end;
        ind = ind + 1;
       elseif tolerance | zeroing,
        error('grd: Invalid argument order');
       else
        ind = ind + 1;
        n = n + 1; % polynomial matrix
       end;
      end; % while

      if (n == 0),
        error('grd: The first argument should be a polynomial matrix');
      end;

      % matrices Ni in resultant S
      m = 0; p = 0; deg = 0;
      S = []; rS = 0; cS = 0;

      % max. degree for Ni
      for i = 1:n,
        N = eval(['N' int2str(i)]);
        degN = pdegco(N);
        if ~isinf(degN),
          deg = max(deg, degN);
        end;
      end;
  
      % build Barnett's resultant
      for i = 1:n,
        N = eval(['N' int2str(i)]);
        [typeN,rN,cN,degN] = pinfo(N);
        if isinf(degN) | (typeN == 'cons'),
          degN = 0;
        end;
        if (i > 1) & (cN ~= m),
          error('grd: The input matrices have inconsistent column dimensions.');
        else
          m = cN;
        end;
        Nr = [];
        for i = degN:-1:0,
          Nr = [Nr pdegco(N, i)];
        end;
        S = [S zeros(rS,(deg+1)*m-cS);zeros(rN,(deg-degN)*m) Nr]; p = p + rN;
        [rS,cS] = size(S);
      end;

      % ------------------------------------------------------------
      % first step : reduction to reduced row echelon form
      % row permutations are allowed
      % ------------------------------------------------------------

      if ~tolerance,
       tol = max(rS,cS)*eps*norm(S,'inf'); % tolerance for Gaussian elimination
      end;
      row = 1; col = 1; colind = [];
      while (row <= rS) & (col <= cS),
         [val,i] = max(abs(S(row:rS,col))); i = i+row-1;
         if (val <= tol), % negligible column
            S(row:rS,col) = zeros(rS-row+1,1);
         else
            colind = [colind col];
            S([row i],col:cS) = S([i row],col:cS); % row permutation
            S(row,col:cS) = S(row,col:cS)/S(row,col); % pivot
            for i = [1:row-1 row+1:rS],
               S(i,col:cS) = S(i,col:cS) - S(i,col)*S(row,col:cS);
            end;
            row = row + 1;
         end;
         col = col + 1;
      end;

      % ------------------------------------------------------------
      % second step : successive reductions without row permutations
      % ------------------------------------------------------------
      E = S; rk = rank(S); oldrk = 0;

      if ~tolerance,
       tol = max(rS,cS)*eps*1e4*norm(S,'inf'); % higher tolerance
      end;

      first = 0; % enters the loop for the first time
      while ~first | (rk - oldrk > m),

        first = 1;
        oldrk = rk;
        S = [S zeros(rS, m); zeros(p, m) E]; % extended resultant
        rS = rS + p; cS = cS + m; deg = deg + 1;
        if ~tolerance,
         tol = max(rS,cS)*1e4*eps*norm(S,'inf'); % tolerance for Gaussian elimination
        end;

        % "shifted" row echelon form by Gaussian elimination
        % row permutations are not allowed

        zp = zeros(rS, 1);
        col = 1;
        while (col <= cS), 
         row = 1;
         while (row <= rS),
          if (abs(S(row,col)) > tol) & ~zp(row), % non-zero possible pivot
            zp(row) = 1; % next pivot shouldn't belong to this row
            S(row,:) = S(row,:)/S(row,col); % normalization
            for k = 1:rS, % cancel other elements in the column
              if (k ~= row) & (abs(S(k,col)) > tol),
                S(k,:) = S(k,:) - S(row,:)*S(k,col);
              end;
            end;
            row = rS;
          end; % if
          row = row + 1;
         end; % while row
         col = col + 1;
        end; % while column

        rk = rank(S,tol);
        E = S(rS-p+1:rS,:); % lower part of S

      end; % while rk

      % grd
      ind = any(abs(E')>tol);
      if sum(ind),
        E = E(ind, :); % non zero rows
        for i=0:deg,
          G(:, 1+i*m:(i+1)*m) = E(:, 1+cS-m*(i+1):cS-m*i);
        end;  
      else
        G = [];
      end;

      % zero leading coefficients will be removed
      rowG = size(G, 1);
      G = ppck(G, deg);

      rankG = prank(G);
      if (rowG ~= m) | (rankG < m),
        disp('grd warning: The computed divisor is not square');
        % extraction of the linearly independent
        % rankG rows of G(s) having minimal row degrees
        [rowdeg, ind] = sort(pdegco(G, 'row'));
        newG = []; oldrank = 0; j = 0;
        for i = 1:rankG,
         newrank = oldrank;
         while (newrank == oldrank) & (j < rowG),
          j = j + 1;
          testG = prowjoin(newG, psel(G, ind(j), ':'));
          newrank = prank(testG);
         end;
         if newrank > oldrank,   
          newG = testG;
          oldrank = newrank;
         end;
        end;
        G = newG;
      end;


      % final zeroing
      if zeroing == 2,
        G = pzero(G, zeroeps);
      elseif zeroing == 1,
        G = pzero(G);
      end;      
      
   elseif strcmp(method,'tri')
      zeroing=0; num=nargin;
      if nargin>1
         for ls=nargin:-1:(max(2,nargin-1))
             st=['argm=N',int2str(ls),';'];
             eval(st);
             if isstr(argm)
                if strcmp(argm,'z')
                   num=num-1;
                   if zeroing==0, zeroing=2; end
                else, num=0;
                end
             elseif length(argm)==1
                tol=argm; zeroing=1; num=num-1; 
             end
         end
      end
      if num < 1
         disp('usage: [G,U,UI] = grd(N1,N2,..,Nk,''z'',tol) ');
         return
      end
      A=N1;, F=N1;
      if num > 1
         for j=2:num
             strB=['B=N',int2str(j),';'];
             eval(strB);
             F=prowjoin(A,B);
             A=F;
         end
      end
      [typeF,rF,cF,degF]=pinfo(F);
      if isempty(F)
         G=[];, U=[];, UI=[];
         return;
         end
      if isinf(degF) | (norm(punpck(F),inf)<eps)
         G=[];
         U=[];, UI=U;
         return
      end
      if zeroing==2
         [G,U,UI]=pstairs(F,'up','z');
      elseif zeroing==1
         [G,U,UI]=pstairs(F,'up',tol);
      else
         [G,U,UI]=pstairs(F,'up');
      end
      DGr=pdegco(G,'row');
      rG=length(DGr);
      while DGr(rG,1)<0
            G=pput(G,rG,':',[]);
            DGr=pdegco(G,'row');
            rG=length(DGr);
      end
      [typeG,rG,cG,degG]=pinfo(G);
      if rG ~= cG
         disp('grd warning: The greatest right divisor is not square');
      end
   end
end

