%prandm
%
% Random polynomial matrix with random coefficients
%
% The command
%
%    A = prandm(degA,i,j)     generates a "random" polynomial 
%                             matrix A with integer coefficients
%                             of size i-by-j.
%                              If degA is a scalar integer then
%                               the output matrix is of degree degA.
%                              If degA is a column vector then its
%                               entries specify the row degrees of A.
%                              If degA is a row vector then its entries
%                               specify the column degrees of A.
%                              If j is missing then A is i-by-i. 
%                              If both i and j are missing then the 
%                               size of A equals that of degA.
%
%    A = prandm(n,'col',i,j)  generates a polynomial matrix whose
%                             column degrees are randomly chosen 
%                             within the interval [0,n]. 
%                              If n is missing then the default value 
%                               n = 8 applies.
%                              If j is missing then the matrix is 
%                               i-by-i.
%
%    A = prandm(n,'row',i,j)  generates a polynomial matrix whose
%                             row degrees are randomly chosen
%                             within the interval [0, n]. 
%                              If n is missing then the default value 
%                               n = 8 applies.
%                              If j is missing then the matrix is 
%                               i-by-i.
%
%    A = prandm(n,'ent',i,j)  generates a polynomial matrix whose
%                             entry degrees are randomly chosen
%                             within the interval [0,n]. 
%                              If n is missing then the default value 
%                               n = 8 applies.
%                              If j is missing then the matrix is 
%                               i-by-i.
%
%    A = prandm(degA,'mon',i) generates an i-by-i monic polynomial 
%                             matrix of degree degA. If degA is 
%                             missing then it is randomly chosen
%                             within the interval [0,8].
%
%    A = prandm(degA,'uni',i) generates an i-by-i unimodular matrix of 
%                             degree degA. If degA is missing then it 
%                             is randomly chosen within the interval 
%                             [0,8].
%
%    A = prandm(m,'pos',i,v)  generates an i-by-i matrix whose zeros
%                             take the positions specified by the 
%                             vector v. To every complex element of v 
%                             its complex conjugate is automaticaly
%                             added. The number m is the sum of the
%                             degrees of two random unimodular 
%                             matrices used to scramble the diagonal
%                             matrix determined by v. If m is missing
%                             then the default value m = 0 applies.
%
%    [A,roots] = prandm(n,'sta',i,v) generates a "stable" i-by-i
%                             polynomial output matrix. The number n 
%                             specifies the number of zeros, which
%                             all have negative real parts. The count
%                             includes possible multiplicities but
%                             pairs of complex conjugate zeros count 
%                             only once. Some zeros can be fixed a 
%                             priory by the vector v but those fixed 
%                             zeros need not necessary be stable. If 
%                             n is missing then the default value 
%                             n = i applies. The output argument 
%                             roots contains the vector of all zeros 
%                             of A.
%
%   [A,roots] = prandm(n,'res',i,v) has the same functionality but
%                             without complex zeros.

% COPYRIGHT S. Pejchova, M. Sebek 1997
% $Revision: 1.1 $      $Date: 1997/03/11 11:50:20 $    $State: Exp $

function [A,arg] = prandm(n,degA,i,j);

test1=0;, test2=0;
if nargin==1
   degA=n;
end
if nargin<1
   test1=1;
elseif (nargin >4)|(nargin==1 & isstr(n))|(nargin==2 & isstr(degA))
   test2=1;
end

if test1 | test2
   disp('usage: A = prandm(degA,i,j)            or  A = prandm(degA,i) ');
   disp('   or: A = prandm(degA) ');
   disp('   or: A = prandm(n,''col'',i,j)         or  A = prandm(n,''col'',i) ');
   disp('   or: A = prandm(''col'',i,j)           or  A = prandm(''col'',i) ');
   disp('   or: A = prandm(n,''row'',i,j)         or  A = prandm(n,''row'',i) ');
   disp('   or: A = prandm(''row'',i,j)           or  A = prandm(''row'',i) ');
   disp('   or: A = prandm(n,''ent'',i,j)         or  A = prandm(n,''ent'',i) ');
   disp('   or: A = prandm(''ent'',i,j)           or  A = prandm(''ent'',i) ');
   disp('   or: A = prandm(degA,''mon'',i)        or  A = prandm(''mon'',i) ');
   disp('   or: A = prandm(degA,''uni'',i)        or  A = prandm(''uni'',i) ');
   disp('   or: A = prandm(m,''pos'',i,v)         or  A = prandm(''pos'',i,v) ');
   disp('   or: [A,roots] = prandm(n,''sta'',i,v) or  [A,roots] = prandm(n,''sta'',i) ');
   disp('   or: [A,roots] = prandm(''sta'',i,v)   or  [A,roots] = prandm(''sta'',i) ');
   disp('   or: [A,roots] = prandm(n,''res'',i,v) or  [A,roots] = prandm(n,''res'',i) ');
   disp('   or: [A,roots] = prandm(''res'',i,v)   or  [A,roots] = prandm(''res'',i) ');
   return
end

if isstr(degA)==0 & isstr(n)==0
   [rd,cd]=size(n);
   if nargin==1
      i=rd;, j=cd;
    elseif nargin==2
      i=degA;
      degA=n;
      j=i;
    else
      j=i;, i=degA;, degA=n;
   end
   if rd==0 | cd==0 | i==0 | j==0
      error('prandm: The input argument is empty');
   end
   [ir,ic]=size(i);
   [jr,jc]=size(j);
   if ir>1 | ic>1 | jr>1 | jc>1
      error('prandm: The number of rows or columns is not scalar');
   end
   if rd==1
      if cd==1                               % degA is scalar
         if degA >=0
            A=floor(10*randn(i,j*(degA+1)));
         else
            A=zeros(i,j);
            degA=0;
         end
         A=ppck(A,degA);
         arg=degA;
         return;
      else                                   % degA is row vector
         if cd < j
            degA=[degA,-Inf*ones(1,j-cd)];
            cd=j;
         elseif cd > j
            degA=degA(1,1:j);
            cd=j;
         end
         degA=ceil(degA);
         maxd=max(degA);
         if maxd >=0
            Deg=zeros(1,j*(maxd+1));
            for s=1:j
                if degA(s)>=0
                   Deg(1,s:j:(degA(s)*j+s))=ones(1,degA(s)+1);
                end
            end
            Jz=find(~Deg);
            L=length(Jz);
            A=floor(10*randn(i,j*(maxd+1)));
            if L > 0
               A(:,Jz)=zeros(i,L);
            end
         else
            A=zeros(i,j);
            maxd=0;
         end
         A=ppck(A,maxd);
         arg=maxd;
         return
      end
   else
      if cd==1                               % degA is column vector
         if rd < i
            degA=[degA; -Inf*ones((i-rd),1)];
            rd=i;
         elseif rd > i
            degA=degA(1:i,1);
            rd=i;
         end
         degA=ceil(degA);
         maxd=max(degA);
         if maxd >= 0
            A=zeros(i,j*(maxd+1));
            for s=1:i
                if degA(s)>=0
                   A(s,1:j*(degA(s)+1))=floor(10*randn(1,j*(degA(s)+1)));
                end
            end
         else
            A=zeros(i,j);
            maxd=0;
         end
         A=ppck(A,maxd);
         arg=maxd;
         return;
      else                                   % degA is a matrix
         if rd < i
            degA=[degA; -Inf*ones((i-rd),cd)];
            rd=i;
         elseif rd > i
            degA=degA(1:i,1:cd);
            rd=i;
         end
         if cd < j
            degA=[degA,-Inf*ones(i,j-cd)];
            cd=j;
         elseif cd > j
            degA=degA(1:i,1:j);
            cd=j;
         end
         degA=ceil(degA);
         A=ppck(zeros(i,j),0);
         for k=1:i
             for m=1:j
                 if degA(k,m) >= 0
                    en=floor(10*randn(1,degA(k,m)+1));
                    S=pput(A,k,m,ppck(en,degA(k,m)));
                    A=S;
                 end
             end
         end
         arg=degA;
         return
      end
   end
else
   if isstr(n)
      if nargin==3
         j=i;, i=degA;
         degA=n;, n=NaN;
      elseif nargin==2
         if n=='pos'
            error('prandm: Missing vector of required positions of zeros');
         elseif n=='sta' | n=='res'
            j=NaN;
         else
            j=degA;
         end
         i=degA;
         degA=n;, n=NaN;
      end
   elseif isstr(degA)
      if nargin==3
         if degA=='pos'
            error('prandm: Missing vector of required positions of zeros');
         elseif degA=='sta' | degA=='res'
            j=NaN;
         else
            j=i;
         end
      end
   end
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   [rn,cn]=size(n);
   if rn==0 | cn==0 | rn>1 | cn>1 | isstr(n)
      error('prandm: Illegal type of first input argument');
   end
   if isnan(n)
      n1=8;
      n2=0;
      n3=i;
      n4=round(8*rand(1));
   else
      n1=n;, n2=n;, n3=n;, n4=n;
   end
   [ir,ic]=size(i);
   if ir>1 | ic>1
      error('prandm: The number of rows or columns is not scalar');
   end
   if (degA=='col' | degA=='row' | degA=='ent') & n1<0
      A=ppck(zeros(i,j),0);
      arg=0;
      return;
   end

   if degA=='col'                            % column degrees "randomly"
      degA=round(n1*rand(1,j));
      A=prandm(degA,i,j);
      arg=degA;
      return
   end
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   if degA=='row'                            % row degrees "randomly"
      degA=round(n1*rand(i,1));
      A=prandm(degA,i,j);
      arg=degA;
      return
   end
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   if degA=='ent'                            % degrees of particular
      degA=round((n1+1)*rand(i,j))-ones(i,j); %    entries "randomly"
      A=prandm(degA,i,j);
      arg=degA;
      return
   end
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   if n4 < 0
      A=ppck(zeros(i),0);
      arg=0;
      return;
   end

   if degA=='mon'                            % "monic" polynomial
      P=prandm(n4,i);                        %             matrix
      [degP,PL]=pdegco(P);
      A=punpck(P);
      A=PL\A;
      A(:,(i*degP+1):(i*(degP+1)))=eye(i);
      A=round(A);
      A=ppck(A,degP);
      arg=degP;
      return
   end
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   if degA=='uni'                            % "unimodular" polynomial
      no2=floor(n4/2);                       %                  matrix
      no1=n4-no2;
      A1=[];, A2=[];
      for s1=1:no1+1
          P1=triu(round(randn(i)),1);        % upper(right) triang.

          if s1==1
             P1=P1+eye(i);
          end
          A1=[A1,P1];
      end
      A1=ppck(A1,no1);
      for s2=1:no2+1
          P2=tril(round(randn(i)),-1);       % lower(left) triang.
          if s2==1
             P2=P2+eye(i);
          end
          A2=[A2,P2];
      end
      A2=ppck(A2,no2);
      A=pmul(A1,A2,'z');
      arg=n4;
      return
   end
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   if degA=='sta' | degA=='res'              % "stable" polynomial
                                             %              matrix
      v=j;
      [vr,vc]=size(v);
      if vr==0 | vc==0 | (vr>1 & vc>1)
         error('prandm: The input argument of required zeros should be a vector');
      end
      if isnan(v)
         nv=n3;, v=[];
      else
         nv=n3-length(v);
      end
      if nv > 0
         v_aux=-(round(10*rand(1,nv))+ones(1,nv));
         V=v;
         if degA=='sta'
            v_aux=v_aux+sqrt(-1)*round(10*rand(1,nv));
         end
      else
         V=v(1:n3);
         v_aux=[];
      end
      V=[V,v_aux];
      [A,arg]=prandm('pos',i,V);
      return
   end
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   if degA=='pos'                            % polynomial matrix
                                             % with known zeros
      v=j;
      [vr,vc]=size(v);
      if vr==0 | vc==0 | (vr>1 & vc>1)
         error('prandm: The input argument of required zeros is not a vector');
      end
      l=length(v);
      if vr>vc, v=v'; vc=vr; vr=1; end
      v1=ones(1,i);
      vs1=zeros(1,i);
      v2=[];
      if l>=i
         v1=-v(1:i);, vs1=ones(1,i);
         v2=v(i+1:l);
      else
         v1(1:l)=-v;
         vs1(1:l)=ones(1,l);
      end
      V=[v1,vs1];
      V=ppck(V,1);
      f=find(imag(v1));
      if isempty(f)==0
         for t=f
             par=[(real(v1(t)))^2+(imag(v1(t)))^2, 2*real(v1(t)), 1];
             par=ppck(par,2);
             V=pput(V,1,t,par);
         end
      end
      if isempty(v2)==0
         lv2=length(v2);
         a=1;
         for t=1:lv2
             if imag(v2(t))==0
                par1=ppck([-v2(t),1],1);
             else
                par1=ppck([(real(v2(t)))^2+(imag(v2(t)))^2, -2*real(v2(t)), 1],2);
             end
             par2=psel(V,1,a);
             parnew=pmul(par1,par2,'z');
             V=pput(V,1,a,parnew);
             a=a+1;
             if a==i+1
                a=1;
             end
         end
      end
      S=pdiag(V);
      no2=floor(n2/2);
      no1=n2-no2;
      U1=prandm(no1,'uni',i);
      U2=prandm(no2,'uni',i);
      A=pmul(U1,S,U2,'z');
      Root=v;
      fR=find(imag(v));
      if isempty(fR)==0
         for tR=fR
             Root=[Root,(real(v(tR))-sqrt(-1)*imag(v(tR)))];
         end
      end
      [arg1,In]=sort(abs(Root));
      Root=Root(In); 
      arg=(Root(length(Root):-1:1))';  
      return
   end
   error('prandm: Illegal input string.');
end
