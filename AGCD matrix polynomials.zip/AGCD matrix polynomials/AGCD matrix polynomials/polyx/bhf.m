%bhf
%
%    [F,G,H,bsizes] = bhf(A,B,C)
%
% This function converts a state space realization (A,B,C) into 
% upper block Hessenberg form. The controllable part of the system 
% {A,B,C} is returned as the system {F,G,H}, where F is an upper block 
% Hessenberg matrix and G has nonzero elements in its first m rows 
% only, where m is the rank of B. The vector bsizes contains the 
% sizes of the different blocks of the matrix F.

% Rens C.W. Strijbos, 1996.
% Modified by S. Pejchova, June 28, 1997
% $Revision: 1.1 $	$Date: 1995/08/21 10:16:24 $	$State: Exp $

function[F,G,H,bsizes] = bhf(A,B,C)

if nargin ~= 3
   disp('usage: [F,G,H,bsizes] = bhf(A,B,C)')
   return
end
   
[typeA,rA,cA,degA]=pinfo(A);
[typeB,rB,cB,degB]=pinfo(B);
[typeC,rC,cC,degC]=pinfo(C);
if isempty(A)|isempty(B)|isempty(C)
   F=[]; G=[]; H=[]; bsizes=[];
   return
end
iter=1;
Tot=[B A];
normTot=norm(Tot);
if normTot >= eps*1e2
   EPS=(rA+rB)*normTot*eps*1e4;
else
   EPS=eps*1e2;
end
sumbsizes=rank(B,EPS);
rowstart=1;
colstart=1;
colstop=cB;
T=eye(rA);
while (sumbsizes <= rA)
   Btemp=Tot(rowstart:rB,colstart:colstop);
   [rBt,cBt]=size(Btemp);
   Atemp=Tot(rowstart:rA,colstop+1:cA+cB);
   [rAt,cAt]=size(Atemp);
   [Btemp,Tloc,rankBtemp]=hhl(Btemp,EPS);
   if rankBtemp == 0
      break
   end
   bsizes(iter)=rankBtemp;
   sumbsizes=sum(bsizes);
   iter=iter+1;
   T(rA-rAt+1:rA,:)=Tloc*T(rA-rAt+1:rA,:);
   Atemp=T*A*T';
   Btemp=T*B;
   Tot = [Btemp Atemp];
   rowstart=rowstart+rankBtemp;
   colstart=colstart+rankBtemp;
   colstop=colstop+rankBtemp;
end
F=T*A*T';
G=T*B;
H=C*T';
if rankBtemp == 0
   F=F(1:sumbsizes,1:sumbsizes);
   G=G(1:sumbsizes,:);
   H=H(:,1:sumbsizes);
end
iter=iter-1;
while iter>1
   rightstart=bsizes(iter-1)-bsizes(iter);
   if rightstart > 0
      break;
   else
      iter=iter-1;
   end
end
if iter > 1
   T=eye(sumbsizes);
   cumbsizes=cumsum(bsizes);
   Tloc=eye(bsizes(iter));
   while iter>1
      rowstart=cumbsizes(iter-1)+1;
      rowstop=cumbsizes(iter);
      if iter>2
         colstart=cumbsizes(iter-2)+1;
      else
         colstart=1;
      end
      colstop=rowstart-1;
      Ftemp=Tloc'*F(rowstart:rowstop,colstart:colstop);
      [Ftemp,Tloc,rankBtemp]=hhr(Ftemp,EPS);
      T(colstart:colstop,colstart:colstop)=Tloc;
      iter=iter-1;
   end 
   F=T'*F*T;
   G=T'*G;
   H=H*T;
end
