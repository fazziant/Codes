% axya2b
%
% The function
%
%    [x,y] = axya2b(a,b[,algorithm])
%
% solves the scalar polynomial equation a(-s)x(s) + y(-s)a(s) = 2b(s),
% where a and b are given polynomials such that
%
%    a(s) ~= 0 for Re(s) >= 0    (a is Hurwitz)
%    deg(b) <= 2*deg(a)          (a^-1(-s)b(s)a^-1(s) is proper)
%
% The solution polynomials x and y have the properties
%
%    deg(x) <= deg(a)            (x/a is proper)
%    deg(y) <= deg(a)            (y/a is proper)
%
% The optional argument 'algorithm' specifies which algorithm is used:
%
% 'res' (default): the resultant algorithm. The solution is obtained
%     by the resultant formulation of the problem. In this case the 
%     degrees of x and y are taken to be equal to the degree of a.
%
% 'euc': the Euclidean division algorithm.

% Henrion D. 3-96
% $Revision: 1.4 $	$Date: 1996/10/07 08:54:32 $	$State: Exp $
% Modified by Henrion D. 5-97
% - description updated
% - tolerance added, [] returned when no solution exist
% Modified by S. Pejchova, June 26, 1997

% functions used : pinfo, ppck (euclidean algorithm)
%                  presult, pinv (resultant formulation)

function [x,y]=axya2b(a,b,algorithm)

tol = 1e-8;

if nargin<2
 disp('usage:  [x,y]=axya2b(a,b[,algorithm])');
 return
end
if (nargin < 3),
  algorithm = 'euc';
elseif ~strcmp(algorithm, 'euc') & ~strcmp(algorithm, 'res'),
  error('axya2b: valid values for algorithm are ''euc'' and ''res''.');
end;

[typea, ra, ca, dega] = pinfo(a);
[typeb, rb, cb, degb] = pinfo(b);
if ((ra ~= 1) | (ca ~= 1)),
  error('axya2b: a must be a polynomial.');
elseif ((rb ~= 1) | (cb ~= 1)),
  error('axya2b: b must be a polynomial.');
elseif isinf(dega),
  error('axya2b: a is the zero polynomial.');
end;
if isinf(degb),
  x = ppck(0,0); y = ppck(0,0);
  return;
end;

if (algorithm == 'euc'),

  % EUCLIDEAN ALGORITHM

  % separation of odd and even parts of a and b

  na = floor(dega/2)+1; nb = floor(degb/2)+1; m = max(na, nb);
  ae = zeros(1,m); ao = ae; be = ae; bo = ae;
  a(1, dega+2) = 0; b(1, degb+2) = 0;

  for i = 1:na,
    ae(i) = a(1, (i-1)*2+1);
    ao(i) = a(1, 2*i);
  end;
  for i = 1:nb,
    be(i) = b(1, (i-1)*2+1);
    bo(i) = -b(1, 2*i);
  end;

  % forward construction of coefficients

  coefs = []; nit = 1;

  while length(find(ao)) > 0, % while polynomial ao(s) is not zero
    a1 = ao(1); a2 = ae(1);
    if (abs(a1) < eps) | (abs(a2) < eps),
      error('axya2b: a must be stictly stable.');
    end;
    coefs = [coefs; a2/a1 be(1)/a2 bo(1)/a1];
    be = [be(2:m) - coefs(nit,2)*ae(2:m) 0];
    bo = [bo(2:m) - coefs(nit,3)*ao(2:m) 0];
    aen = ao; ao = [ae(2:m) - coefs(nit,1)*ao(2:m) 0]; ae = aen;
    nit = nit + 1;
  end;

  % backward substitutions

  ue = zeros(1,m); uo = ue; ve = ue; vo = ue;
  ue(1:length(be)) = be/ae(1);
  vo(1:length(bo)) = bo/ae(1);

  for i = nit-1:-1:1,
    uon = ue - coefs(i,1)*uo;
    ue = [coefs(i,2) uo(1:m-1)]; uo = uon;
    ven = [coefs(i,3) vo(1:m-1)] - coefs(i,1)*ve;
    vo = ve; ve = ven;
  end;

  % construction of solutions x(s) and y(s)

  xe = ue + ve; xo = -(uo + vo); x = [];
  ye = ue - ve; yo = -(uo - vo); y = [];

  for i = 1:m,
   x = [x xe(i) xo(i)];
   y = [y ye(i) yo(i)];
  end;

  degx = 2*m-1; degy = 2*m-1;

else % algorithm == 'res'

  % RESULTANT FORMULATION :
  % LEAST SQUARE SOLUTION

  % maximal possible degree for x and y
  degx = dega; degy = dega;
  b = [punpck(b) zeros(1,dega+degx-degb)];
  R = [presult(cjg(a), degx); presult(a, degx)];

  if rank(R, tol) ~= size(R, 2),
    xy = 2 * b * pinv(R);
    % check
    if norm(xy*R-2*b) > tol,
      x = []; y = []; return;
    end;
  else
    xy = 2 * b / R;
  end;

  x = xy(1:degx+1); y = xy(degx+2:2*(degx+1));
  
  for i = 2:2:degx+1,
    y(i) = -y(i);
  end;

end; % if algorithm

x = ppck(x, degx);
y = ppck(y, degy);

 


