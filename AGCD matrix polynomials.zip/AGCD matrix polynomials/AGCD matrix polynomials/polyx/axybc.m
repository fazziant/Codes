% axybc
%
% The function
%
%    [X0,Y0,Kx,Ky] = axybc(A,B,C[,tol][,'minimal'])
%
% solves the polynomial matrix equation
%
%       AX+YB = C
%
% If only two output arguments X0, Y0 are present then the macro computes
% only a particular solution. If C is a zero matrix then this solution
% equals matrices Kx = [ Kx1; Kx2; ...; Kxk] and Ky = [ Ky1; Ky2; ...; Kyk]
% such that Kxi, Kyi are homogenous solutions (i.e. AKxi=KyiB).
% If no polynomial solution exists then  X0 = Y0 = []. 
%
% If all output arguments are present then the macro computes matrices
% Kx = [ Kx1; Kx2; ...; Kxk] and Ky = [ Ky1; Ky2; ...; Kyk] such that
% Kxi, Kyi are homogenous solutions (i.e. AKxi=KyiB). This allows to
% parametrize  all solutions to AX + YB = C as
% 
%    X = X0 - t1Kx1 + t2Kx2 + ... + tkKxk
%    Y = Y0 + t1Ky1 + t2Ky2 + ... + tkKyk
%
% where the ti are arbitrary scalar polynomials. If such a kernel does
% not exist, then Kx = Ky = [].
%
% The optional argument tol is used to decide whether a solution 
% exists and to perform kernel extraction. If tol is negative then
% it takes its default value.
%
% If the option 'minimal' is present then the function computes a 
% solution with minimal row degrees of Y0. 

% functions used: pinfo, prowjoin, pcoljoin, pkron, ptransp, xab, psel
%                 pdegco, punpck, ppck

% COPYRIGHT D. Henrion, S. Pejchova, M. Sebek 1997
% $Revision: 1.1 $      $Date: 1997/06/28 17:05:08 $    $State: Exp $

function [X0,Y0,Kx,Ky] = axybc(A,B,C,arg4,arg5)

test1=0; tol=-1; minim=0; gnrl=0;

if nargin<3
   test1=1;
elseif isstr(A) | isstr(B) | isstr(C)
   test1=1;
elseif nargin > 3
   if ~isstr(arg4)
      if length(arg4)==1, tol=arg4;
      else, test1=1;
      end
   elseif strcmp(arg4,'minimal'), minim=1;
   else, test1=1;
   end
end
if nargin > 4
   if isstr(arg5)
    if strcmp(str5,'minimal')
      minim=1;
    else, test1=1;
    end
   else, test1=1; end
end
if test1
 disp('usage: [X0,Y0] = axybc(A,B,C[,tol][,''minimal'']) ');
 disp('   or: [X0,Y0,Kx,Ky] = axybc(A,B,C[,tol][,''minimal'']) ');
 return
end
[typeA,rA,cA,degA] = pinfo(A);
[typeB,rB,cB,degB] = pinfo(B);
[typeC,rC,cC,degC] = pinfo(C);
if isempty(A)|isempty(B)|isempty(C)
   X0=[]; Y0=[]; Kx=[]; Ky=[];
   return
end
zeroC=0;
if norm(punpck(C))<eps, zeroC=1;  end

if ~zeroC & ((rA ~= rC) | (cB ~= cC))
  error('Inconsistent dimensions of the input matrices.');
end;
if nargout>2, gnrl=1; end
if ~zeroC | (zeroC & max(rC,cC)>1)
   vecC = [];
   for i = 1:cC,
     vecC = prowjoin(vecC, psel(C, ':', i));
   end;
else, vecC=0; end 

newA = pcoljoin(pkron(eye(cB), A), pkron(ptransp(B), eye(rA)));
newB = vecC;

% call xab with transposed arguments
% and with error checking

if gnrl | zeroC
   strout=['[XT,KT]'];
else
   strout=['XT'];
end
strout = [strout,'=xab(ptransp(newA),ptransp(newB),tol);'];
eval(strout,'error(lasterr)');
vecX=ptransp(XT);
if gnrl | zeroC, vecK=ptransp(KT); end

if isempty(vecX),

   X0 = []; Y0 = [];

else                               % PARTICULAR SOLUTION

  vecXx = psel(vecX,1:cA*cB,1); degX=max(0,pdegco(vecXx));
  vecXy = psel(vecX,cA*cB+1:cA*cB+rA*rB,1); degY=max(0,pdegco(vecXy));
  X = zeros(cA, cB*(degX+1));
  Y = zeros(rA, rB*(degY+1));
  if ~zeroC
     X(:) = punpck(vecXx); Y(:) = punpck(vecXy);
  end
  if degX>0|degY>0|strcmp(typeA,'poly')|strcmp(typeB,'poly')|strcmp(typeC,'poly')
     X0 = ppck(X, degX); Y0 = ppck(Y, degY);
  else, X0=X; Y0=Y; end
end
if gnrl | zeroC                    % HOMOGENEOUS SOLUTION
 if isempty(vecK)
  Kx=[]; Ky=[];
 else
  [void,void,cK,degK] = pinfo(vecK);
  Kx = []; Ky = []; Kxi = zeros(cA, cB); Kyi = zeros(rA, rB);
  for i = 1:cK,
    Kcx = psel(vecK,1:cA*cB,i); degKcx=max(0,pdegco(Kcx));
    Kcy = psel(vecK,cA*cB+1:cA*cB+rA*rB,i); degKcy=max(0,pdegco(Kcy));
    Kjx = []; Kjy = [];
    for j = 0:degKcx,
      Kix(:) = pdegco(Kcx, j);
      Kjx = [Kjx Kix];
    end;
    for j = 0:degKcy,
      Kiy(:) = pdegco(Kcy, j);
      Kjy = [Kjy Kiy];
    end;
    Kjx = ppck(Kjx, degKcx); Kjy = ppck(Kjy, degKcy);
    Kx = prowjoin(Kx,Kjx); Ky = prowjoin(Ky,Kjy);
  end;
   Kx = pscl(Kx,-1);
 end;
 [typeKx,rKx,cKx,degKx]=pinfo(Kx);
 [typeKy,rKy,cKy,degKy]=pinfo(Ky);
 if degKx<=0&degKy<=0&~strcmp(typeA,'poly')&~strcmp(typeB,'poly')&~strcmp(typeC,'poly')
    Kx=punpck(Kx); Ky=punpck(Ky);
 end
 if ~gnrl & zeroC
  X0 = Kx; Y0 = Ky;
 end
end;
if minim & ~zeroC                  % MINIMAL DEGREE SOLUTION
   if tol >= 0
      str_tol=[',tol'];
   else, str_tol=[]; end
   str_min=['[Q,Ym]=pdiv(Y0,A,''l'',''z'''];
   str_min=[str_min,str_tol,');'];
   eval(str_min,'Q=[]; Ym=[]; ');
   Xm=[];
   if ~isempty(Ym) & ~isempty(Q)
      str_min=['Xm=padd(X0,pmul(Q,B,''z''',str_tol,'),''z''',str_tol,');'];
      eval(str_min,'Xm=[];');
   end
   if ~isempty(Ym) & ~isempty(Xm)&(norm(isnan(punpck(Xm)))<eps)&...
      (norm(isnan(punpck(Ym)))<eps)
      X0=Xm; Y0=Ym;
   else
      disp('axybc warning: Degree cannot be reduced by division.');
   end
end;
