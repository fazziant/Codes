% hermite
%
% Reduction of a polynomial matrix to Hermite form
%
% The commands
%
%    [D,V,VI] = hermite(A[,'z'][,tol][,'menu'][,'movie'])
%    [D,V,VI] = hermite(A,'row'[,'z'][,tol][,'menu'][,'movie'])
%    [D,V,VI] = hermite(A,'col'[,'z'][,tol][,'menu'][,'movie'])
%
% convert the polynomial matrix A to Hermite form.
%
% In the form
%
%    [D,V,VI] = hermite(A[,'z'][,tol][,'menu'][,'movie'])
%    [D,V,VI] = hermite(A,'row'[,'z'][,tol][,'menu'][,'movie'])
%
% the row Hermite form is computed by elementary column operations
% so that
%
%     D = A*V
%
% D is a lower triangular matrix with monic diagonal elements, where 
% each of these elements has the highest degree in its row.
%
% In the form
%
%   [D,V,VI] = hermite(A,'col'[,'z'][,tol][,'menu'][,'movie'])
%
% the column Hermite form ic computed by elementary row operations
% so that
%
%   D = V*A
%
% D is a upper triangular matrix with monic diagonal elements; the
% diagonal element of D are of higher degree than any nonzero element 
% above it.
%
% The default type of the Hermite form is the row Hermite form.
%
% V and VI = V^(-1) are unimodular transformation matrices. 
%
% The input arguments 'z' and tol are used in "zeroing" (see the
% function 'pzero'). The default value of the tolerance tol is 
% computed from the degree and sizes of A. If 'z' and tol are missing
% then the macro runs without "zeroing". THE USE OF ZEROING IS 
% STRONGLY RECOMMENDED!!!
%
% The fourth argument 'menu' allows to select and control the next 
% step of the reduction.
%
% The fifth argument allows to create a 2-D or 3-D graphics object
% from the reduced matrix.

% functions used: stairsl, pinfo, punpck, ppck, pdegco, psel, pmul,
%                pput, matplot, matplot3

% COPYRIGHT S. Pejchova, M. Sebek 1997
% $Revision: 1.0$      $Date: 1997/04/16 16:22:17 $    $State: Exp $

function [D,V,VI] = hermite(A,arg2,arg3,arg4,arg5,arg6)

menu1=0;, mov1=0;, test1=0;, tol=eps;, step_plot=[0 0 0];
method=0; zeroing=0; ssttgg=[];

if nargin==0
   test1=1;
elseif isstr(A)
   test1=1;
elseif nargin>1
   for i=2:nargin
       stg=['argm=arg',int2str(i),';'];
       eval(stg);
       if isstr(argm)
          if strcmp(argm,'menu')
             menu1=1; ssttgg=[ssttgg,',''menu'''];
          elseif strcmp(argm,'movie')
             mov1=1; ssttgg=[ssttgg,',''movie'''];
          elseif strcmp(argm,'col')
             method=1;
          elseif strcmp(argm,'z')
             if zeroing==0, zeroing=2; ssttgg=[ssttgg,',''z''']; end   
          elseif ~strcmp(argm,'row')
             test1=1;
          end
       elseif length(argm)==1
          tol=argm; zeroing=1; ssttgg=[ssttgg,',tol'];
       else
          test1=1;
       end
   end
end

if test1
   disp('usage: [D,V,VI]=hermite(A,''z'',tol,''menu'',''movie'') ');
   disp('    or [D,V,VI]=hermite(A,''row'',''z'',tol,''menu'',''movie'') ');
   disp('    or [D,V,VI]=hermite(A,''col'',''z'',tol,''menu'',''movie'') ');
   disp('THE USE OF ZEROING IS STRONGLY RECOMMENDED !!! ');
   return
end
if method
   A=ptransp(A); step_plot(3)=1;
end
[typeA,rA,cA,degA]=pinfo(A);
if isempty(A) | isinf(degA) | norm(punpck(A))<tol
   V=eye(cA); 
   if strcmp(typeA,'poly'), V=ppck(V,0); end
   D=A; VI=V;
   if method, D=ptransp(D); end
   return
end
degofdet=degA*(min(rA,cA));

stg='[D,V,VI,rlD,step_plot]=pstairs(A,''low'',step_plot'; 
stg=[stg,ssttgg,');'];
eval(stg);
if step_plot(1)>10
   if method, D=ptransp(D); V=ptransp(V); VI=ptransp(VI); end
   return
end
NormD=norm(punpck(D)); if NormD==0, NormD=1; end
D=pscl(D,1/NormD);
if zeroing==2
   tol=norm(punpck(D))*(max(size(punpck(D))))*eps*1e2;
elseif zeroing==1
   tol=tol/NormD;
end
[typeD,rD,cD,degD]=pinfo(D);
[DEGD,LCD]=pdegco(D,'ent');
n=min(rD,max(rlD));
if abs(LCD(1,1))>tol
   diaL=LCD(1,1);
else
   diaL=[];
end
if n>1
   for i=2:n                                % reduction of i-row
     ind=find(rlD==i);
     if isinf(DEGD(ind(1),i))==0
        diaL=[diaL,LCD(ind(1),i)];
        T=ppck(eye(cD),0);, TI=T;           % reduction to the left
        for j=1:i-1
            if DEGD(ind(1),i)<=DEGD(ind(1),j)
               ar=fliplr(punpck(psel(D,ind(1),i)));
               if isinf(DEGD(ind(1),j))==0
                  br=fliplr(punpck(psel(D,ind(1),j)));
                  [qr,rr]=deconv(br,ar);
                  if zeroing > 0
                     q=pzero(qr(length(qr):-1:1),tol);
                  else
                     q=qr(length(qr):-1:1);
                  end
                  T=pput(T,i,j,ppck(-q,length(q)-1));
                  TI=pput(TI,i,j,ppck(q,length(q)-1));

               end  %(isinf(DEGD))
            end  %(if DEGD)
        end  %(for j=1:i-1)
        if zeroing > 0
           V=pmul(V,T,'z',tol); VI=pmul(TI,VI,'z',tol);
           D=pmul(D,T,'z',tol);
        else
           V=pmul(V,T); VI=pmul(TI,VI); D=pmul(D,T);
        end
        [DEGD,LCD]=pdegco(D,'ent');
        frow=find(DEGD(ind(1),1:i-1)>=DEGD(ind(1),i));
        if isempty(frow)==0
           for m=frow
               nm=(DEGD(ind(1),i)*cD+m):cD:(max(max(DEGD))+1)*cD;
               D(ind(1),nm)=zeros(1,length(nm));
           end
           D=ppck(punpck(D),pdegco(D));
        end
        [DEGD,LCD]=pdegco(D,'ent');
        [menu1,mov1,step_plot]=graphobj(menu1,mov1,step_plot,D);
        if step_plot(1)>10
           if method, D=ptransp(D); V=ptransp(V); VI=ptransp(VI); end
           return
        end
     end  %(if isinf)
   end  %(for i=2:n)
end  %(if n>1)
if zeroing > 0, D=pzero(D,tol); end
D=pscl(D,NormD); diaL=diaL*NormD;
tol=tol*NormD;
diaT=ones(cD,1);
if isempty(diaL)==0
   diaT(1:length(diaL))=diaL;
end
TI=diag(diaT);
diaT=diaT.^(-1);
T=diag(diaT);                               % 'monic' transformation
if zeroing > 0
   V=pmul(V,T,'z',tol); VI=pmul(TI,VI,'z',tol);
   D=pmul(D,T,'z',tol);
else
   V=pmul(V,T); VI=pmul(TI,VI); D=pmul(D,T);
end
DEGD=pdegco(D,'ent');
DEGDc=DEGD;
if rD>1, DEGDc=max(DEGD); end
zc= find(DEGDc<0);                          % sorting of columns
if isempty(zc)==0
   Tp=eye(cD);
   nzc=1:cD;, nzc(zc)=[];
   T=[Tp(:,nzc), Tp(:,zc)];
   TI=T';
   V=pmul(V,T); VI=pmul(TI,VI); D=pmul(D,T);
end
[menu1,mov1,step_plot]=graphobj(menu1,mov1,step_plot,D);
if step_plot(1)>10
   if method, D=ptransp(D); V=ptransp(V); VI=ptransp(VI); end
   return
end
Res=(norm(punpck(psub(D,pmul(A,V)))))/NormD;
if Res > tol*1e4
   disp(' ');
   disp(sprintf('Warning(hermite): The relative residue of calculation is  %g',Res));
   disp('                  Try to change tolerance.');
else
   degdiaD=diag(DEGD);
   degdiaD=sum(degdiaD);
   if degdiaD > degofdet
      disp(' ');
      disp('Warning(hermite): Resulting degree may not be correct! ');
      disp('                  Try to change tolerance.');
   end
end
if method, D=ptransp(D); V=ptransp(V); VI=ptransp(VI); end
if strcmp(typeA,'cons')
   [typeD,rD,cD,degD]=pinfo(D);
   [typeV,rV,cV,degV]=pinfo(V);
   [typeVI,rVI,cVI,degVI]=pinfo(VI);
   if degD <= 0, D=punpck(D);, end
   if degV <= 0, V=punpck(V);, end
   if degVI <= 0, VI=punpck(VI);, end
end
