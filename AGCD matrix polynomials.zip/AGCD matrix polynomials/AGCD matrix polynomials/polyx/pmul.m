%pmul
%
% Multiplication of polynomial matrices
%
% The commands
%
%    C = pmul(mat1,mat2,mat3,...,matN)
%    C = pmul(mat1,mat2,mat3,...,matN,'z')
%    C = pmul(mat1,mat2,mat3,...,matN,'z',EPS)
%
% produce the polynomial matrix C that equals the product 
%
%    mat1 * mat2 * mat3 * ... * matN 
%
% of the polynomial matrices mat1, mat2, ..., matN.  
%
% If one of the input matrices is a regular Matlab matrix then it 
% is considered to be a polynomial matrix with degree 0. If all 
% input matrices are regular Matlab matrices then C is of the same 
% type.
%
% If the input argument 'z' is present then the multiplication is 
% accompanied by zeroing (see the function pzero) with threshold
% EP = me*eps*10^(8). The number me is the product of the minimum
% (in absolute value) of the nonzero scalar coefficients occurring in
% the input matrices. If the optional argument EPS is present then 
% zeroing is performed with EP = me*EPS.
%
% The maximal total number of input arguments of the macro depends 
% on the Matlab version (10 in version 4).

% functions used: pinfo, pmin, ppck, punpck, pzero

% R. C. W. Strijbos, S. Pejchova, 1995
% $Revision: 1.4 $	$Date: 1996/04/18 12:37:28 $	$State: Exp $

function C = pmul(mat1,mat2,mat3,mat4,mat5,mat6,mat7,mat8,mat9,mat10)

last = [];
lastone = [];

num=nargin;, test1=0;
if num > 1
   st=['last=mat', int2str(nargin), ';'];
   eval(st);
end
if num > 2
   st1=['lastone=mat',int2str(nargin-1),';'];
   eval(st1);
end

illstr=0;
if isstr(last)==1
   if strcmp(last,'z')
      num=nargin-1;, test1=1;
      EPS=1e8*eps;
    else
      illstr=1;
   end
end
if isstr(lastone)
   if strcmp(lastone,'z')
      num=nargin-2;, test1=1;
      EPS=last;
    else
      illstr=1;
   end
end

if num <= 1 | illstr
   disp('usage: C = pmul(mat1,mat2,...,matN) ');
   disp('    or C = pmul(mat1,mat2,...,matN,''z'') ');
   disp('    or C = pmul(mat1,mat2,...,matN,''z'',EPS) ');
   return
end

if test1
   [rE,cE]=size(EPS);
   if rE ~= 1 | cE ~= 1 | isstr(EPS)
      error('pmul: The input argument for zeroing should be a scalar');
   end
end

A=mat1;
[typeA,rA,cA,degA] = pinfo(A);
A=punpck(A);
minmat=pmin(mat1);

if typeA=='empt'
    C=[];
    return
end
if isnan(degA),  degA=0;, end

for j=2:num
    strB=['B=mat',int2str(j),';'];
    eval(strB);
    [typeB,rB,cB,degB] = pinfo(B);
    minmatB=pmin(B);
    minmat=minmat*minmatB;

    if typeB == 'empt',  C=[];, return, end

    if isnan(degB),  degB=0;, end 
    
    % polynomials (scalars in the ring of matrices) are accepted
    scalA = (cA == 1 & rA == 1);
    scalB = (cB == 1 & rB == 1);

    if scalA
      rC = rB; cC = cB;
    elseif scalB
      rC = rA; cC = cA;
    elseif cA ~= rB
      error('pmul: Inconsistent dimensions of the input matrices');
    else
      rC = rA; cC = cB;
    end   

    if degA == -Inf | degB == -Inf
       C = zeros(rC,cC);

       degC = -Inf;
    elseif typeA == 'cons' & typeB == 'cons'
       C=A*B;
       degC=0;
    else
       degC = degA + degB;
       C=[];

       for k = 0:degC
           mi = 0;
           if k-degB > mi
              mi = k-degB;
           end
           ma = degA;
           if k < ma
              ma = k;
           end
           Ck = zeros(rC,cC);
           for i = mi:ma
               Ck = Ck + A(:,i*cA+1:(i+1)*cA)*B(1:rB,(k-i)*cB+1:(k-i+1)*cB);
           end
           C = [C Ck];
       end
       typeA='poly';
    end
    A=C;, degA=degC;
    rA = rC; cA = cC;

end

if typeA == 'poly'
   C = ppck(C,degC);
   if test1 & ~isempty(minmat)
      EP=EPS*minmat;
      C=pzero(C,EP);
   end
end
