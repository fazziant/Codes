%padd
%
% The commands
%
%    C = padd(mat1,mat2,mat3,...,matN)
%    C = padd(mat1,mat2,mat3,...,matN,'z')
%    C = padd(mat1,mat2,mat3,...,matN,'z',EPS)
%
% results in the polynomial matrix C that is the sum of the polynomial
% matrices mat1, mat2, ..., matN. 
%
% If one of the input matrices is a regular Matlab matrix then it 
% is considered to be a polynomial matrix with degree 0. If all 
% input matrices are regular Matlab matrices then C is of the 
% same type;
%
% In the option 'z' is included then the addition is accompanied by 
% zeroing  (see the function 'pzero'). The threshold is
% EP = me*eps*10^(8) where me is the minimum (in absolute value)
% nonzero scalar coefficient occuring in the matrices mat1, mat2, 
% ...,, matN. If the additional argument EPS is present then zeroing 
% is performed with EP = me*EPS.
%
% The maximal total number of input arguments of the macro depends 
% on the Matlab version (10 in version 4).

% functions used: pinfo, pmin, punpck, ppck, pzero

% R. C. W. Strijbos, S. Pejchova
% $Revision: 1.4 $	$Date: 1996/04/18 11:45:30 $	$State: Exp $

function C = padd(mat1,mat2,mat3,mat4,mat5,mat6,mat7,mat8,mat9,mat10)

last=[];
lastone=[];

num=nargin;, test1=0;
if num > 1
   st=['last=mat',int2str(nargin),';'];
   eval(st);
   lastone=[];
end
if num > 2
   st1=['lastone=mat',int2str(nargin-1),';'];
   eval(st1);
end

illstr=0;
if isstr(last)
   if strcmp(last,'z')
      num=nargin-1;, test1=1;
      EPS=1e8*eps;
    else
      illstr=1;
   end
end
if isstr(lastone)
   if strcmp(lastone,'z')
      num=nargin-2;, test1=1;
      EPS=last;
    else
      illstr=1;
   end
end
if num <= 1 | illstr==1
   disp('usage: C = padd(mat1,mat2,...,matN) ');
   disp('    or C = padd(mat1,mat2,...,matN,''z'') ');
   disp('    or C = padd(mat1,mat2,...,matN,''z'',EPS) ');
   return
end

if test1
   [rE,cE]=size(EPS);
   if rE ~= 1 | cE ~= 1 | isstr(EPS)
      error('padd: The input argument for zeroing should be a scalar');
   end
end

[typeA,rA,cA,degA] = pinfo(mat1);
A=punpck(mat1);
minmat=pmin(mat1);

if isempty(A),  C = [];,  return,  end

if isnan(degA),  degA=0;,  end

for  j=2:num
     strB=['B=mat',int2str(j),';'];
     eval(strB);
     [typeB,rB,cB,degB] = pinfo(B);
     minmatB=pmin(B);
     if minmatB < minmat
        minmat=minmatB;
     end

     if typeB == 'empt',  C=[];,  return,   end

     if isnan(degB),  degB=0;,   end

     if cA ~= cB | rA ~= rB
        error('padd: Inconsistent dimensions of the input matrices');
     end
     if degA == -Inf
        C = punpck(B);
        degC = degB;
        typeA=typeB;
     elseif degB == -Inf
        C = A;
        degC = degA;
     else
        if typeA == 'cons'  & typeB =='cons'
           degC=0;
        else
           B=punpck(B);
           degC = max(degA,degB);
           if degC > degA
              A = [A zeros(rA,(degC-degA)*cA)];
           end
           if degC > degB
              B = [B, zeros(rB,(degC-degB)*cB)];
           end
           typeA='poly';
        end
        C = A + B;
      end
      A=C;,   degA=degC;
end

if typeA == 'poly'
   C = ppck(C,degC);
   if test1 & ~isempty(minmat)
      EP=EPS*minmat;
      C=pzero(C,EP);
   end
end


